<div class="navigation-box">
    <div class="container">
      <div class="navigation" id="chromemenu1">
        <ul>
          <li><a class="selected" href="#" title="Customers">Home</a></li>
          <!--<li><a href="#" title="Web Sites">Web Sites</a></li>
          <li><a href="#" title="Packages">Packages</a></li>
          <li><a href="#" title="Email Templates">Email Templates</a></li>
          <li><a href="#" title="CMS">CMS</a></li>
          <li><a href="#" title="Settings">Settings</a></li>-->
        </ul>
      </div>
    </div>
  </div>
<?php 
  session_start();
  include_once('header.php');
  include_once('navigation_menu.php');
  include_once('dbclass.php');
  require_once('pagination.php');
	
	$conn = new dbclass();
	$page=1; //Default page

	// export data
	if(isset($_GET['checkbox']) && $_GET['checkbox']!=''){
		$Checkboxarray = implode("','",$_GET['checkbox']);
		header('Location: export_data.php?data='.$Checkboxarray);
	} 
	
	
	//Records per page
	if(isset($_GET['sort_by']) && $_GET['sort_by']!=''){
		$limit=$_GET['sort_by'];
	} else {
		$limit=25;
	}
	
	$wheres = array();
	// get the status
	if(isset($_GET['status']) && $_GET['status']!=''){
		$status=$_GET['status'];
		$wheres[] = "status = '".$_GET['status']."'";
	} else {
		$status = "";
	}
	
	//get the search var
	if(isset($_GET['search']) && ($_GET['search'] != 'Search Emails...' || $_GET['search'] == '')){
		$searchvar = $_GET['search'];
		$wheres[] = "email like '%".$_GET['search']."%'";
	} else {
		$searchvar = "Search Emails...";
	}	
		
	if(count($wheres) > 0){
		$where = implode(' AND ',$wheres);
	} else{
		$where = 1;
	}
	//starts displaying records from 0
	$start=0; 
	
	if(isset($_GET['page']) && $_GET['page']!=''){
		$page=$_GET['page'];
	}

	$start=($page-1)*$limit;

	//Get total records (you can also use MySQL COUNT function to count records)

	$query = $conn->select("select id from emaillist where $where ");
	$rows = count($query);
	
	if($limit < 0){
		$qry = "select * from emaillist where $where order by id DESC";
	} else {
		$qry = "select * from emaillist where $where order by id DESC LIMIT $start, $limit";
	}
	//echo $qry;
	$records = $conn->select( $qry);
?>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
<SCRIPT language="javascript">
$(function(){
 
    // add multiple select / deselect functionality
    $("#selectall").click(function () {
          $('.checkbox').attr('checked', this.checked);
    });
    $(".checkbox").click(function(){
 
        if($(".checkbox").length == $(".checkbox:checked").length) {
            $("#selectall").attr("checked", "checked");
        } else {
            $("#selectall").removeAttr("checked");
        }
 
    });
});
</SCRIPT>
  
  
  <div class="page-info">
    <div class="container">
    <div class="add-btn"> <a href="import_data.php" title=""> <img width="14" height="14" alt="" src="images/add-icon.png"> <span>Import Emails (CSV) </span> </a> </div>
      <div id="breadcrumbs"> <a class="first" href="gridview.php">Home</a> \ All Emails </div>
    </div>
    <div id="tab-width">
      <div id="tab-box" >
        <div id="page-tabs">
          <ul>
            <li class="selected">
              <div>&nbsp;</div>
              <a href="gridview.php">All Emails</a>
            <li class="last">
              <div>&nbsp;</div>
              <a href="import_data.php">Import Emails</a>
              <div class="last"></div>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div class="clear"></div>
  </div>
  
  <div id="content">
    <div class="container">
      <h1 class="page-title">All Emails</h1>
      <div class="col-s-content-project">
        <div class="left-part-project">
		
		<?php 
		  if(!isset($_GET['sort_by'])) {
			$_GET['sort_by'] = 25;
		  }
    	?>
			  
		<form action="" class="selection fancy-form order" method="get">
        <div class="gried-view">
            <div class="project-list-box">
              <div class="sorter date-sorter">
			  
			    
                <label class="font-9" for="sort_by">Show </label>
                <select style="width:30px;" class="sort_order" id="sort_by" name="sort_by" onchange="$('.checkbox').attr('checked', false); this.form.submit()">
					<option value="5" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '5') { ?> selected = "selected" <?php } ?>>5</option>
					<option value="10" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '10') { ?> selected = "selected" <?php } ?>>10</option>
					<option value="15" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '15') { ?> selected = "selected" <?php } ?>>15</option>
					<option value="25" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '25') { ?> selected = "selected" <?php } ?>>25</option>
					<option value="50" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '50') { ?> selected = "selected" <?php } ?>>50</option>
					<option value="100" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '100') { ?> selected = "selected" <?php } ?>>100</option>
					<option value="-1" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '-1') { ?> selected = "selected" <?php } ?>>All</option>
                </select>
                  <label>&nbsp;&nbsp;&nbsp;records</label>
				  
				   <input type="text" name="search" class="searchbox_class" onclick="this.value = ''" <?php if(isset($_GET['search']) && $_GET['search'] != 'Search Emails...') { ?> value="<?php echo $_GET['search'];?>" <?php } else { ?> value="Search Emails..." <?php } ?> onblur="if(this.value==''){this.value='Search Emails...'};" />
                  <select style="width:60px;" class="sort_order" id="status" name="status" onchange="$('.checkbox').attr('checked', false); this.form.submit()">
                    <option value="">--Status--</option>
                    <option value="Valid" <?php if(isset($_GET['status']) && $_GET['status'] == 'Valid') { ?> selected = "selected" <?php } ?>>Valid</option>
                    <option value="Invalid" <?php if(isset($_GET['status']) && $_GET['status'] == 'Invalid') { ?> selected = "selected" <?php } ?>>Invalid</option>
                  </select>
                  <button onclick="$('.checkbox').attr('checked', false);" class="submit-button-dark" id="mc-embedded-subscribe" type="submit" style="margin-left:10px;"><span class="sprite"><em class="sprite">GO</em></span></button>
                  <div style="float:right;"><a href="gridview.php" class="submit-button-dark" id="mc-embedded-subscribe"><span class="sprite"><em class="sprite">Reset</em></span></a></div>
				  
                
              </div>
            </div>
          </div>
		
		<?php if(isset($_SESSION['success_message'])) { ?>
		<div class="sucessMessage">
				<p>
				<?php 
					echo $_SESSION['success_message']; 
					unset($_SESSION['success_message']); 
				?>
				</p>
		</div>
		<?php } ?>
		
		<?php if(isset($_SESSION['error_message'])) { ?>
		<div class="errorMessage">
			<p>
				<?php 
					echo $_SESSION['error_message'];
					unset($_SESSION['error_message']);
				?>
			</p>
		</div>
		<?php } ?>
		  
          <div class="shadowed" id="items">
            <div class="inner-boundaries">
              <div class="gried-view">
                <div class="project-box">
                  <div class="gray-box-bg">
					<table cellpadding="0" cellspacing="0" border="0" width="100%" class="gridViewTable">
                      <tr>
						<th align="left" style="width:30px">
							<input name="selectall" id="selectall" type="checkbox">
							
						</th>
                        <th style="width:30px" align="left">Id</th>
                        <th align="left">Email</th>
                        <th style="width:75px" align="left">Status</th>
                      </tr>
					  <?php
						
						if(count($query)>0){
						$countRecord = count($records);
						$idNo = $start+1;
						foreach($records as $number => $data) {
						?>
						<tr class="odd">
							<td>
							<input name="checkbox[]" class="checkbox" type="checkbox"  value="<?php echo $idNo; ?>">
							</td>
							<td><?php echo $idNo;?></td>
							<td><?php echo $data['email'];?></td>
							<td><?php echo $data['status'];?></td>
						</tr>
						<?php $idNo++; }
						} else{
						?>
						<tr class="odd" >
							<td colspan="3"><?php echo "No records";?></td>
						</tr>
						<?php
						} ?>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
		  <div class="btnLeft">
          	<button type="submit" id="mc-embedded-subscribe" class="submit-button-dark"><span class="sprite"><em class="sprite">Export Selected</em></span></button>
          </div>
		  </form>
		<div class="paging-box paging-dashboard">
            <div style="clear:both;" class="pagination margin10-top">               
			  <?php
				echo pagination($limit,$page,'gridview.php?sort_by='.$limit.'&search='.$searchvar.'&status='.$status.'&page=',$rows,$countRecord); //call function to show pagination
			  ?>
            </div>
        </div>
        </div>
      </div>
    </div>
  </div>
<?php include_once('footer.php');?>


  <?php 
  session_start();	
  include_once('header.php');
  include_once('navigation_menu.php');
  include_once('dbclass.php');
  
  require_once('smtp_validateEmail.class.php');
  require_once('logfile.php');
  
  $conn = new dbclass();
  
  
  if(isset($_POST['cancel']) && $_POST['cancel'] != ''){
	header('Location: gridview.php');
  }
  
  if(isset($_POST['subscribe']) && $_POST['subscribe'] != ''){
	  if ($_FILES["file_csv"]["error"] > 0){
			$_SESSION['error_message'] = " Please select the CSV file";
	  }
  if(isset($_FILES['file_csv']['name']) && $_FILES['file_csv']['name'] != '' ){
	$startTime = time();
	startLoging('log'); 
	logFile("start time:= ".$startTime);
	set_time_limit(0);
	ini_set('memory_limit', '-1');

	$SMTP_Validator = new SMTP_validateEmail();
	
	
	
	$validemails = array();
	$finalcnt = 0;
	$row = 1;

	if (($handle = fopen($_FILES["file_csv"]["tmp_name"], "r")) !== FALSE) {
		while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
			$num = count($data);
		    for ($c=0; $c < $num; $c++) {
					$validemails[$finalcnt] =  $data[0];	
			}
			$finalcnt++;
		}
		fclose($handle);
	}
	
		$sender = 'user@yourdomain.com';

		// turn on debugging if you want to view the SMTP transaction
		//$SMTP_Validator->debug = true;
		// do the validation
		$results = $SMTP_Validator->validate($validemails, $sender);

		// view results
		$stringvaluePart = "";
		foreach($results as $email=>$result) {
		$status = ($result) ? 'Valid' : 'Invalid';
		
		$stringvaluePart .= "(
			'" .$email . "' ,
			'" .$status. "'
			),";
		}
		
		$stringSql = "INSERT INTO emaillist
					(email, status)";
		$stringSql .= "VALUES";
		$stringvaluePart = trim($stringvaluePart, ',');
		
		$resultQuery = $conn->insert($stringSql . $stringvaluePart);
		
		$_SESSION['success_message'] = 'Data imported successfully.';
		
		$endTime = time();
		logFile('Total seconds: ' . ($endTime - $startTime) );
		logFile('Completed');
		header('Location: gridview.php');
		
	}
  
  }
  
  
?>

  <div class="page-info">
    <div class="container">
      <!--<div class="add-btn"> <a href="add-new.html" title=""> <img width="14" height="14" alt="" src="images/add-icon.png"> <span>Add New </span> </a> </div> -->
      <div id="breadcrumbs"> <a class="first" href="gridview.php">Home</a> \ Import Emails </div>
	  
    </div>
	
    <div id="tab-width">
      <div id="tab-box" >
        <div id="page-tabs">
        <ul>
            <li class="">
              <div>&nbsp;</div>
              <a href="gridview.php">All Emails</a></li>
            <li class="selected last">
              <div>&nbsp;</div>
              <a href="import_data.php">Import Emails</a>
              <div class="last"></div>
            </li>
        </ul>
        
        </div>
      </div>
    </div>
    <div class="clear"></div>
  </div>
  <div id="content">
    <div class="container">
		<?php if(isset($_SESSION['error_message'])) { ?>
		<div class="errorMessage">
			<p>
				<?php 
					echo $_SESSION['error_message'];
					
				?>
			</p>
		</div>
		<?php }
unset($_SESSION['error_message']);
		?>
	
      <h1 class="page-title">Import File</h1>
      <div class="col-s-content">
        <div class="left-part">
          <div class="shadowed" id="items">
            <div class="inner-boundary">
              <div class="signup-content">
                <form name="createAccount" method="post" action="" id="createAccount" enctype="multipart/form-data">
                  <input name="check" type="hidden" value="check" id="check"/>
                  <div class="add-form-box">
                    <ul>
                      <li>
                        <label><em>*</em> Filename:</label>
                        <input type="file" name="file_csv" id="file_csv" class="name required add-form-input">
                        <span class="field_error" style="display: none;"> </span> </li>
                    </ul>
                  </div>
                  <div class="submit-btn noMargin">
                   <button class="submit-button-dark" id="mc-embedded-subscribe1" name="subscribe" value="subscribe" type="submit"><span class="sprite"><em class="sprite">Save</em></span></button>
              <button class="submit-button-dark" id="mc-embedded-subscribe1" name="cancel" value="cancel" type="submit"><span class="sprite"><em class="sprite">Cancel</em></span></button>
			  </div>
				  <div id="downloadSample">Download: <a id= "downloadSampleMain" href="sampleData/emails.csv"><span >Sample CSV</span></a>
				  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
	  <div class="large-sidebar">
        <div class="section">
          <h4 class="decorator title sprite">Why Sign Up?</h4>
          <div class="inner-boundary first-item last-item">
            <div class="inner-border">
              <p>It only takes a couple of minutes to create an account that works not just on ThemeForest, but on ALL the <a href="#">Envato Marketplaces</a>. Your account will let you:</p>
              <a href="index.html">
              <button type="submit" name="subscribe" id="mc-embedded-subscribe1" class="submit-button-dark"><span class="sprite"><em class="sprite">Sign Up Now</em></span></button>
              </a> </div>
          </div>
        </div>
      </div>
		
    </div>
	
  </div>
</div>

<?php include_once('footer.php');?>

function toggle_visibility(id) {
       var e = document.getElementById(id);
       if(e.style.display == 'block')
          e.style.display = 'none';
       else
          e.style.display = 'block';
    }
$(document).ready(function(){
$(".reply-box-open").click(function(){
showElement = $(this).parent().parent().parent().parent().parent().parent().children(".subreply").attr('class');
$('.open').each(function(index) {
domEle = this;
if ($(domEle).attr('class') != showElement){
				$(domEle).hide();
				$(domEle).removeClass('open');
		
			};
		});
activeClass = $(this).attr('class');
		$('.active').each(function(index) {
			domEle = this;
	
			if ($(domEle).attr('class') != activeClass){
				$('.active').removeClass('active');
	
			};
		});
		$(this).toggleClass('active');
		$(this).parent().parent().parent().parent().parent().parent().children(".subreply").toggleClass('open');
		$(this).parent().parent().parent().parent().parent().parent().children(".subreply").slideToggle();	
	});
	$(".attachment-box").click(function(){
	showElement = $(this).parent().parent().parent().parent().parent().parent().children(".subattach").attr('class');
		$('.open').each(function(index) {
			domEle = this;
	if ($(domEle).attr('class') != showElement){
				$(domEle).hide();
				$(domEle).removeClass('open');

			};
		});
activeClass = $(this).attr('class');
		$('.active').each(function(index) {
			domEle = this;

			if ($(domEle).attr('class') != activeClass){
				$('.active').removeClass('active');

			};
		});
		$(this).toggleClass('active');
		$(this).parent().parent().parent().parent().parent().parent().children(".subattach").toggleClass('open');
		$(this).parent().parent().parent().parent().parent().parent().children(".subattach").slideToggle();	
	});

}); 


function addNewFile(id){
	$("#"+id+" ul").append("<li><span>&nbsp;</span><div style='float: left'><input type='file' name='username' id='username2' /><a onclick='$(this).parent().parent().remove();' style='cursor:pointer;' title='Delete'> + Delete</a></div></li>");
	return false;
	}

(function (l) {
    var i = {
        preloadImg: true
    };
    var m = false;
    var o = function (a) {
            a = a.replace(/^url\((.*)\)/, "$1").replace(/^\"(.*)\"$/, "$1");
            var c = new Image();
            c.src = a.replace(/\.([a-zA-Z]*)$/, "-hover.$1");
            var b = new Image();
            b.src = a.replace(/\.([a-zA-Z]*)$/, "-focus.$1")
        };
    var k = function (b) {
            var a = l(".jqTransformSelectWrapper ul:visible");
            a.each(function () {
                var c = l(this).parents(".jqTransformSelectWrapper:first").find("select").get(0);
                if (!(b && c.oLabel && c.oLabel.get(0) == b.get(0))) {
                    l(this).hide()
                }
            })
        };
    var j = function (a) {
            if (l(a.target).parents(".jqTransformSelectWrapper").length === 0) {
                k(l(a.target))
            }
        };
	
    var p = function () {
            l(document).mousedown(j)
        };
    var n = function (a) {
            var b;
            l(".jqTransformSelectWrapper select", a).each(function () {
                b = (this.selectedIndex < 0) ? 0 : this.selectedIndex;
                l("ul", l(this).parent()).each(function () {
                    l("a:eq(" + b + ")", this).click()
                })
            });
            l("a.jqTransformCheckbox, a.jqTransformRadio", a).removeClass("jqTransformChecked");
            l("input:checkbox, input:radio", a).each(function () {
                if (this.checked) {
                    l("a", l(this).parent()).addClass("jqTransformChecked")
                }
            })
        };
    l.fn.jqTransSelect = function () {
        return this.each(function (d) {
            var s = l(this);
            if (s.hasClass("jqTransformHidden") || s.hasClass("jqTransformIgnore")) {
                return
            }
            if (s.attr("multiple")) {
                return
            }
            var f = s.addClass("jqTransformHidden").wrap('<div class="jqTransformSelectWrapper sprite"></div>').parent().css({
                zIndex: 50 - d
            });
            f.prepend('<div><span></span><a href="#" class="jqTransformSelectOpen sprite"></a></div><ul></ul>');
            var h = l("ul", f).css("width", s.width()).hide();
            l("option", this).each(function (u) {
                var v = l(this).html() == "" ? "&nbsp;" : l(this).html();
                var q = l('<li><a href="#" class="' + l(this).attr("class") + '" index="' + u + '">' + v + "</a></li>");
                h.append(q)
            });
            h.find("a").click(function () {
                l("a.selected", f).removeClass("selected");
                l(this).addClass("selected");
                if (s[0].selectedIndex != l(this).attr("index") && s[0].onchange) {
                    s[0].selectedIndex = l(this).attr("index");
                    s[0].onchange()
                }
                s[0].selectedIndex = l(this).attr("index");
                l("span:eq(0)", f).html(l(this).html());
                h.hide();
                return false
            });
            l("a:eq(" + this.selectedIndex + ")", h).click();
            l("span:first", f).click(function () {
                l("a.jqTransformSelectOpen", f).trigger("click")
            });
            var b = l("a.jqTransformSelectOpen", f).click(function () {
                if (h.css("display") == "none") {
                    k()
                } else {
                    h.hide();
                    return false
                }
                if (s.attr("disabled")) {
                    return false
                }
                h.slideToggle("fast", function () {
                    var q = (l("a.selected", h).offset().top - h.offset().top);
                    h.animate({
                        scrollTop: q
                    }, "fast")
                });
                return false
            });
            var c = s.outerWidth();
            var g = l("span:first", f);
            var r = (c > g.innerWidth()) ? c + b.outerWidth() : f.width();
            r = parseInt(f.css("width")) < r && parseInt(f.css("width")) != 35 ? parseInt(f.css("width")) : r;
            f.css("width", r);
            h.css("width", r - 2);
            g.css({
                width: c
            });
            h.css({
                display: "block",
                visibility: "hidden"
            });
            var a = (l("li", h).length) * (l("li:first", h).height());
            (a < h.height()) && h.css({
                height: a,
                overflow: "hidden"
            });
            h.css({
                display: "none",
                visibility: "visible"
            })
        })
    };
    l.fn.jqTransform = function (b) {
        var a = l.extend({}, i, b);
        return this.each(function () {
            var c = l(this);
            if (c.hasClass("jqtransformdone")) {
                return
            }
            c.addClass("jqtransformdone");
            if (l("select", this).jqTransSelect().length > 0) {
                p()
            }
            c.bind("reset", function () {
                var d = function () {
                        n(this)
                    };
                window.setTimeout(d, 10)
            })
        })
    }
})(jQuery);

$(document).ready(function () {
    $("form.fancy-form").jqTransform();
});
$.fn.jqTransformReApply = function () {
    $(this).each(function () {
        $(this).removeClass("jqtransformdone");
        $(this).jqTransform()
    })
};

</div>
<div id="footer-box">
<div id="footer" class="large">
    <div class="container">
      <div class="left">

      </div>
      <div class="middle vert_sprite">
        <div>
          <div class="content-left">
            <div style="width:450px" class="newsletter">
              <h3>What's New</h3>
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
            </div>
          </div>

        </div>
      </div>
      <div class="right vert_sprite">

      </div>
    </div>
    <div class="clear"></div>
  </div>
  <div id="copyright">
    <div class="container">
      <div class="powered-by-envato"> <a href="#" title="POWERED BY SILVER TOUCH">POWERED BY SILVER TOUCH </a> </div>
      <div class="copyright">
        <p> <span>COPYRIGHT (C) 2011 SILVER TOUCH TECHNOLOGIES LTD. | ISO 9001:2008 | ISO 20000:2005 | ISO 27001</span></p>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/ddaccordion.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript">
    $(function() {
        $('#gallery a').lightBox();
    });
	
	 $(function() {
        $('#gallery2 a').lightBox();
    });
	
	$("input.file_3").filestyle({ 
          image: "images/choose-file.png",
          imageheight : 33,
          imagewidth : 82,
          width : 150
      });
	$("input.file_4").filestyle({ 
          image: "images/choose-file.png",
          imageheight : 33,
          imagewidth : 82,
          width : 170
      });
		$("input.detail").filestyle({ 
          image: "images/choose-file.png",
          imageheight : 33,
          imagewidth : 82,
          width : 101
      });
		
				$("input.detail-last").filestyle({ 
          image: "images/choose-file.png",
          imageheight : 33,
          imagewidth : 82,
          width : 240
      });

    </script>
<script type="text/javascript">

	$(function() {

		$('.multiple_listmenu li input').click(function(){
			$(this).parent('li').toggleClass('active');
		});
		
		$('.multiple_listmenu li label').toggle(
			function () {
			$(this).parent('li').addClass('active');
				currentcheckbox = $(this).prev('input'); 
				$(currentcheckbox).attr('checked', true);
			},
			function () {
			$(this).parent('li').removeClass('active');
				currentcheckbox = $(this).prev('input'); 
				$(currentcheckbox).attr('checked', false);
			}
		);
		
	$('.all-attchment-box li input').click(function(){
			$(this).parent('li').toggleClass('active');
		});
		
		$('.all-attchment-box li label').toggle(
			function () {
			$(this).parent('li').addClass('active');
				currentcheckbox = $(this).prev('input'); 
				$(currentcheckbox).attr('checked', true);
			},
			function () {
			$(this).parent('li').removeClass('active');
				currentcheckbox = $(this).prev('input'); 
				$(currentcheckbox).attr('checked', false);
			}
		);	

	});
</script>
<script type="text/javascript" src="js/envato.js"></script>
<script type="text/javascript">
$(function(){
	//$("select").multiselect();
});
</script>
<script type="text/javascript" language="javascript" >$('#list li').mouseover(function(){ $('#action_'+this.id).show() });</script>
<script type="text/javascript" language="javascript">$('#list li').mouseout(function(){ $('#action_'+this.id).hide() });</script>
</body>
</html>
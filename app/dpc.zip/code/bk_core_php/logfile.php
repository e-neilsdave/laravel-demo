<?php
function logFile($msg = '') {
    $msg = $msg  . '<br/>';    
    global $fh;
    fwrite($fh, $msg);
}

function startLoging($myFile = "log") {
    //return;
    global $fh;
    $folder = 'E:/wamp/www/smtpmail_new/log/';
    //$folder = '/phpweb/html/komal/smtpemail/log/';
    $myFile = $folder . $myFile . '.html';
    //@copy( $myFile, 'log/log-backup-' . date('Y-m-d H-i-s') . '.html');
    @unlink($myFile);
    $fh = fopen($myFile, 'w') or print_r("can't open log file " . $myFile);
    //chmod($myFile, 777);
}

/**
 * Ending the process log - closes the file
 *
 * @return void
 */
function endLogging() {
    //return;
    global $fh;
    fclose($fh);
}
?>
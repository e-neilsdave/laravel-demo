<?php

/**
 * class Commonfunctions
 * To manipulate the frequently used functions through out the application which have no DB commnications
 */

class commonfunctions {

    private $obj;

    function __construct() {
        define('GLOBAL_PATH', site_url(array()));
        $arr = explode("/", site_url(array()));
        unset($arr[count($arr) - 2]);
		define('GLOBAL_PATH_WITHOUT_INDEXPHP', implode("/", $arr));
       // define('GLOBAL_PATH_IMG', implode("/", $arr) . '/img/');
        $this->obj = & get_instance();
		$this->checkLoginAndRedirect();
       
    }
	

    function checkLoginAndRedirect() {
        $currentController = $this->obj->router->class;
        $currentMethod = $this->obj->router->method;
       // echo $currentController.'_'.$currentMethod;
		
		// for admin pages
		if( ($currentController != 'admin' && $currentController.'_'.$currentMethod != 'home_logout' && $currentController.'_'.$currentMethod != 'emails_editregisteruser' )  && $this->obj->session->userdata('user_type') == 'admin' ) {
			$this->header_redirect(site_url(array('admin','index')));
		}
		
		// after login this page will not access
		$localPages = array('home_login','home_register');
		if ($this->obj->session->userdata('login_id') != '' && in_array($currentController . '_' . $currentMethod,$localPages)) { 
			$this->header_redirect(site_url(array('emails','index')));
		}
		
		
        $adminPages = array('admin');
        if(in_array($currentController,$adminPages) && $this->obj->session->userdata('user_type') != "admin")
        {
           // $this->header_redirect(site_url(array('guest_user','errorPage')));
            $this->header_redirect(site_url(array('home','login')));
        }
        
        // private pages
		$privatePages = array('emails_index','emails_import','emails_pay','emails_cartpage','guest_user_pricing','guest_user_index');
		
		if ($this->obj->session->userdata('login_id') == ''){
			if($currentController . '_' . $currentMethod == 'emails_cartpage'){
				if($this->obj->uri->segment(3) == 1){
					$this->header_redirect(site_url(array('home','register')));
				}else{
					$this->header_redirect(site_url(array('home','login')));
				}
			}
		}
		
        if(in_array($currentController . '_' . $currentMethod, $privatePages) && $this->obj->session->userdata('login_id') == "") {
            $this->header_redirect(site_url(array('home','login')));
        }
        
    }

    /**
     * function header_redirect
     * To redirect the page
     *
     * @param string $url
     * @return void
     */
    public function header_redirect($url, $forcefully_redirect = "") {
	    //ob_start();
		//
		if($forcefully_redirect == 'forcefully_redirect') {
		echo'
<script>
window.location.href = "'.$url.'";
</script>
';
		}else{
		header('Location: ' . $url);
		}
		
		exit;
    }

    /**
     * function sendMail
     * To send the email globally from the aplication
     *
     * @param string $to
     * @param string $from
     * @param string $subject
     * @param string $body
     * @param string $cc
     * @param string $bcc
     * @return array
     */
    public function sendMail($to, $from, $subject, $body, $cc = '', $bcc = '') {
          //return false;
//          echo $to;
//          echo '<br/>'.$from;
//          echo '<br/>'.$subject;
//          echo $body;
//          $headers = "From: " . strip_tags($from) . "\r\n";
//          $headers .= "Reply-To: ". strip_tags($from) . "\r\n";
//          $headers .= "MIME-Version: 1.0\r\n";
//          $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
//          mail($to,$subject,$body,$headers);
//          return true;

        /* Smtp : smtp.gmail.com
          Port:465 or 587
          Ssl required = Yes
          Authentication required = Yes
          Id : sitintranet@sitdistribution.ae
          Pwd : gridzgrup321! */

//        $fromName = $this->obj->session->userdata('username');
//        $fromEmail = $this->obj->session->userdata('useremail');
//
//        $body = str_replace('#REGARDS_NAME#', $fromName, $body);



        //Replace the links - start
        //$siteUrl = site_url(array());
//        $sql = "select 'http://192.168.1.20/sitdev/app/index.php/' as LIVE_LINK from IGM_USER_MASTER ";
//        $rs = $this->obj->db->Execute($sql);
//        $arrRes = $rs->GetRows();
//		$siteUrl = $arrRes[0]['LIVE_LINK'];
//        $body = str_replace('#AIRFARE_LISTAING_LINK#', $siteUrl . 'airfare', $body);
//        $body = str_replace('#CLAIM_REQUEST_LISTING_LINK#', $siteUrl . 'claimrequest', $body);
//        $body = str_replace('#CLAIM_REQUEST_LINK#', $siteUrl . 'claimrequest', $body);
//        $body = str_replace('#LEAVE_MANAGEMENT_LISTING_LINK#', $siteUrl . 'leavemanagement', $body);
//        $body = str_replace('#DOCUMENT_REQUEST_LISTING_LINK#', $siteUrl . 'documentrequest', $body);
//        $body = str_replace('#SALES_ORDERS_LISTING_LINK#', $siteUrl . 'salesorders', $body);
//        $body = str_replace('#APPRISAL_LISTING_LINK#', $siteUrl . 'apprisal', $body);
//        $body = str_replace('#CREDIT_LIMIT_LISTING_LINK#', $siteUrl . 'creditLimit', $body);
//        echo $body; exit;
        //Replace the links - complete


//        $loggedInUserEmailExists = true;
//        if (trim($fromName) == '') {
//                $fromName = 'SIT';
//        }
//        if (trim($fromEmail) == '') {
//                $loggedInUserEmailExists = false;
//                $fromEmail = 'noreply@sit.com';
//        }

        $mail = new PHPMailer();
        $mail->IsSMTP(); // send via SMTP
        //$mail->Host = "mail.sitdistribution.biz";
        $mail->Host = "silvermail.silvertouch.com";
        //$mail->Mailer = "smtp";
        //$mail->Port = 26;
        $mail->Port = 25;
        $mail->SMTPAuth = true; // turn on SMTP authentication
        //$mail->Username = "sitintranet@sitdistribution.biz"; // SMTP username
        $mail->Username = "aniket.dabgar@silvertouch.com"; // SMTP username
        //$mail->Password = "gridzgrup321!"; // SMTP password
        $mail->Password = "ADad@123"; // SMTP password
        $mail->SetFrom('aniket.dabgar@silvertouch.com', 'Aniket Dabgar<aniket.dabgar@silvertouch.com>');
//        $mail->From = $fromEmail;
//        $mail->FromName = $fromName;
        //echo '<br/>From email: ' . $fromEmail;
        //echo '<br/>From name: ' . $fromName;
        //$to = 'ravi.kotwani@silvertouch.com, sanjay.surani@silvertouch.com';

//        $toArr = explode(",", $to);
//        foreach ($toArr as $emailTo) {
//                if (trim($emailTo) != '') {
//                        $mail->AddAddress(trim($emailTo), '');
//                        //echo '<br/>To: ' . $emailTo;
//                }
//        }
//        $mail->AddReplyTo($fromEmail, $fromEmail);
//        //echo '<br/>Reply To: ' . $fromEmail;
//        if (!empty($cc)) {
//                $ccArr = explode(",", $cc);
//                foreach ($ccArr as $ccNew) {
//                        if (trim($ccNew) != '') {
//                                $mail->AddCC(trim($ccNew), '');
//                                //echo '<br/>CC: ' . $ccNew;
//                        }
//                }
//        }
//        if (!empty($bcc)) {
//                $bccArr = explode(",", $bcc);
//                foreach ($bccArr as $bccNew) {
//                        if (trim($bccNew) != '') {
//                                $mail->AddBCC(trim($bccNew), '');
//                                //echo '<br/>BCC: ' . $bccNew;
//                        }
//                }
//        }
//        if ($loggedInUserEmailExists) {
//                $mail->AddBCC(trim($fromEmail), '');
//                //echo '<br/>BCC: ' . $fromEmail;
//        }
//        $mail->WordWrap = 50; // set word wrap
        //$mail->AddAttachment("/tmp/image.jpg", "new.jpg"); // attachment
        $mail->IsHTML(true); // send as HTML
        $mail->Subject = $subject;
        //$mail->Body = $body; //HTML Body
        $mail->MsgHTML($body); //HTML Body
        $mail->AddAddress($to);
        if (!$mail->Send()) {
                //echo "<br/>Mailer Error: " . $mail->ErrorInfo;
                //echo "This is FROM: ";
                //echo $from;
                //exit;
        } else {
               //echo "<br/>Message has been sent";
        }

        /* echo '<br/>From name: ' . $mail->FromName;
          echo '<br/>From mail / Reply to: ' . $mail->From;
          echo '<br/>To : ' . $to;
          echo '<br/>CC : ' . $cc;
          echo '<br/>BCC : ' . $cc; */
        //exit;
    }

	
	function generatePassword($length = 8) {
        $password = "";
        $possible = "2346789bcdfghjkmnpqrtvwxyzBCDFGHJKLMNPQRTVWXYZ";
        $maxlength = strlen($possible);
        if ($length > $maxlength) {
            $length = $maxlength;
        }
        $i = 0; 
        while ($i < $length) { 
            $char = substr($possible, mt_rand(0, $maxlength-1), 1);
            if (!strstr($password, $char)) { 
                $password .= $char;
                $i++;
            }
        }
        return $password;
   }
	
    /**
     * function loadLanguageFiles
     * To load the language file from libraries for the selected lang (availavle in session)
     *
     * @return void
     */
     function loadLanguageFiles() {
        /* Check the sesison and redirect to login page if required - starts */
        $currentController = $this->router->class;
        $currentMethod = $this->router->method;
        
        /* Check the sesison and redirect to login page if required - comeplted */
        
       $langName = $this->session->userdata('login_language_name');
       if(trim($langName) == '') {
           //Load default language
        //   $this->load->model('language_model');
         //  $defaultLangDetails = $this->language_model->get_default_language_details();
           $langName = 'english';
       }
       
       //If a new language file is added, that file name should be added in bellow array
       $allLangFiles = array('general');
       
       //Load all the files for this language
       foreach($allLangFiles as $langFileName) {
           $this->lang->load($langFileName, $langName);
       }
    }
    
    /**
     * function displayDate
     * To display the date in global format of app mm.dd.yyyy
     * 
     * @param date: Y-m-d format
     * @return mm.dd.yyyy format
     */
    function displayDate($date) {
       $arr = explode('-', $date);
       $y = $arr[0];
       $m = $arr[1];
       $d = $arr[2];
       return $m . '.' . $d . '.' . $y;
    }
    
    /**
     * function dateForDB
     * To get the date in global DB format Y-m-d
     * 
     * @param date: mm.dd.yyyy format
     * @return Y-m-d format
     */
    function dateForDB($date) {
       $arr = explode('.', $date);
       $m = $arr[0];
       $d = $arr[1];
       $y = $arr[2];
       return $y . '-' . $m . '-' . $d;
    }
    
    /**
     * function displayLangVar
     * To display the variable in current available lang or in global language of app (if not available in current lang)
     * 
     * @param string $varInBrowsingLang
     * @param string $varInStanderedLang
     * @return string
     */
    function displayLangVar($varInBrowsingLang = '', $varInStanderedLang = '') {
       //If browsing lang variable is available then directly display it 
       if(trim($varInBrowsingLang) != '') {
           return $varInBrowsingLang;
       } else {
           if(trim($varInStanderedLang) == '') {
               $varInStanderedLang = $varInBrowsingLang;
           }
           return $varInStanderedLang;
       }
    }
    
    /**
     * function pr
     * To print array AND optional exit
     * 
     * @param array $arr
     * @param bool $exit
     * @return void
     */
    public function pr($arr, $exit = false) {
       echo '<pre>';
       print_r($arr);
       echo '</pre>';
       if($exit) {
           exit;
       }
    }
		
	function custom_pagination($per_page = 10, $page = 1, $url = '', $total,$count){
		///echo $count." and ".$total;
		
		
		$adjacents = "2";

		$page = ($page == 0 ? 1 : $page);
		$start = ($page - 1) * $per_page;

		$prev = $page - 1;
		$next = $page + 1;
		if($per_page == -1){
		$lastpage = ceil($total/$total);
		}else {
		$lastpage = ceil($total/$per_page);
		}
		$lpm1 = $lastpage - 1;

		$pageStartRecord = ($start + 1);

		if($count < $per_page){
			$pageLastRecord = $total;
		}else{
			if($per_page < 0){
			$pageLastRecord = $total;
			}else{
			$pageLastRecord = ($start + $per_page);
			}
		}
		
		$pagination = "";
		if($total == 0){
			$pagination = "<p class='page_items'>NO ITEMS</p>";
		}else{
			$pagination = "<p class='page_items'>$pageStartRecord - $pageLastRecord OF $total ITEMS</p>";
		}
		$pagination .= "<div class='page_numbers'>
		<span class='page-first'>PAGE</span>";
		if($lastpage > 1)
		{
		//$pagination .= "<ul class='pagination'>";
		//$pagination .= "<li class='details'>Page $page of $lastpage</li>";
		if ($lastpage < 7 + ($adjacents * 2))
		{
		for ($counter = 1; $counter <= $lastpage; $counter++)
		{
		if ($counter == $page)
		$pagination.= "<li><a class='active'>$counter</a></li>";
		else
		$pagination.= "<li><a href='{$url}$counter'>$counter</a></li>";
		}
		}
		elseif($lastpage > 5 + ($adjacents * 2))
		{
		if($page < 1 + ($adjacents * 2))
		{
		for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
		{
		if ($counter == $page)
		$pagination.= "<li><a class='active'>$counter</a></li>";
		else
		$pagination.= "<li><a href='{$url}$counter'>$counter</a></li>";
		}
		$pagination.= "<li class='dot'>...</li>";
		$pagination.= "<li><a href='{$url}$lpm1'>$lpm1</a></li>";
		$pagination.= "<li><a href='{$url}$lastpage'>$lastpage</a></li>";
		}
		elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
		{
		$pagination.= "<li><a href='{$url}1'>1</a></li>";
		$pagination.= "<li><a href='{$url}2'>2</a></li>";
		$pagination.= "<li class='dot'>...</li>";
		for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
		{
		if ($counter == $page)
		$pagination.= "<li><a class='active'>$counter</a></li>";
		else
		$pagination.= "<li><a href='{$url}$counter'>$counter</a></li>";
		}
		$pagination.= "<li class='dot'>..</li>";
		$pagination.= "<li><a href='{$url}$lpm1'>$lpm1</a></li>";
		$pagination.= "<li><a href='{$url}$lastpage'>$lastpage</a></li>";
		}
		else
		{
		$pagination.= "<li><a href='{$url}1'>1</a></li>";
		$pagination.= "<li><a href='{$url}2'>2</a></li>";
		$pagination.= "<li class='dot'>..</li>";
		for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
		{
		if ($counter == $page)
		$pagination.= "<li><a class='active'>$counter</a></li>";
		else
		$pagination.= "<li><a href='{$url}$counter'>$counter</a></li>";
		}
		}
		}

		if ($page < $counter - 1){
		$pagination.= "<li><a href='{$url}$next'>&gt;</a></li>";
		// $pagination.= "<li><a href='{$url}$lastpage'>Last</a></li>";
		}else{
		//$pagination.= "<li><a class='active'>Next</a></li>";
		// $pagination.= "<li><a class='active'>Last</a></li>";
		}
		//$pagination.= "</ul>\n";
		} else {
		if($total == 0) { 
			$pagination.= "<li><a class='active'>1</a></li>";
		} else {
			$pagination.= "<li><a class='active'>$lastpage</a></li>";
		}
		//$pagination.= "<li><a href=''></a></li>";
		}

		$pagination .= "</div>";


		return $pagination;
	}
		
		
	function exportMysqlToCsv($sql_query,$filename = 'export.csv'){
		//echo $sql_query;exit;
		$csv_terminated = "\n";
		$csv_separator = ",";
		$csv_enclosed = '"';
		$csv_escaped = "\\";
		
		//$sql_query = "select * from $table";
		// Gets the data from the database
		$result = mysql_query($sql_query);
		$fields_cnt = mysql_num_fields($result);
		$schema_insert = '';
		for ($i = 0; $i < $fields_cnt; $i++)
		{
			$l = $csv_enclosed . str_replace($csv_enclosed, $csv_escaped . $csv_enclosed,
			stripslashes(mysql_field_name($result, $i))) . $csv_enclosed;
			$schema_insert .= $l;
			$schema_insert .= $csv_separator;
		} // end for

		$out = trim(substr($schema_insert, 0, -1));
		$out .= $csv_terminated;
		// Format the data
		while ($row = mysql_fetch_array($result))
		{
			$schema_insert = '';
			for ($j = 0; $j < $fields_cnt; $j++)
			{
				if ($row[$j] == '0' || $row[$j] != '') {
					if ($csv_enclosed == '') {
						$schema_insert .= $row[$j];
					} else 	{
						$schema_insert .= $csv_enclosed .
						str_replace($csv_enclosed, $csv_escaped . $csv_enclosed, $row[$j]) . $csv_enclosed;
					}
					
				} else {
						$schema_insert .= '';
				}
					
				if ($j < $fields_cnt - 1) {
					$schema_insert .= $csv_separator;
				}
			}
			// end for
			$out .= $schema_insert;
			$out .= $csv_terminated;
		} // end while
		
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		header("Content-Length: " . strlen($out));
		// Output to browser with appropriate mime type, you choose ;)
		header("Content-type: text/x-csv");
		//header("Content-type: text/csv");
		//header("Content-type: application/csv");
		header("Content-Disposition: attachment; filename=$filename");
		echo $out;
		exit;
	}
	
   
	function activeClass(){
		// for home page
		$currentController = $this->obj->router->class;
		$currentMethod = $this->obj->router->method;	
		
		$rule = $currentController."_".$currentMethod;
		
		//echo $rule;
		$activemenu = 'home';
    
        switch ($rule) {
            case 'guest_user_index':
				$activemenu = 'home';
				break;
           
		   case 'guest_user_feature':
				$activemenu = 'feature';
                break;
			case 'guest_user_pricing':
				$activemenu = 'pricing';
                break;

			case 'guest_user_help':
				$activemenu = 'help';
                break;				
				
			case 'home_register':
				$activemenu = 'register';
                break;
			case 'home_login':
				$activemenu = 'login';
                break;
			case 'home_forgotpassword':
				$activemenu = 'forgotpassword';
                break;
				
			case 'emails_index':
				$activemenu = 'managa_account';
                break;
			
			case 'emails_dashbord':
				$activemenu = 'dashbord_account';
				break;
			
			case 'emails_myorderdetails':
				$activemenu = 'transection_account';
				break;
				
			case 'emails_import':
				$activemenu = 'managa_account';
                break;
				
			case 'emails_editregisteruser':
				$activemenu = 'edit_user';
                break;

			case 'admin_index':
				$activemenu = 'dashbord';
                break;

			case 'admin_userlist':
				$activemenu = 'dashbord';
                break;
				
			case 'admin_price_setting':
				$activemenu = 'dashbord';
                break;

			case 'admin_emailtemplatelist':
				$activemenu = 'dashbord';
                break;
			
			case 'admin_emailTemplate':
				$activemenu = 'dashbord';
                break;	

			case 'admin_transectiondetail':
				$activemenu = 'dashbord';
                break;			
        }
		
        if($activemenu) {
            return $activemenu;
        }
    
	}
	
	function pdfHtml($txnDetails){
		
		//echo "txn data = <pre>";print_r($txnDetails);
		//echo date('d F, Y',strtotime($txnDetails->payment_date))."<br />";
		//echo date('G:i:s T',strtotime($txnDetails->payment_date));
		
		//exit;
	
		$html = '<table width="600" style="margin:15px auto; border:1px solid #d6d6d6; font-family:Arial, Helvetica, sans-serif; padding:20px 20px 0;" border="0" cellspacing="0" cellpadding="0">
		<tr>
		<td align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
			  <td colspan="2" align="left" valign="top" ><a href="#" title="Email Validator"><img src="'.GLOBAL_PATH_WITHOUT_INDEXPHP.'images/email-logo.png" alt="Email Validator" style="border:0;" /></a></td>
			  <td align="left" valign="top" style="font-family:Arial, Helvetica, sans-serif; font-size:11pt; color:#666; padding-top:5px; text-align:right;">
				Date : '.date('d F, Y').'<br />
				Time : '.date('G:i:s T').'
			  </td>
			</tr>
		  </table></td>
		</tr>
		<tr>
		<td height="15"></td>
		</tr>
		<tr>
		<td align="left" valign="top"><table width="560" border="0" style="background:#f0f0f0; border:1px solid #d6d6d6;" cellspacing="0" cellpadding="0">
			<tr>
			  <td style="padding:20px;font-family:Arial, Helvetica, sans-serif;font-size:12pt; color:#333;">
				<table  width="100%" border="0" cellspacing="0" cellpadding="0">
					<tr>
						<td valign="top" style="padding-bottom:15px;font-size:12pt; color:#333; line-height:18pt; margin:0;">Dear <strong>'.$txnDetails->username.'&nbsp;'.$txnDetails->lastname.'</strong>,</td>
					</tr>
					<tr>
						<td>
									Thanks for purchasing subscripton for Email Validator.	
						</td>
					</tr>
					<tr>
						<td height="15"></td>
					</tr>
					<tr>
						<td style="">
							<strong>Package Details</strong><br /><br />
							<table  width="100%" border="0" cellspacing="0" cellpadding="10" style="border:1px solid #f0f0f0;background:#fff;">
								<tr>
									<td width="210" style="border-bottom:1px solid #f0f0f0"><strong>Package Name :</strong> </td>
									<td style="border-bottom:1px solid #f0f0f0">'.ucfirst($txnDetails->item_name).'</td>
								</tr>
								<tr>
									<td style="border-bottom:1px solid #f0f0f0"><strong>Date Time :</strong> </td>
									<td style="border-bottom:1px solid #f0f0f0">'.date('F d, Y  H:i:s', strtotime($txnDetails->payment_date)).'</td>
								</tr>
								<tr>
									<td style="border-bottom:1px solid #f0f0f0"><strong>Invoice ID/Transaction ID :</strong> </td>
									<td style="border-bottom:1px solid #f0f0f0">'.$txnDetails->txn_id.'</td>
								</tr>
								<tr>
									<td style="border-bottom:1px solid #f0f0f0"><strong>Number of Emails :</strong> </td>
									<td style="border-bottom:1px solid #f0f0f0">'.$txnDetails->no_of_mail.' Emails</td>
								</tr>
								<tr>
									<td style="border-bottom:1px solid #f0f0f0"><strong>Price :</strong> </td>
									<td style="border-bottom:1px solid #f0f0f0">$'.$txnDetails->mc_gross.'</td>
								</tr>
								<tr>
									<td><strong>Valid Upto :</strong> </td>
									<td>'.date('F d, Y H:i:s', strtotime($txnDetails->payment_enddate)).'</td>
								</tr>
							</table>        	
						</td>
					</tr>
					<tr>
						<td height="15"></td>
					</tr>
					<tr>
						<td>
						<strong>Regards,</strong><br />
						Silver Touch<br />
						<a href="http://www.silvertouch.com" title="www.silvertouch.com" style="font-size:12pt; color:#333; text-decoration:none;" target="_blank">www.silvertouch.com</a>
						</td>
					</tr>
				</table>
			  </td>
			</tr>
		  </table></td>
	  </tr>
	  <tr>
		<td align="center" valign="middle" style="font-size:11pt; color:#666; height:35px;">Copyright &copy; '.date('Y').' Email Validator. All rights reserved.</td>
	  </tr>
	</table>';
	
	return $html;
	
	}

	function sendMailWithEmailTemplate($bodyTemp , $replacement = array()){
			
			//echo "array = <pre>";print_r($bodyTemp);
			
			if (count($replacement) > 0) {
                foreach ($replacement as $Find => $Replace) {
                    $bodyTemp->description = str_replace($Find, $Replace, $bodyTemp->description);
                }
            }
	
			$html = '<html xmlns="http://www.w3.org/1999/xhtml">
					<head>
					<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
					<title>Email Validator</title>
					</head>
					<body style="margin:0; padding:0;">
					<table width="600" style="margin:15px auto; border:1px solid #d6d6d6; font-family:Arial, Helvetica, sans-serif; padding:20px 20px 0;" border="0" cellspacing="0" cellpadding="0">
					  <tr>
						<td align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr>
							  <td colspan="2" align="left" valign="top" ><a href="#" title="Email Validator"><img src="'.GLOBAL_PATH_WITHOUT_INDEXPHP.'images/email-logo.png" alt="Email Validator" style="border:0;" /></a></td>
							  <td align="left" valign="top" style="font-family:Arial, Helvetica, sans-serif; font-size:11pt; color:#666; padding-top:5px; text-align:right;">
								Date : '.date('d F, Y').'<br />
								Time : '.date('G:i:s T').'
							  </td>
							</tr>
						  </table></td>
					  </tr>
					  <tr>
						<td height="15"></td>
					  </tr>
					  <tr>
						<td align="left" valign="top"><table width="560" border="0" style="background:#f0f0f0; border:1px solid #d6d6d6;" cellspacing="0" cellpadding="0">
							<tr>
							  <td style="padding:20px;font-family:Arial, Helvetica, sans-serif;font-size:12pt; color:#333;">
								' . $bodyTemp->description . '
										
						</td>
						</tr>
					  </table></td>
				  </tr>
				  <tr>
					<td align="center" valign="middle" style="font-size:11pt; color:#666; height:35px;">Copyright &copy; '.date('Y').' Email Validator. All rights reserved.</td>
				  </tr>
				</table>
				</body>
				</html>';
				//echo "contact us = ".$html;exit;
				return $html;
	}
	
}
?>
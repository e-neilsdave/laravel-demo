<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Checkemailapi extends CI_Controller {

    /**
	* 
    * Index Page for this controller.
    * 
    */
    
    function __construct() {
        parent::__construct();
		Commonfunctions::loadLanguageFiles();
    }
    
    public function index() {
        $data = array();
		// get api code and emails 
		$this->load->library('smtp_validateemail');
		$checkEmails = json_decode($_GET['email']); //explode(',',json_decode($_GET['email']));
		echo "<pre>";print_r($checkEmails);
		$emails = $checkEmails; //array('user@example.com', 'user2@example.com');
		$sender = 'jigar.prajapati@mydomain.com';
		$SMTP_Validator = new SMTP_validateEmail();
		$results = $SMTP_Validator->validate($emails, $sender);
		foreach($results as $email=>$result) {
				$status = ($result) ? 'Valid' : 'Invalid';
				echo "<br />";
				echo $email . ' is ' .$status."<br />";
		}                                     
		
	}
	
	
	
}

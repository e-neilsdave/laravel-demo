<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Emails extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     */
    
    function __construct() {
        parent::__construct();
		Commonfunctions::loadLanguageFiles();
    }
    
    public function index() {
        $data = array();
		//unset message
        $this->load->model('emails_model');
		$getData = $this->input->get();
		$userid = $this->session->userdata('login_id');

		if(isset($getData['checkbox']) && $getData['checkbox']!=''){
			$Checkboxarray = implode("','",$getData['checkbox']);
			$query = "select * from emaillist where id in ('".$Checkboxarray."') order by id desc";
			$this->commonfunctions->exportMysqlToCsv($query);
		} 
		
		if(count($getData['checkbox']) < 0){
		$errorMSG = array('errorMsg' => 'Please select the emails for export!!');
		$this->session->set_userdata($errorMSG);
		}
		
		//Records per page
		if(isset($getData['sort_by']) && $getData['sort_by']!=''){
			$limit=$getData['sort_by'];
		} else {
			$limit=25;
		}
		
		$page=1;
		
		$wheres = array();
		// get the status
		if(isset($getData['status']) && $getData['status']!=''){
			$status=$getData['status'];
			$wheres[] = "status = '".$getData['status']."'";
		} else {
			$status = "";
		}
		
		//get the search var
		if(isset($getData['search']) && ($getData['search'] != 'Search Emails...' || $getData['search'] == '')){
			$searchvar = $getData['search'];
			$wheres[] = "email like '%".$getData['search']."%'";
		} else {
			$searchvar = "Search Emails...";
		}	
		$wheres[] = "userid = ".$userid;	
		if(count($wheres) > 0){
			$where = implode(' AND ',$wheres);
		} else{
			$where = "userid = ".$userid;
		}
		
		$start=0; 
		
		if(isset($getData['page']) && $getData['page']!=''){
			$page=$getData['page'];
		}
		
		$start = ($page-1)*$limit;

		$totalUser = $this->emails_model->get_all_email($where);
		$rows = count($totalUser);
		
		if($limit < 0){
			$data['allusers'] = $this->emails_model->get_all_emails($where);
		} else {
			$data['allusers'] = $this->emails_model->get_all_emails($where,$start,$limit);
		}
		
		$countRecord = count($data['allusers']);
		$data['pagi_data'] = $this->commonfunctions->custom_pagination($limit,$page,site_url(array('emails','index?sort_by='.$limit.'&search='.$searchvar.'&status='.$status.'&page=')),$rows,$countRecord);
		$data['start'] = $start;
		
		
		// get the points
		$userid = $this->session->userdata('login_id');
		$data['points'] = $this->emails_model->getPoints($userid);
		$data['privateKeys'] = $this->emails_model->getPrivateKeys($userid);
		$data['membershiptype'] = $this->emails_model->getMembershipType($userid);
		
		$data['enabledbreadPanels'] = array('bredcrum_home');
		$data['enabledSidePanels'] = array('sidebar_points');
		$this->layout->view('emails/index',$data);
    }
	
	function dashbord(){
		$data = array();
		//$data['enabledbreadPanels'] = array('bredcrum_admin_dashbord');
        $this->layout->view('emails/dashbord',$data);
	}
	
	public function import() {
		$data = array();
		
		//load library
		$this->load->library('smtp_validateemail');
		$this->load->model('emails_model');
		
		$postData = $this->input->post();
		$getData = $this->input->get();
		
		$userid = $this->session->userdata('login_id');
		$data['points'] = $this->emails_model->getPoints($userid);
		
		
		
		$data['privateKeys'] = $this->emails_model->getPrivateKeys($userid);
		$data['perdaylimit'] = $this->emails_model->getPerDayLimit($userid);
				
		// get pricing_details
		$data['priceDetails'] = $this->emails_model->getLimitPriceDetail($data['points']->membership_type);
		
		$emailsValidator = explode(',',rtrim($postData['emailString'],','));
		$SMTP_Validator = new SMTP_validateEmail();
		
		if(isset($postData) && $postData['emailString'] != '' ){
			
			$validemails = $emailsValidator;
			$sender = 'user@yourdomain.com';
			$results = $SMTP_Validator->validate($validemails, $sender);	
		
			$resultCount = count($validemails);
			
			// create array for all added emails in csv
			$rd_validemails = array();
			
			for($i=0; $i < count($validemails); $i++){
				$rd_validemails[$i]['email'] = $validemails[$i];
				$rd_validemails[$i]['result'] = $results[$validemails[$i]];
			}
			//echo "array = <pre>";print_R($rd_validemails);exit;
			$insertdata = $this->emails_model->insertEmailsBulk($rd_validemails);
			ob_clean();
			if($insertdata != ""){
				$remainPoint = $data['points']->point - $resultCount;
				$insertPoint = $this->emails_model->updatePoints($remainPoint);
				
				// genret log for single email validation
				$genratArray = array();
				$i = 0;
				
				for($i=0; $i < count($validemails); $i++){
					$statusLog = ($results[$validemails[$i]]) ? 'Valid' : 'Invalid';
				
					$genratArray[$i]['userid'] = $this->session->userdata('login_id');
					$genratArray[$i]['ipaddress'] = $_SERVER['REMOTE_ADDR'];
					$genratArray[$i]['domain'] = $_SERVER['HTTP_HOST'];
					$genratArray[$i]['platform'] = "manually";
					$genratArray[$i]['email'] = $validemails[$i];
					$genratArray[$i]['email_result'] = $statusLog;
					$genratArray[$i]['date']  = date('Y-m-d h:i:s');
					$genratArray[$i]['req_status'] = "1";
					$genratArray[$i]['req_message'] = "sucessfully";
				}
				
				$genrateLog = $this->emails_model->genrateLogs($genratArray);
				$this->session->set_userdata(array('successMessage' => "Email Validation process completed. Please see below for validation status."));
				
				echo '1';
			} else {
				echo '0';
			}
			exit;
		}
		
		if(isset($postData['cancel']) && $postData['cancel'] !=''){
			$this->commonfunctions->header_redirect(site_url() . '/emails/index');
		}
		
		if(isset($postData['importdata'])){
			if ($_FILES["file_csv"]["error"] > 0){
					$data['errorMsg'] = " Please select the CSV file";
			}
			
			if(isset($_FILES['file_csv']['name']) && $_FILES['file_csv']['name'] != '' ){
				$rest = substr($_FILES["file_csv"]["name"], -3);
				if (( ($rest == "csv") || ($rest == "CSV")) ) {
					$validemails = array();
					$finalcnt = 0;
					$row = 1;
					$error = false;
					if (($handle = fopen($_FILES["file_csv"]["tmp_name"], "r")) !== FALSE) {
						
						while (($datacsv = fgetcsv($handle, 1000, ",")) !== FALSE) {
							$num = count($datacsv);
							
							if($row == 1 && $datacsv[0] != 'Email_Address')
							{
								$error = 'Invalid CSV';
								break;
							}
							
							if($row != 1)
							{
								if(trim($datacsv[0]) != '')
								{
									$validemails[] =  $datacsv[0];
									unset($datacsv[0]);
									if(!empty($datacsv))
									{
										$error = 'Invalid CSV';
										break;
									}
								}
								else
								{
									$error = 'Invalid CSV';
									break;
								}
							}
							$row++;
						}
						fclose($handle);
					}
					
					if(trim($error) == false){
						$emailCounterLimit = count($validemails);
						
						array_shift($validemails ); //$validemails_passed
					//	$validemails_passed = array_map('trim',$validemails_passed);
						$validemails = array_map('trim',$validemails);
						
						$validemails_unique = array_unique($validemails);
						//echo "unique = <pre>";
						//print_r($validemails_unique);
						// CSV for standerd and profesional user
						// method 2 is for web service
						// methos 1 is for bulk 
						if($data['priceDetails']->method == 2){
							
							// Bulk limit for standerd and profesional user
							if($emailCounterLimit <= $data['priceDetails']->bulk_limit){
								
								// if csv emails is more then points the show error you cant upload more emails
								if($emailCounterLimit <= $data['points']->point ){
								
									$sender = 'user@yourdomain.com';
									$results = $SMTP_Validator->validate($validemails_unique, $sender);
									//echo "result = <pre>";
									//print_r($results);
									// create array for all added emails in csv
									$rd_validemails = array();
									
									for($i=0; $i < count($validemails); $i++){
									 $rd_validemails[$i]['email'] = $validemails[$i];
									 $rd_validemails[$i]['result'] = $results[$validemails[$i]];
									}
									//echo "passed = <pre>";
									//print_r($rd_validemails);exit;
									$insertdata = $this->emails_model->insertEmailsBulk($rd_validemails);
									if($insertdata != ""){
										
										//update points
										$remainPoint = $data['points']->point - $emailCounterLimit;
										$insertPoint = $this->emails_model->updatePoints($remainPoint);
										
										// generate log
										$genratArrayCSV = array();
										for($iG=0; $iG < count($validemails); $iG++){
											$statusLog = ($results[$validemails[$i]]) ? 'Valid' : 'Invalid';
											$genratArrayCSV[$iG]['userid'] = $this->session->userdata('login_id');
											$genratArrayCSV[$iG]['ipaddress'] = $_SERVER['REMOTE_ADDR'];
											$genratArrayCSV[$iG]['domain'] = $_SERVER['HTTP_HOST'];
											$genratArrayCSV[$iG]['platform'] = "csv_bulk";
											$genratArrayCSV[$iG]['email'] = $validemails[$iG];
											$genratArrayCSV[$iG]['email_result'] = $statusLog;
											$genratArrayCSV[$iG]['date']  = date('Y-m-d H:i:s');
											$genratArrayCSV[$iG]['req_status'] = "1";
											$genratArrayCSV[$iG]['req_message'] = "sucessfully";
										}
										
										// generate a log
										$genrateLogCSV = $this->emails_model->genrateLogs($genratArrayCSV);
										
										$this->session->set_userdata(array('successMessage' => "Emails are inserted"));
										$this->commonfunctions->header_redirect(site_url(array('emails','index')));
										
									} else{
										$this->session->set_userdata(array('successMessage' => "Emails are not inserted preoperly!"));
									}		
								} else {
									$this->session->set_userdata(array('errorMessage' => "you can not import more then ".$data['points']->point." emails"));
									$this->commonfunctions->header_redirect(site_url(array('emails','index')));
								}
								
							} else {
								$data['errorMsg'] = "you can not import more then ".$data['priceDetails']->bulk_limit." emails in CSV file";
							}
						}
						
						// methos 1 is for bulk limit
						if($data['priceDetails']->method == 1){
							
							// check bulk limit
							if($emailCounterLimit <= $data['priceDetails']->bulk_limit){
								
								// if csv emails is more then points the show error you cant upload more emails
								if($emailCounterLimit <= $data['points']->point  ){
								
									$sender = 'user@yourdomain.com';
									$results = $SMTP_Validator->validate($validemails_unique, $sender);
									$r_validemails = array();
								//	echo "results - <pre>";print_R($validemails);
									for($i=0; $i < count($validemails); $i++){
									 $r_validemails[$i]['email'] = $validemails[$i];
									 $r_validemails[$i]['result'] = $results[$validemails[$i]];
									}
								
									$insertdata = $this->emails_model->insertEmailsBulk($r_validemails);
								
									if($insertdata != ""){
										// update points
										$remainPoint = $data['points']->point - $emailCounterLimit;
										$insertPoint = $this->emails_model->updatePoints($remainPoint);
											
										// generate log
										$genratArrayCSVM = array();
										$iGM = 0;
										for($iGM=0; $iGM < count($validemails); $iGM++){
											$statusLog = ($results[$validemails[$i]]) ? 'Valid' : 'Invalid';
											$genratArrayCSVM[$iGM]['userid'] = $this->session->userdata('login_id');
											$genratArrayCSVM[$iGM]['ipaddress'] = $_SERVER['REMOTE_ADDR'];
											$genratArrayCSVM[$iGM]['domain'] = $_SERVER['HTTP_HOST'];
											$genratArrayCSVM[$iGM]['platform'] = "csv_bulk";
											$genratArrayCSVM[$iGM]['email'] = $validemails[$iGM];
											$genratArrayCSVM[$iGM]['email_result'] = $statusLog;
											$genratArrayCSVM[$iGM]['date']  = date('Y-m-d H:i:s');
											$genratArrayCSVM[$iGM]['req_status'] = "1";
											$genratArrayCSVM[$iGM]['req_message'] = "sucessfully";
										}
										
										// insert log
										$genrateLogCSVM = $this->emails_model->genrateLogs($genratArrayCSVM);									
										// set success message in session
										$this->session->set_userdata(array('successMessage' => "Emails are inserted"));
										$this->commonfunctions->header_redirect(site_url(array('emails','index')));
									} else{
										$this->session->set_userdata(array('successMessage' => "Emails are not inserted preoperly!"));
									}		
								}else{
									$this->session->set_userdata(array('errorMessage' => "you can not import more then ".$data['points']->point." emails"));
									$this->commonfunctions->header_redirect(site_url(array('emails','index')));
								}
								
							} else {
								$data['errorMsg'] = "you can not import more then ".$data['priceDetails']->bulk_limit." emails in CSV file";
							}
						}
						
						// methos 0 is for free
						if($data['priceDetails']->method == 0){
							$data['errorMsg'] = "you can not import CSV file";
						}
					}else{
						$data['errorMsg'] = "Please import a proper CSV file!!";
					}
					
				} else {
					$data['errorMsg'] = "Please import a CSV file!!";
				}
				
			}
		}
		$data['membershiptype'] = $this->emails_model->getMembershipType($userid);
		
		$data['enabledbreadPanels'] = array('bredcrum_import');
		$data['enabledSidePanels'] = array('sidebar_points');
		$this->layout->view('emails/import_data',$data);
    }
	
	
	public function editregisteruser() {
		
        $data = array();
		$data['editid'] = $this->session->userdata('login_id');
		$data['postData'] = $this->input->post();
		
		$this->load->model('user_model');
		$this->load->model('emails_model');
		
		$userid = $this->session->userdata('login_id');
		$data['privateKeys'] = $this->emails_model->getPrivateKeys($userid);
		if($data['editid'] != '' && $data['editid'] != '0') {
            $data['editData'] = $this->user_model->get_user_details($data['editid'], 'array');
            if(!isset($data['postData']['username'])) {
                $data['postData'] = $data['editData'];
            }
        }

        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
      
        $this->form_validation->set_rules('username', array('required' => 'lang:general_enter_user_name'), 'required');

       // $this->form_validation->set_rules('email', array('required' => 'lang:general_enter_email', 'valid_email' => 'lang:general_enter_valid_email', 'is_unique' => 'lang:general_email_exists'), 'required|valid_email|is_unique[users.email.'.$data['finalEditId'].']');
		
		//if($data['editid'] != '' && $data['editid'] != '0') {
        //    $this->form_validation->set_rules('password', array('matches' => 'lang:general_password_not_match'), 'matches[confirm_password]');
      //  } else {
			$this->form_validation->set_rules('password', array('required' => 'lang:general_enter_password', 'matches' => 'lang:general_password_not_match'), 'required|matches[confirm_password]');
            $this->form_validation->set_rules('confirm_password', array('required' => 'lang:general_enter_confirm_password'), 'required');
     //   }
	
        $this->form_validation->set_error_delimiters('<span class="errorMessage">', '</span>');
    	if ($this->form_validation->run() == TRUE && isset($data['postData']['subscribe'])) {			
			$userUpdate['id'] = $data['editid'];
			$userUpdate['`username`'] = $data['postData']['username'];
			$userUpdate['`password`'] = MD5($data['postData']['password']);
			$statId = $this->user_model->globalUpdate('users', $userUpdate);
			
			// username session value update
			$this->session->set_userdata(array('login_username' => $data['postData']['username']));
			
			$this->session->set_userdata(array('successMessage' => "User Data Updated"));
			$this->commonfunctions->header_redirect(site_url() . '/emails/editregisteruser');    
        }
		$data['membershiptype'] = $this->emails_model->getMembershipType($userid);
		$data['points'] = $this->emails_model->getPoints($userid);
		$data['enabledbreadPanels'] = array('bredcrum_editaccount');
		$data['enabledSidePanels'] = array('sidebar_points');
        $this->session->set_userdata($cdata);
        $this->layout->view('emails/register_edituser',$data);
    }
	
	public function cartpage(){
		$data = array();
		$this->load->model('emails_model');
		$priceId = $_POST['username'];
		//$priceId = $this->uri->segment(3);
		//echo "hi = ".$priceId;
		$data['priceDetails'] = $this->emails_model->getPriceDetails($priceId);
		//echo "<pre>";print_r($data['priceDetails']);
		
		$cartpageHtml = $this->emails_model->htmlCartPage($data['priceDetails']);
    	echo $cartpageHtml;
		
		//echo $this->layout->view('emails/cartpage',$data);
	}
	
	public function paypalForm(){
		$data = array();
		$this->load->model('emails_model');
		$priceId = $this->uri->segment(3);
		$data['priceDetails'] = $this->emails_model->getPriceDetails($priceId);
		$this->layout->view('emails/paypalform',$data);
	}
	
	public function thankyou(){
	
		$data = array();
		$this->load->model('user_model');
		$this->load->model('emails_model');
		$postdata = $this->input->post();
		$postdata['userid'] = $this->session->userdata('login_id');
		
		//get membership detail id 
		$membershipid = $this->uri->segment(3);
		
		// get the users points and membership
		$pointDetails = $this->emails_model->getPoints($postdata['userid']);
		//echo "<pre>";print_R($postdata);
		//echo "membership id = ".$membershipid;
		//echo "point id = ".$pointDetails;
		
		//exit;
		if(isset($postdata) && $postdata['payment_status'] != ''){
			// insert transaction details
			$txnDetails = $this->emails_model->insertTxnID($postdata);
			
			
			
			
			
			if($txnDetails == '0'){
				$data['message'] = "<p style='color:red'>Your transaction  incomplited, Please try again</p>";
			} else {
				
				$ValidityDetails = $this->emails_model->getValidity($membershipid);
				
				//update points and membership_type	
				$pointUpdate['`userid`'] = $this->session->userdata('login_id');
				$pointUpdate['`point`'] = $pointDetails->point + $postdata['option_selection1'];
				$pointUpdate['`membership_type`'] = $membershipid;//$postdata['item_name'];
				
				$pointUpdate['`start_date`'] = $ValidityDetails['start_date'];//$postdata['item_name'];
				$pointUpdate['`end_date`'] = $ValidityDetails['end_date'];//$postdata['item_name'];
				
				$statId = $this->emails_model->globalUpdate('emailpoints', $pointUpdate);	
				
				$data['message'] = "<p style='color:green'>Your transaction completed successfully</p>";
				
				// txn details mail
				//Send mail
						
				$bodyTemp = $this->user_model->getEmailBody('membership_detail');
				$replacement = array(
								'#username#' => $this->session->userdata('login_username'),
								'#membership#' => $postdata['item_name'],
								'#date#' => date('F d, Y  H:i:s', strtotime($pointUpdate['`start_date`'])),
								'#txnid#' => $postdata["txn_id"],
								'#noEmails#' => $postdata["option_selection1"],
								'#amount#' => $postdata["mc_gross"],
								'#dateupto#'=> date('F d, Y  H:i:s', strtotime($pointUpdate['`end_date`'])),);
				$html = $this->commonfunctions->sendMailWithEmailTemplate($bodyTemp , $replacement);
				
			//	echo "Body HTML = ".$html;
			//	exit;	
				
				$subject = $bodyTemp->subject;
				$to = $this->session->userdata('login_email');
				/*
				echo "subject=".$subject;
				echo "<br>";
				echo "to = ".$to;
				echo "<br>";
				echo "<pre>";
				print_r($html);
				exit; */
				
				$this->commonfunctions->sendMail($to, 'noreplay@silvertouch.com', $subject, $html);
								
			}
		} else {
			$data['message'] = "<p style='color:red'>Your transaction incomplete, Please try again</p>";
		} 
		$this->layout->view('emails/thankyou',$data);
	}
	
	public function cancel(){
		$this->session->set_userdata(array('errorMessage' => "Your Transaction is canceled"));
		$this->commonfunctions->header_redirect(site_url() . '/guest_user/pricing');   
	}
	
	public function myorderdetails(){
	    $data = array();
		//unset message

        $this->load->model('emails_model');
		$getData = $this->input->get();
		$userid = $this->session->userdata('login_id');
		
		//Records per page
		if(isset($getData['sort_by']) && $getData['sort_by']!=''){
			$limit=$getData['sort_by'];
		} else {
			$limit=25;
		}
		
		$page=1;
		
		$wheres = array();
		
		// get the status
		if(isset($getData['membership']) && $getData['membership']!=''){
			$membership=$getData['membership'];
			$wheres[] = "b.item_name = '".$getData['membership']."'";
		} else {
			$membership = "";
		}
		
		//get the search var
		if(isset($getData['search']) && ($getData['search'] != 'Search by email...' || $getData['search'] == '')){
			$searchvar = $getData['search'];
			$wheres[] = "a.email like '%".$getData['search']."%'";
		} else {
			$searchvar = "Search by email...";
		}	
		if(count($wheres) > 0){
			$where = implode(' AND ',$wheres);
		} else{
			$where = 1;
		}
		
		$start=0; 
		
		if(isset($getData['page']) && $getData['page']!=''){
			$page=$getData['page'];
		}
		
		$start = ($page-1)*$limit;

		$totalUser = $this->emails_model->getAllTransection($where);
		$rows = count($totalUser);
		
		if($limit < 0){
			$data['allTransectionDetails'] = $this->emails_model->getAllTransections($where);
		} else {
			$data['allTransectionDetails'] = $this->emails_model->getAllTransections($where,$start,$limit);
		}
		
		$countRecord = count($data['allTransectionDetails']);
		$data['pagi_data'] = $this->commonfunctions->custom_pagination($limit,$page,site_url(array('admin','transectiondetail?sort_by='.$limit.'&search='.$searchvar.'&membership='.$membership.'&page=')),$rows,$countRecord);
		$data['start'] = $start;
		
		$data['enabledbreadPanels'] = array('bredcrum_myorderlist');
		$this->layout->view('emails/myorderdetail',$data);  
	}
	
	function editAuthKey(){
		$data = array();
		$this->load->model('emails_model');
		$postData = $this->input->post();
		$insertPoint = $this->emails_model->updateAuthKey($postData);
		echo 1;
		exit;
	}
	
	public function userlog() {
        $data = array();
		//unset message
        $this->load->model('emails_model');
		$getData = $this->input->get();
		
		
	//	echo "<pre>";print_r($getData);
	//	exit;
		$userid = $this->session->userdata('login_id');

		//Records per page
		if(isset($getData['sort_by']) && $getData['sort_by']!=''){
			$limit=$getData['sort_by'];
		} else {
			$limit=25;
		}
		
		$page=1;
		
		$wheres = array();
		
		// get the calander date
		if(isset($getData['from']) && $getData['from']!=''){
			$start_date= date('Y-m-d H:i:s',strtotime($getData['from'])); 
			$end_date=date('Y-m-d H:i:s',strtotime($getData['to']));
			$daterange = $getData['from'] .'to'.$getData['to'];
			$wheres[] = "a.date BETWEEN '".$start_date."' AND '".$end_date."'";
		} else {
			$daterange = "";
		}
		
		
		// get the status
		if(isset($getData['status']) && $getData['status']!=''){
			$status=$getData['status'];
			$wheres[] = "a.platform = '".$getData['status']."'";
		} else {
			$status = "";
		}
		
		//get the search var
		if(isset($getData['search']) && ($getData['search'] != 'Search Emails...' || $getData['search'] == '')){
			$searchvar = $getData['search'];
			$wheres[] = "b.username like '%".$getData['search']."%'";
		} else {
			$searchvar = "Search Emails...";
		}
		

		
		
		$wheres[] = "a.user_id = b.id and a.user_id = '".$userid."'";	
		if(count($wheres) > 0){
			$where = implode(' AND ',$wheres);
		} else{
			$where = "a.user_id = b.id and a.user_id = '".$userid."'";
		}
		
		if(isset($getData['generateLog']) && $getData['generateLog']!=''){
			$query = "select a.*,b.username from generate_log as a inner join users as b where ".$where." order by id DESC";
			//echo $query;exit;
			$this->commonfunctions->exportMysqlToCsv($query);
		} 	
		
		
		
		$start=0; 
		
		if(isset($getData['page']) && $getData['page']!=''){
			$page=$getData['page'];
		}
		
		$start = ($page-1)*$limit;

		$totalLogs = $this->emails_model->get_all_user_log($where);
		$rows = count($totalLogs);
		
		if($limit < 0){
			$data['alllogs'] = $this->emails_model->get_all_user_logs($where);
		} else {
			$data['alllogs'] = $this->emails_model->get_all_user_logs($where,$start,$limit);
		}
		
		$countRecord = count($data['allusers']);
		$data['pagi_data'] = $this->commonfunctions->custom_pagination($limit,$page,site_url(array('emails','userlog?sort_by='.$limit.'&search='.$searchvar.'&status='.$status.'&daterange='.$daterange.'&page=')),$rows,$countRecord);
		$data['start'] = $start;
		
		
		// get the points
		$userid = $this->session->userdata('login_id');		
		$data['enabledbreadPanels'] = array('bredcrum_userlog');
		$this->layout->view('emails/user_log',$data);
    }
	
	function pdf(){
		//get txn id 
		$txnid = $this->uri->segment(3);
		$this->load->model('emails_model');
		$txnDetails = $this->emails_model->getTxnDetails($txnid);
		$html = $this->commonfunctions->pdfHtml($txnDetails);
		//echo "html = ".$html;exit;
		$this->load->library('pdf');
		$pdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
		$pdf->SetTitle('My Title');
		$pdf->SetHeaderMargin(5);
		//$pdf->SetTopMargin(20);
		$pdf->setFooterMargin(10);
		$pdf->SetAutoPageBreak(true,25);
		$pdf->setFontSubsetting(true);
		$pdf->SetFont('dejavusans', '', 14, '', true);
		$pdf->AddPage();
		$pdf->setTextShadow(array('enabled'=>true, 'depth_w'=>0.2, 'depth_h'=>0.2, 'color'=>array(196,196,196), 'opacity'=>1, 'blend_mode'=>'Normal'));
		// Print text using writeHTMLCell()
		
		$pdf->writeHTMLCell(0, 0, '', '', $html, 0, 1, 0, true, '', true);
		$pdf->Output($txnid.'.pdf', 'D');
		
		//$this->commonfunctions->header_redirect(site_url() . '/emails/myorderdetails');   
		/* // store at pdf folder
		$filename= "{$txnid}.pdf"; 
		$filelocation = "E:/wamp/www/email_validator/code/smtpemail/admin/pdf_invoice";//windows
        //$filelocation = "/var/www/project/custom"; //Linux

        $fileNL = $filelocation."/".$filename;//Windows
        //$fileNL = $filelocation."/".$filename; //Linux
		//echo $fileNL;exit;		
        $pdf->Output($fileNL,'F');
		*/
	}
	
}

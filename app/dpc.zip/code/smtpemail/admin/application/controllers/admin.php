<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * class Frontpage
 *  
 * @package    act_gmbh
 * @subpackage F360
 * @author     Krunal Darji
 */
class Admin extends CI_Controller {

    /**
     * constructor
     * will load language files
     * 
     * @return void
     */
    function __construct() {
        parent::__construct();
        Commonfunctions::loadLanguageFiles();
    }
    
    /**
     * function index
     * will show dashboard
     * @return void
     */
	 
    public function index() {
        $data = array();
		$data['enabledbreadPanels'] = array('bredcrum_admin_dashbord');
        $this->layout->view('admin/index',$data);
    }
	
	/**
     * function AllUsers
     * will get the all use data
     * @return void
     */
	
	public function userlist(){
	    $data = array();
		//unset message

        $this->load->model('admin_model');
		$getData = $this->input->get();
		$userid = $this->session->userdata('login_id');
		
		$action = $this->input->get('action', TRUE);
		$status = $this->input->get('status', TRUE);
        $uID = $this->input->get('uid', TRUE);
		
		
		if($action == 'status')
        {
          $this->admin_model->changeStatusUser($uID,$status);
		  if($status == 0){
			$msg = 'User Inactive Successfully.';
		  }else{
			$msg = 'User Active Successfully.';
		  }
          $this->session->set_userdata(array('successMessage' => $msg));
		  $this->commonfunctions->header_redirect(site_url() . '/admin/userlist');
        }
		
		
		//Records per page
		if(isset($getData['sort_by']) && $getData['sort_by']!=''){
			$limit=$getData['sort_by'];
		} else {
			$limit=25;
		}
		
		$page=1;
		
		$wheres = array();
		// get the status
		if(isset($getData['status']) && $getData['status']!=''){
			$status=$getData['status'];
			$wheres[] = "user_type = '".$getData['status']."'";
		} else {
			$status = "";
		}
		
		//get the search var
		if(isset($getData['search']) && ($getData['search'] != 'Search User...' || $getData['search'] == '')){
			$searchvar = $getData['search'];
			$wheres[] = "(username like '%".$getData['search']."%' OR email like '%".$getData['search']."%')"; 
		} else {
			$searchvar = "Search User...";
		}	
		if(count($wheres) > 0){
			$where = implode(' AND ',$wheres);
		} else{
			$where = 1;
		}
		
		$start=0; 
		
		if(isset($getData['page']) && $getData['page']!=''){
			$page=$getData['page'];
		}
		
		$start = ($page-1)*$limit;

		$totalUser = $this->admin_model->get_all_user($where);
		$rows = count($totalUser);
		
		if($limit < 0){
			$data['allusers'] = $this->admin_model->get_all_users($where);
		} else {
			$data['allusers'] = $this->admin_model->get_all_users($where,$start,$limit);
		}
		
		$countRecord = count($data['allusers']);
		$data['pagi_data'] = $this->commonfunctions->custom_pagination($limit,$page,site_url(array('admin','userlist?sort_by='.$limit.'&search='.$searchvar.'&status='.$status.'&page=')),$rows,$countRecord);
		$data['start'] = $start;
		
		$data['enabledbreadPanels'] = array('bredcrum_admin_home');
		$this->layout->view('admin/userlist',$data);  
	}
	
	
	
	
	public function price_setting(){
	    $data = array();
        $action = $this->input->get('action', TRUE);
		$status = $this->input->get('status', TRUE);
        $priceID = $this->input->get('pid', TRUE);
        $postData = $this->input->post();
        $this->load->model('admin_model');
        
        if($action == 'delete')
        {
          $this->admin_model->deleteItemPrice($priceID);
          $this->session->set_userdata(array('successMessage' => 'Delete Package Sucessfully.')); 
        }
		
		if($action == 'status')
        {
          $this->admin_model->changeStatus($priceID,$status);
		  if($status == 0){
			$msg = 'Package Inactive Successfully.';
		  }else{
			$msg = 'Package Active Successfully.';
		  }
          $this->session->set_userdata(array('successMessage' => $msg));
		  $this->commonfunctions->header_redirect(site_url() . '/admin/price_setting');
        }	
		
		$data['enabledbreadPanels'] = array('bredcrum_admin_price');
        $data['allpricesetting'] = $this->admin_model->getPricingDetailsFree();
        $this->layout->view('admin/price_setting',$data);  
	}
	
	
	public function news_later(){
	    $data = array();
        $action = $this->input->get('action', TRUE);
		$status = $this->input->get('status', TRUE);
        $newsID = $this->input->get('nid', TRUE);
        $postData = $this->input->post();
        $getData = $this->input->get();
        
        $this->load->model('admin_model');
        
        if($action == 'delete')
        {
          $this->admin_model->deleteItemNews($newsID);
          $this->session->set_userdata(array('successMessage' => 'Email Id Deleted Sucessfully.')); 
        }
		
		if($action == 'status')
        {
          $this->admin_model->changeStatusNews($newsID,$status);
		  if($status == 0){
			$msg = 'Email Id Inactive Successfully.';
		  }else{
			$msg = 'Email Id Active Successfully.';
		  }
          $this->session->set_userdata(array('successMessage' => $msg));
		  $this->commonfunctions->header_redirect(site_url() . '/admin/news_later');
        }	
	
        //Records per page
        if(isset($getData['sort_by']) && $getData['sort_by']!=''){
                $limit=$getData['sort_by'];
        } else {
                $limit=25;
        }

        $page=1;
        
        // ADD where conditions
        $wheres = array();
        if(isset($getData['search']) && ($getData['search'] != 'Search Emails...' || $getData['search'] == '')){
                $searchvar = $getData['search'];
                $wheres = "where email like '%".$getData['search']."%'";
        } else {
                $searchvar = "Search Emails...";
        }
        
        $start=0; 
		
        if(isset($getData['page']) && $getData['page']!=''){
                $page=$getData['page'];
        }

        $start = ($page-1)*$limit;
        
        $totalNewsLater = $this->admin_model->get_all_newsLater($wheres);
	$rows = count($totalNewsLater);
        
	$data['enabledbreadPanels'] = array('bredcrum_admin_news');
        //echo $limit; echo $start;
        
        if($limit < 0){
                $data['allnewslater'] = $this->admin_model->getNewsDetails($wheres);
        } else {
                $data['allnewslater'] = $this->admin_model->getNewsDetails($wheres,$start,$limit);
        }
        
        $countRecord = count($data['allnewslater']);
        $data['pagi_data'] = $this->commonfunctions->custom_pagination($limit,$page,site_url(array('admin','news_later?sort_by='.$limit.'&search='.$searchvar.'&page=')),$rows,$countRecord);
        $data['start'] = $start;
        
        //$data['allnewslater'] = $this->admin_model->getNewsDetails();
        $this->layout->view('admin/news_later',$data);  
	}
	
	
	public function PriceSettingEdit()
    {
        $data = array();
        $postData = $this->input->post();
        $this->load->model('admin_model');
        $saloonID = $this->input->get('Itemid', TRUE);
        $data['allusers'] = $this->admin_model->getPricingDetails($saloonID);
        $data['search'] = '';
        
        if(isset($data['allusers']->id))
        {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('mailtype', array('required' => 'lang:please enter the mail type'), 'required');
            $this->form_validation->set_rules('price', array('required' => 'lang:Please enter the price'), 'required');
            $this->form_validation->set_rules('no_of_mail', array('required' => 'lang:please enter the number of mails'), 'required');
            
            $this->form_validation->set_error_delimiters('<span class="errorMessage">', '</span>');
			
				
            if ($this->form_validation->run() == TRUE && isset($postData['submit'])) 
            {
				
				//echo "<pre>";
				//print_r($postData);	
				$saloonUpdate['id'] = $saloonID;
                $saloonUpdate['registration'] = $postData['registration'];
                $saloonUpdate['status'] = $postData['status'];
                $saloonUpdate['mailtype'] = $postData['mailtype'];
                $saloonUpdate['price'] =  $postData['price'];
                $saloonUpdate['no_of_mail'] = $postData['no_of_mail'];
				$saloonUpdate['method'] = $postData['method'];
				$saloonUpdate['max_per_day'] = $postData['max_per_day'];
				$saloonUpdate['bulk_limit'] = $postData['bulk_limit'];
				$saloonUpdate['validity'] = $postData['validity'];
				$saloonUpdate['discount'] = $postData['discount'];
				$saloonUpdate['old_price'] = $postData['old_price'];
				
				if($postData['validity'] == 0){
						$saloonUpdate['validity_month'] = 0;
						$saloonUpdate['validity_year'] = 0;
				}
				if($postData['validity'] == 1){
						$saloonUpdate['validity_month'] = $postData['validity_month'];
						$saloonUpdate['validity_year'] = 0;
				}
				if($saloonUpdate['validity'] == 2){
						$saloonUpdate['validity_year'] = $postData['validity_year'];
						$saloonUpdate['validity_month'] = 0;
				}
				
				
				//exit;
				$statId = $this->admin_model->globalUpdate('pricing_details', $saloonUpdate);
                $this->session->set_userdata(array('successMessage' => 'Price Listing Updated Successfully.'));
                $this->commonfunctions->header_redirect(site_url() . '/admin/price_setting');
              //$this->commonfunctions->header_redirect(site_url() . '/admin/edit_price_setting?Itemid='.$saloonUpdate['id']);
            }
			
			$data['enabledbreadPanels'] = array('bredcrum_admin_price');
            $data['postData'] = $postData;
            $this->layout->view('admin/edit_price_setting',$data);
        }
    }
	
    public function AllUsers()
    {
        $data = array();
        $this->layout->setLayout('admin_layout.php');
        $postData = $this->input->post();
        $this->load->model('admin_model');
        $action = $this->input->get('action', TRUE);
        $usersID = $this->input->get('uid', TRUE);
        if($action == 'delete')
        {
          $this->admin_model->deleteUsers($usersID);
          $this->session->set_userdata(array('successMessage' => $this->lang->line('users_deleted_sucessfully')));
        }
        
         /* Paging starts */
        $currentPage = $this->input->get('page', TRUE);
        if($currentPage == '' || $currentPage== '0') {
            $currentPage = 0;
        }
        $pagingData = $this->commonfunctions->setPaginationSettings($currentPage, site_url(array()) . 'admin/allusers?1=1', $this->admin_model->get_all_users(true, $currentPage,$postData['keyword']));
        $this->pagination->initialize($pagingData);
        /* Paging complete */
        $data['allusers'] = $this->admin_model->get_all_users(false, $currentPage,$postData['keyword'] );
        $data['search'] = 'search';
        $this->layout->view('admin/allusers',$data);  
    }
    
	public function emailtemplatelist(){
	    $data = array();
		//unset message

        $this->load->model('admin_model');
		$getData = $this->input->get();
		$userid = $this->session->userdata('login_id');
		
		
		//Records per page
		if(isset($getData['sort_by']) && $getData['sort_by']!=''){
			$limit=$getData['sort_by'];
		} else {
			$limit=25;
		}
		
		$page=1;
		
		$wheres = array();
		// get the status
		if(isset($getData['status']) && $getData['status']!=''){
			$status=$getData['status'];
			$wheres[] = "user_type = '".$getData['status']."'";
		} else {
			$status = "";
		}
		
		//get the search var
		if(isset($getData['search']) && ($getData['search'] != 'Search Username...' || $getData['search'] == '')){
			$searchvar = $getData['search'];
			$wheres[] = "username like '%".$getData['search']."%'";
		} else {
			$searchvar = "Search Username...";
		}	
		if(count($wheres) > 0){
			$where = implode(' AND ',$wheres);
		} else{
			$where = 1;
		}
		
		$start=0; 
		
		if(isset($getData['page']) && $getData['page']!=''){
			$page=$getData['page'];
		}
		
		$start = ($page-1)*$limit;

		$totalUser = $this->admin_model->getEmailTemplate($where);
		$rows = count($totalUser);
		
		if($limit < 0){
			$data['allusers'] = $this->admin_model->getEmailTemplates($where);
		} else {
			$data['allusers'] = $this->admin_model->getEmailTemplates($where,$start,$limit);
		}
		
		$countRecord = count($data['allusers']);
		$data['pagi_data'] = $this->commonfunctions->custom_pagination($limit,$page,site_url(array('admin','emailtemplatelist?sort_by='.$limit.'&search='.$searchvar.'&status='.$status.'&page=')),$rows,$countRecord);
		$data['start'] = $start;
		
		$data['enabledbreadPanels'] = array('bredcrum_admin_mail');
		$this->layout->view('admin/emailtemplatelist',$data);  
	}
	
	
	 public function emailTemplate() {
        $data = array();
		
        $data['editid'] = $this->input->get('tid', TRUE);
        
        $data['postData'] = $this->input->post();
		
        $this->load->model('admin_model');
        
        if($data['editid'] != '' && $data['editid'] != '0') {
			//echo 'yes';
            $data['editData'] = $this->admin_model->getEmailTemplates('id = '.  $data['editid']);
            //echo "<pre>";print_r($data['editData']);
			if(!isset($data['postData']['emailname'])) {
                $data['postData'] = $data['editData'];
            }
        }
		//echo "<pre>";print_r($data['postData']);
		
		$this->load->helper(array('form', 'url'));
        
		//echo "1<pre>";print_r($data['postData']);
		//echo "2 = ".$data['postData']['editid'];		
		//exit;
	   
		if (isset($data['postData']['submit'])) {
		
			if($data['postData']['editid'] != '' && $data['postData']['editid'] != '0') {
			//	echo "edut";exit;
				$userUpdate['`id`'] = $data['postData']['editid'];
				$userUpdate['`emailname`'] =  $data['postData']['emailname'];
				$userUpdate['`subject`'] = $data['postData']['subject'];
				$userUpdate['`description`'] = mysql_escape_string($data['postData']['description']);
				$userUpdate['`sendermail`'] = $data['postData']['sendermail'] ;
				$statId = $this->admin_model->globalUpdate('emailtemplate', $userUpdate);
				$this->session->set_userdata(array('successMessage' => $this->lang->line('statistics_records_updated')));
				$this->session->set_userdata(array('successMessage' => '<span>Email Templates Updated Successfully.</span>'));
				$this->commonfunctions->header_redirect(site_url() . '/admin/emailtemplatelist');
			}
			else{
			//echo "add";exit;
				$userInsert = array();
				$userInsert['`emailname`'] =  $data['postData']['emailname'];
				$userInsert['`email_alias`'] = $data['postData']['email_alias'];
				$userInsert['`subject`'] = $data['postData']['subject'];
				$userInsert['`description`'] = mysql_escape_string($data['postData']['description']);
				$userInsert['`sendermail`'] = $data['postData']['sendermail'] ;
                                
				$statId = $this->admin_model->globalInsert('emailtemplate', $userInsert);
				$this->session->set_userdata(array('successMessage' => $this->lang->line('statistics_records_inserted')));
				$this->session->set_userdata(array('successMessage' => '<span>Email Templates Added Successfully.</span>'));
				$this->commonfunctions->header_redirect(site_url() . '/admin/emailtemplatelist');
			}
	   
        }
		if($data['editid'] != '' && $data['editid'] != '0') {
		$data['enabledbreadPanels'] = array('bredcrum_admin_mail_edit');
        }else{
		$data['enabledbreadPanels'] = array('bredcrum_admin_mail_new');
		}
        $this->session->set_userdata($cdata);
        $this->layout->view('admin/emailtemplate',$data);
    }
	
	function checkEmailAlias(){
		//echo 'vhghhj'.$_POST['email_alias'];exit;
		$this->load->model('admin_model');
		if(isset($_POST['email_alias']))//If a username has been submitted
		{
			$username = mysql_real_escape_string($_POST['email_alias']);//Some clean up :)
			$check_for_username = $this->admin_model->email_alias_exists($username);
			
			if($check_for_username)
			{
				echo 'false';//If there is a  record match in the Database - Not Available
			}
			else
			{
				echo 'true';//No Record Found - Username is available
			} 
		}
	
	}
	
	public function transectiondetail(){
	    $data = array();
		//unset message

        $this->load->model('admin_model');
		$getData = $this->input->get();
		$userid = $this->session->userdata('login_id');
		
		//Records per page
		if(isset($getData['sort_by']) && $getData['sort_by']!=''){
			$limit=$getData['sort_by'];
		} else {
			$limit=25;
		}
		
		$page=1;
		
		$wheres = array();
		
		// get the status
		if(isset($getData['membership']) && $getData['membership']!=''){
			$membership=$getData['membership'];
			$wheres[] = "b.item_name = '".$getData['membership']."'";
		} else {
			$membership = "";
		}
		
		//get the search var
		if(isset($getData['search']) && ($getData['search'] != 'Search by email...' || $getData['search'] == '')){
			$searchvar = $getData['search'];
			$wheres[] = "a.email like '%".$getData['search']."%'";
		} else {
			$searchvar = "Search by email...";
		}	
		if(count($wheres) > 0){
			$where = implode(' AND ',$wheres);
		} else{
			$where = 1;
		}
		
		$start=0; 
		
		if(isset($getData['page']) && $getData['page']!=''){
			$page=$getData['page'];
		}
		
		$start = ($page-1)*$limit;

		$totalUser = $this->admin_model->getAllTransection($where);
		$rows = count($totalUser);
		
		if($limit < 0){
			$data['allTransectionDetails'] = $this->admin_model->getAllTransections($where);
		} else {
			$data['allTransectionDetails'] = $this->admin_model->getAllTransections($where,$start,$limit);
		}
		
		$countRecord = count($data['allTransectionDetails']);
		$data['pagi_data'] = $this->commonfunctions->custom_pagination($limit,$page,site_url(array('admin','transectiondetail?sort_by='.$limit.'&search='.$searchvar.'&membership='.$membership.'&page=')),$rows,$countRecord);
		$data['start'] = $start;
		
		$data['enabledbreadPanels'] = array('bredcrum_admin_transectiondetails');
		$this->layout->view('admin/transectiondetail',$data);  
	}
	
	public function adminLog() {
        $data = array();
		//unset message
        $this->load->model('admin_model');
		$getData = $this->input->get();
		
		
		//echo "<pre>";print_r($getData);
		//exit;
		$userid = $this->session->userdata('login_id');

		/*	
		if(isset($getData['checkbox']) && $getData['checkbox']!=''){
			$Checkboxarray = implode("','",$getData['checkbox']);
			$query = "select * from generate_log where id in ('".$Checkboxarray."')";
			$this->commonfunctions->exportMysqlToCsv($query);
		} 
		*/
		
		/*
		if(count($getData['checkbox']) < 0){
		$errorMSG = array('errorMsg' => 'Please select the emails for export!!');
		$this->session->set_userdata($errorMSG);
		}
		*/
		
		//Records per page
		if(isset($getData['sort_by']) && $getData['sort_by']!=''){
			$limit=$getData['sort_by'];
		} else {
			$limit=25;
		}
		
		$page=1;
		
		$wheres = array();
		
		// get the calander date
		$datefrom = $this->session->userdata('from_date');
		$dateto = $this->session->userdata('to_date');
		
		if(isset($getData['from']) && $getData['from']!=''){
					$this->session->set_userdata(array('from_date'=>$getData['from']));
					$this->session->set_userdata(array('to_date'=>$getData['to']));
					$start_date= date('Y-m-d H:i:s',strtotime($getData['from'])); 
					$end_date=date('Y-m-d H:i:s',strtotime($getData['to']));
					$daterange = $getData['from'] .'to'.$getData['to'];
					$wheres[] = "a.date BETWEEN '".$start_date."' AND '".$end_date."'";
		} else if((isset($datefrom)) && (!empty($datefrom))) {
					$start_date= date('Y-m-d H:i:s',strtotime($datefrom)); 
					$end_date=date('Y-m-d H:i:s',strtotime($dateto));
					$daterange = $datefrom .'to'.$dateto;
					$wheres[] = "a.date BETWEEN '".$start_date."' AND '".$end_date."'";
					
		} else {
				$daterange = "";
		}
		
		
		// get the status
		if(isset($getData['status']) && $getData['status']!=''){
			$status=$getData['status'];
			$wheres[] = "a.platform = '".$getData['status']."'";
		} else {
			$status = "";
		}
		
		//get the search var
		if(isset($getData['search']) && ($getData['search'] != 'Search User...' || $getData['search'] == '')){
			$searchvar = $getData['search'];
			$wheres[] = "(b.username like '%".$getData['search']."%' OR a.email like '%".$getData['search']."%')";
		} else {
			$searchvar = "Search User...";
		}
		
	
		$wheres[] = "a.user_id = b.id";	
		if(count($wheres) > 0){
			$where = implode(' AND ',$wheres);
		} else{
			$where = "1 = 1";
		}
		
		if(isset($getData['generateLog']) && $getData['generateLog']!=''){
			$query = "select a.*,b.username from generate_log as a inner join users as b where ".$where." order by id DESC";
			//echo $query;exit;
			$this->commonfunctions->exportMysqlToCsv($query);
		} 	
		
		
		
		$start=0; 
		
		if(isset($getData['page']) && $getData['page']!=''){
			$page=$getData['page'];
		}
		
		$start = ($page-1)*$limit;

		$totalLogs = $this->admin_model->get_all_log($where);
		$rows = count($totalLogs);
		
		if($limit < 0){
			$data['alllogs'] = $this->admin_model->get_all_logs($where);
		} else { 
			$data['alllogs'] = $this->admin_model->get_all_logs($where,$start,$limit);
		}
		
		$countRecord = count($data['allusers']);
		$data['pagi_data'] = $this->commonfunctions->custom_pagination($limit,$page,site_url(array('admin','adminLog?sort_by='.$limit.'&search='.$searchvar.'&status='.$status.'&daterange='.$daterange.'&page=')),$rows,$countRecord);
		$data['start'] = $start;
		
		
		// get the points
		$userid = $this->session->userdata('login_id');		
		$data['enabledbreadPanels'] = array('bredcrum_admin_generatelog');
		$this->layout->view('admin/admin_log',$data);
    }
   

}

/* End of file home.php */
/* Location: ./application/controllers/home.php */
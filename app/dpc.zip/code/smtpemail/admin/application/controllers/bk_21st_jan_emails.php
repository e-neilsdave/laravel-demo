<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Emails extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     */
    
    function __construct() {
        parent::__construct();
		Commonfunctions::loadLanguageFiles();
    }
    
    public function index() {
        $data = array();
		//unset message
        $this->load->model('emails_model');
		$getData = $this->input->get();
		$userid = $this->session->userdata('login_id');

		if(isset($getData['checkbox']) && $getData['checkbox']!=''){
			$Checkboxarray = implode("','",$getData['checkbox']);
			$query = "select * from emaillist where id in ('".$Checkboxarray."')";
			$this->commonfunctions->exportMysqlToCsv($query);
		} 
		
		if(count($getData['checkbox']) < 0){
		$errorMSG = array('errorMsg' => 'Please select the emails for export!!');
		$this->session->set_userdata($errorMSG);
		}
		
		//Records per page
		if(isset($getData['sort_by']) && $getData['sort_by']!=''){
			$limit=$getData['sort_by'];
		} else {
			$limit=25;
		}
		
		$page=1;
		
		$wheres = array();
		// get the status
		if(isset($getData['status']) && $getData['status']!=''){
			$status=$getData['status'];
			$wheres[] = "status = '".$getData['status']."'";
		} else {
			$status = "";
		}
		
		//get the search var
		if(isset($getData['search']) && ($getData['search'] != 'Search Emails...' || $getData['search'] == '')){
			$searchvar = $getData['search'];
			$wheres[] = "email like '%".$getData['search']."%'";
		} else {
			$searchvar = "Search Emails...";
		}	
		$wheres[] = "userid = ".$userid;	
		if(count($wheres) > 0){
			$where = implode(' AND ',$wheres);
		} else{
			$where = "userid = ".$userid;
		}
		
		$start=0; 
		
		if(isset($getData['page']) && $getData['page']!=''){
			$page=$getData['page'];
		}
		
		$start = ($page-1)*$limit;

		$totalUser = $this->emails_model->get_all_email($where);
		$rows = count($totalUser);
		
		if($limit < 0){
			$data['allusers'] = $this->emails_model->get_all_emails($where);
		} else {
			$data['allusers'] = $this->emails_model->get_all_emails($where,$start,$limit);
		}
		
		$countRecord = count($data['allusers']);
		$data['pagi_data'] = $this->commonfunctions->custom_pagination($limit,$page,site_url(array('emails','index?sort_by='.$limit.'&search='.$searchvar.'&status='.$status.'&page=')),$rows,$countRecord);
		$data['start'] = $start;
		
		
		// get the points
		$userid = $this->session->userdata('login_id');
		$data['points'] = $this->emails_model->getPoints($userid);
		$data['privateKeys'] = $this->emails_model->getPrivateKeys($userid);
		$data['membershiptype'] = $this->emails_model->getMembershipType($userid);
		
		$data['enabledbreadPanels'] = array('bredcrum_home');
		$data['enabledSidePanels'] = array('sidebar_points');
		$this->layout->view('emails/index',$data);
    }
	
	public function import() {
		$data = array();
		
		//load library
		$this->load->library('smtp_validateemail');
		$this->load->model('emails_model');
		
		$postData = $this->input->post();
		$getData = $this->input->get();
		
		$userid = $this->session->userdata('login_id');
		$data['points'] = $this->emails_model->getPoints($userid);
		
		/*	
			$emails = array('user@example.com', 'user2@example.com');
			$sender = 'user@yourdomain.com';
			$SMTP_Validator = new SMTP_validateEmail();
			$SMTP_Validator->debug = true;
			$results = $SMTP_Validator->validate($emails, $sender);
		*/
	
		echo "Email String = <pre>";print_r($postData);
		echo "<br />";
		
		$emailsValidator = explode(',',rtrim($postData['emailString'],','));
		echo "post data = <pre>";print_r($emailsValidator);
	//	exit;
		
		$SMTP_Validator = new SMTP_validateEmail();
		
		if(isset($postData) && $postData['emailString'] != '' ){
		//	$validemails = array();
		//	$validemails[] = $emailsValidator; //$getData['email'];
			
			
			$validemails = $emailsValidator;
			$sender = 'user@yourdomain.com';
			$results = $SMTP_Validator->validate($validemails, $sender);				
			$insertdata = $this->emails_model->insertEmails($results);
			ob_clean();
			if($insertdata != ""){
				$remainPoint = $data['points']->point - 1;
				$insertPoint = $this->emails_model->insertPoints($remainPoint);
				$this->session->set_userdata(array('successMessage' => "Email Validation process completed. Please see below for validation status."));
				echo '1';
			} else {
				echo '0';
			}
			exit;
		}
		
		if(isset($postData['cancel']) && $postData['cancel'] !=''){
			$this->commonfunctions->header_redirect(site_url() . '/emails/index');
		}
		
		if(isset($postData['importdata'])){
			if ($_FILES["file_csv"]["error"] > 0){
					$data['errorMsg'] = " Please select the CSV file";
			}
			
			if(isset($_FILES['file_csv']['name']) && $_FILES['file_csv']['name'] != '' ){
				$rest = substr($_FILES["file_csv"]["name"], -3);
				if (( ($rest == "csv") || ($rest == "CSV")) ) {
					$validemails = array();
					$finalcnt = 0;
					$row = 1;
					if (($handle = fopen($_FILES["file_csv"]["tmp_name"], "r")) !== FALSE) {
						while (($datacsv = fgetcsv($handle, 1000, ",")) !== FALSE) {
							$num = count($datacsv);
							for ($c=0; $c < $num; $c++) {
									$validemails[$finalcnt] =  $datacsv[0];	
							}
							$finalcnt++;
						}
						fclose($handle);
					}
					
					echo "count = ".$finalcnt."<br />";
					array_splice($validemails, 0, 1);
					echo "<pre>";print_r($data['points']);
					
					$emailCounterLimit = count($validemails);
					echo $emailCounterLimit;
					
					// Bulk limit for standerd and profesional user
					if($data['points']->membership_type == 3 || $data['points']->membership_type == 4 ){
						
						if($emailCounterLimit >= 50){
							echo "yes";
						}else{
							echo "you can not import more then 50 emails in CSV file";
						}
						
					}
					
					if($data['points']->membership_type == 2){
						
						if($emailCounterLimit >= 50){
							echo "yes";
						}else{
							echo "you can not import more then 50 emails in CSV file";
						}
					}
					
					if($data['points']->membership_type == 1){
						echo "you cant insert CSV file";
					}
					
					
					
					
					exit;
					
					$sender = 'user@yourdomain.com';
					$results = $SMTP_Validator->validate($validemails, $sender);
					
					// result = 3
					// point = 2
					
					// and
					
					// result = 3
					// point = 12
					
					//echo count($results) ." and ". $data['points']->point ;exit;
					// if csv emails is more then points the show error you cant upload more emails
					if(count($results) <= $data['points']->point  ){
						$insertdata = $this->emails_model->insertEmails($results);
						if($insertdata != ""){
								$remainPoint = $data['points']->point - count($results);
								$insertPoint = $this->emails_model->insertPoints($remainPoint);
							// set success message in session
							$this->session->set_userdata(array('successMessage' => "Emails are inserted"));
							$this->commonfunctions->header_redirect(site_url(array('emails','index')));
						} else{
							$this->session->set_userdata(array('successMessage' => "Emails are not inserted preoperly!"));
						}		
					}else{
						$this->session->set_userdata(array('errorMessage' => "you can not import more then ".$data['points']->point." emails"));
					//	$data['errorMsg'] = "you can not import more then ".$data['points']->point." emails";
						$this->commonfunctions->header_redirect(site_url(array('emails','index')));
					}
					
				}else{
					$data['errorMsg'] = "Please import a CSV file!!";
				}
			}
		}
		$data['membershiptype'] = $this->emails_model->getMembershipType($userid);
		
		$data['enabledbreadPanels'] = array('bredcrum_import');
		$data['enabledSidePanels'] = array('sidebar_points');
		$this->layout->view('emails/import_data',$data);
    }
	
	
	public function editregisteruser() {
		
        $data = array();
		$data['editid'] = $this->session->userdata('login_id');
		$data['postData'] = $this->input->post();
		
		$this->load->model('user_model');
		$this->load->model('emails_model');
		
		$userid = $this->session->userdata('login_id');
		
		if($data['editid'] != '' && $data['editid'] != '0') {
            $data['editData'] = $this->user_model->get_user_details($data['editid'], 'array');
            if(!isset($data['postData']['username'])) {
                $data['postData'] = $data['editData'];
            }
        }

        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
      
        $this->form_validation->set_rules('username', array('required' => 'lang:general_enter_user_name'), 'required');

       // $this->form_validation->set_rules('email', array('required' => 'lang:general_enter_email', 'valid_email' => 'lang:general_enter_valid_email', 'is_unique' => 'lang:general_email_exists'), 'required|valid_email|is_unique[users.email.'.$data['finalEditId'].']');
		
		//if($data['editid'] != '' && $data['editid'] != '0') {
        //    $this->form_validation->set_rules('password', array('matches' => 'lang:general_password_not_match'), 'matches[confirm_password]');
      //  } else {
			$this->form_validation->set_rules('password', array('required' => 'lang:general_enter_password', 'matches' => 'lang:general_password_not_match'), 'required|matches[confirm_password]');
            $this->form_validation->set_rules('confirm_password', array('required' => 'lang:general_enter_confirm_password'), 'required');
     //   }
	
        $this->form_validation->set_error_delimiters('<span class="errorMessage">', '</span>');
    	if ($this->form_validation->run() == TRUE && isset($data['postData']['subscribe'])) {			
			$userUpdate['id'] = $data['editid'];
			$userUpdate['`username`'] = $data['postData']['username'];
			$userUpdate['`password`'] = MD5($data['postData']['password']);
			$statId = $this->user_model->globalUpdate('users', $userUpdate);
			
			// username session value update
			$this->session->set_userdata(array('login_username' => $data['postData']['username']));
			
			$this->session->set_userdata(array('successMessage' => "User Data Updated"));
			$this->commonfunctions->header_redirect(site_url() . '/emails/editregisteruser');    
        }
		$data['membershiptype'] = $this->emails_model->getMembershipType($userid);
		$data['points'] = $this->emails_model->getPoints($userid);
		$data['enabledbreadPanels'] = array('bredcrum_editaccount');
		$data['enabledSidePanels'] = array('sidebar_points');
        $this->session->set_userdata($cdata);
        $this->layout->view('emails/register_edituser',$data);
    }
	
	public function cartpage(){
		$data = array();
		$this->load->model('emails_model');
		$priceId = $_POST['username'];
		//$priceId = $this->uri->segment(3);
		//echo "hi = ".$priceId;
		$data['priceDetails'] = $this->emails_model->getPriceDetails($priceId);
		//echo "<pre>";print_r($data['priceDetails']);
		
		$cartpageHtml = $this->emails_model->htmlCartPage($data['priceDetails']);
    	echo $cartpageHtml;
		
		//echo $this->layout->view('emails/cartpage',$data);
	}
	
	public function paypalForm(){
		$data = array();
		$this->load->model('emails_model');
		$priceId = $this->uri->segment(3);
		$data['priceDetails'] = $this->emails_model->getPriceDetails($priceId);
		$this->layout->view('emails/paypalform',$data);
	}
	
	public function thankyou(){
		$data = array();
		$this->load->model('user_model');
		$this->load->model('emails_model');
		$postdata = $this->input->post();
		$postdata['userid'] = $this->session->userdata('login_id');
		
		//get membership detail id 
		$membershipid = $this->uri->segment(3);
		
		// get the users points and membership
		$pointDetails = $this->emails_model->getPoints($postdata['userid']);
		//echo "<pre>";print_R($postdata);
		//echo "membership id = ".$membershipid;
		//echo "point id = ".$pointDetails;
		
		//exit;
		if(isset($postdata) && $postdata['payment_status'] != ''){
			// insert transection details
			$txnDetails = $this->emails_model->insertTxnID($postdata);
			
			if($txnDetails == '0'){
				$data['message'] = "<p style='color:red'>Your transection incomplited, Please try again</p>";
			} else {
				
				//update points and membership_type	
				$pointUpdate['`userid`'] = $this->session->userdata('login_id');
				$pointUpdate['`point`'] = $pointDetails->point + $postdata['option_selection1'];
				$pointUpdate['`membership_type`'] = $membershipid;//$postdata['item_name'];
				$statId = $this->emails_model->globalUpdate('emailpoints', $pointUpdate);	
				
				$data['message'] = "<p style='color:green'>Your transection complited successfully</p>";
				
				// txn details mail
				//Send mail
						
				$bodyTemp = $this->user_model->getEmailBody('membership_detail');
				$replacement = array(
								'#username#' => $this->session->userdata('login_username'),
								'#membership#' => $postdata['item_name'],
								'#date#' => $postdata["payment_date"],
								'#txnid#' => $postdata["txn_id"],
								'#noEmails#' => $postdata["option_selection1"],
								'#amount#' => $postdata["mc_gross"],
								'#APIkey#' => $this->session->userdata('APIkey'),	);
				$html = $this->commonfunctions->sendMailWithEmailTemplate($bodyTemp , $replacement);
				
			//	echo "Body HTML = ".$html;
			//	exit;	
				
				$subject = $bodyTemp->subject;
				$to = $this->session->userdata('login_email');
				/*
				echo "subject=".$subject;
				echo "<br>";
				echo "to = ".$to;
				echo "<br>";
				echo "<pre>";
				print_r($html);
				exit; */
				
				$this->commonfunctions->sendMail($to, 'noreplay@silvertouch.com', $subject, $html);
								
			}
		} else {
			$data['message'] = "<p style='color:red'>Your transection incomplited, Please try again</p>";
		} 
		$this->layout->view('emails/thankyou',$data);
	}
	
	public function cancel(){
		$this->session->set_userdata(array('errorMessage' => "Your Transection is canceled"));
		$this->commonfunctions->header_redirect(site_url() . '/guest_user/pricing');   
	}
	
	public function myorderdetails(){
	    $data = array();
		//unset message

        $this->load->model('emails_model');
		$getData = $this->input->get();
		$userid = $this->session->userdata('login_id');
		
		//Records per page
		if(isset($getData['sort_by']) && $getData['sort_by']!=''){
			$limit=$getData['sort_by'];
		} else {
			$limit=25;
		}
		
		$page=1;
		
		$wheres = array();
		
		// get the status
		if(isset($getData['membership']) && $getData['membership']!=''){
			$membership=$getData['membership'];
			$wheres[] = "b.item_name = '".$getData['membership']."'";
		} else {
			$membership = "";
		}
		
		//get the search var
		if(isset($getData['search']) && ($getData['search'] != 'Search by email...' || $getData['search'] == '')){
			$searchvar = $getData['search'];
			$wheres[] = "a.email like '%".$getData['search']."%'";
		} else {
			$searchvar = "Search by email...";
		}	
		if(count($wheres) > 0){
			$where = implode(' AND ',$wheres);
		} else{
			$where = 1;
		}
		
		$start=0; 
		
		if(isset($getData['page']) && $getData['page']!=''){
			$page=$getData['page'];
		}
		
		$start = ($page-1)*$limit;

		$totalUser = $this->emails_model->getAllTransection($where);
		$rows = count($totalUser);
		
		if($limit < 0){
			$data['allTransectionDetails'] = $this->emails_model->getAllTransections($where);
		} else {
			$data['allTransectionDetails'] = $this->emails_model->getAllTransections($where,$start,$limit);
		}
		
		$countRecord = count($data['allTransectionDetails']);
		$data['pagi_data'] = $this->commonfunctions->custom_pagination($limit,$page,site_url(array('admin','transectiondetail?sort_by='.$limit.'&search='.$searchvar.'&membership='.$membership.'&page=')),$rows,$countRecord);
		$data['start'] = $start;
		
		$data['enabledbreadPanels'] = array('bredcrum_myorderlist');
		$this->layout->view('emails/myorderdetail',$data);  
	}
	
	function editAuthKey(){
		$data = array();
		$this->load->model('emails_model');
		$postData = $this->input->post();
		$insertPoint = $this->emails_model->updateAuthKey($postData);
		echo 1;
		exit;
	}
	
	
}

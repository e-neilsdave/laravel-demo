<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

    /**
     * Index Page for this controller.
     *
    */
    
    function __construct() {
        parent::__construct();
        Commonfunctions::loadLanguageFiles();
        $this->load->library('My_PHPMailer');
    }
    
    public function index() {
        $data = array();
        $this->commonfunctions->header_redirect(site_url(array('emails','index')));
    }
    
    public function changepassword() {
        $data = array();
        $postData = $this->input->post();
        if(isset($postData['change'])) {
            if(trim($postData['password1']) == '') {
                $data['errorMsg'] = $this->lang->line('general_enter_password');
            } else if(trim($postData['password2']) == '') {
                $data['errorMsg'] = $this->lang->line('general_enter_confirm_password');
            } else if(trim($postData['password1']) != trim($postData['password2'])) {
                $data['errorMsg'] = $this->lang->line('general_password_not_match');
            } else { 
                $this->load->model('user_model');
                $userData = $this->user_model->change_password($this->session->userdata('login_id'), $postData['password1']);
                $data['errorMsg'] = $this->lang->line('general_password_changed');
                $this->commonfunctions->header_redirect(site_url(array('home','index')));
            }
        }
        $this->layout->view('user/changepassword', $data);
    }
	
    public function forgotpassword() {
        $data = array();
        $data['email'] = '';
        $postData = $this->input->post();
	
		$this->load->library('recaptcha');
		
	    if(isset($postData['reset'])) {
            $data['email'] = $postData['email'];
            if(trim($data['email']) == '') {
                $data['errorMsg'] = "Please enter a email Address";
            } else {
				$this->load->model('user_model');
                $userData = $this->user_model->user_name_exists($data['email']);
				
				$this->recaptcha->recaptcha_check_answer();
				
                if($userData  && $this->recaptcha->getIsValid() ) {
                    //Reset password
                    list($resetData, $newPassword) = $this->user_model->reset_password($data['email']);
                    $finalUserDataNew = $resetData[0];
					
							
					//Send mail
					
					$bodyTemp = $this->user_model->getEmailBody('forgot_password');
					$replacement = array(
									'#username#' => $finalUserDataNew->username,
									'#password#' => $newPassword );
					$html = $this->commonfunctions->sendMailWithEmailTemplate($bodyTemp , $replacement);
					
				//	echo "Body HTML = ".$html;
				//	exit;	
					
					$subject = $bodyTemp->subject;
					$to = $finalUserDataNew->email;
					
					/*
					echo "subject=".$subject;
					echo "<br>";
					echo "to = ".$to;
					echo "<br>";
					echo "<pre>";
					print_r($html);
					exit; */
					
					$this->commonfunctions->sendMail($to, 'noreplay@silvertouch.com', $subject, $html);
                    
                    //Redirect
                    $data['errorMsg'] = "Password Sent on your email Address password is =".$newPassword;
                    $data['email'] = '';
                } else {
					if(!$this->recaptcha->getIsValid()) {
						$data['errorMsg'] = 'incorrect captcha';
					} else {
						$data['errorMsg'] = 'Username is Invalid';
					}
                }
            }
        }
		
		$data['recaptcha_html'] = $this->recaptcha->recaptcha_get_html();
	
		$data['page'] = 'login/login';
		$data['enabledSidePanels'] = array('sidebar_signup');
		$data['enabledbreadPanels'] = array('bredcrum_forgot');
        $this->layout->view('user/forgotpassword', $data);
    }
	
    public function login() {
		$data = array();
        $data['userName'] = '';
        $postData = $this->input->post();
		if(isset($postData['login'])) {
		    $data['userName'] = $postData['username'];
            $data['password'] = $postData['password'];
            if(trim($data['userName']) == '') {
                $data['errorMsg'] = $this->lang->line('general_enter_username');
            } else if(trim($data['password']) == '') {
                $data['errorMsg'] = $this->lang->line('general_enter_password');
            } else {
                $this->load->model('user_model');
                $userData = $this->user_model->validate_user_auth($data['userName'], $data['password']);
                
                if(count($userData) > 0) {
                    //login
                    $newdata = array(
                       'login_email'  => $userData[0]->email,
					   'login_username'  => $userData[0]->username ,
                       'login_id' => $userData[0]->id,
					   'user_type' => $userData[0]->user_type,
					   'APIkey' => $userData[0]->apicode,
					);
                    
                    //Get language name
                    
                    $this->session->set_userdata($newdata);
                  //  $this->accessfunctions->reloadPrivilages();
                    if($userData[0]->forgot_flag == '1') {
                        $this->commonfunctions->header_redirect(site_url(array('home','changepassword')));
                    } else {
						if($userData[0]->user_type == 'admin'){
							$this->commonfunctions->header_redirect(site_url(array('admin','index')));
						}else{
							$this->commonfunctions->header_redirect(site_url(array('emails','dashbord')));
						}
                    }
                } else {
                    $data['errorMsg'] = $this->lang->line('general_invalid_username_password');
                }
            }
        }
		$data['enabledbreadPanels'] = array('bredcrum_login');
		$data['enabledSidePanels'] = array('sidebar_signup');
        $this->layout->view('user/login', $data);
    }
	
    public function logout() {
        $this->session->sess_destroy();
        $this->commonfunctions->header_redirect(site_url(array('home','login')));
    }
	
	public function register() {
		$data = array();
		$data['errorMsg'] = '';
        $data['postData'] = $this->input->post();
		$this->load->model('user_model');
		
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
		$this->load->library('recaptcha');
		
    	if (isset($data['postData']['subscribe']) ) {
		
			$this->recaptcha->recaptcha_check_answer();
			if($this->recaptcha->getIsValid()){
				// generate api key			
				$APIkey = $this->user_model->generateRandomString();
				$auth_token = $this->user_model->generateRandomString();
				
				$userInsert = array();
				$userInsert['`username`'] = $data['postData']['username'];
				$userInsert['`email`'] = $data['postData']['email'];
				$userInsert['`password`'] = md5($data['postData']['password']) ;
				$userInsert['`apicode`'] =  $APIkey;
				$userInsert['`auth_token`'] =  $auth_token;
				$userInsert['`user_type`'] = 'siteuser';
				$statId = $this->user_model->globalInsert('users', $userInsert);
				
				// get points for free emails
				$FreePoints = $this->user_model->getFreePoints();
				
				// add user points
				$userInsertPoint = array();
				$userInsertPoint['`userid`'] = $statId;
				$userInsertPoint['`point`'] = $FreePoints->no_of_mail;
				$userInsertPoint['`membership_type`'] = 1;
				$userInsertPoint['`start_date`'] = date('Y-m-d h:i:s');
				$userInsertPoint['`end_date`'] = '';
				$lastPointId = $this->user_model->globalInsert('emailpoints', $userInsertPoint);	
				
				
				//add transection details
				$userInsertTxn = array();
				$userInsertTxn['`userid`'] = $statId;
				$userInsertTxn['`txn_id`'] = '';
				$userInsertTxn['`item_name`'] = 'free';
				$userInsertTxn['`mc_gross`'] = '0.00';
				$userInsertTxn['`mc_currency`'] = 'USD';
				$userInsertTxn['`payment_date`'] = date('Y-m-d H:i:s');
				$userInsertTxn['`payment_status`'] = 'Completed';
				$userInsertTxn['`payer_email`'] = $data['postData']['email'];
				$lastTxnId = $this->user_model->globalInsert('transection_details', $userInsertTxn);	
				
				/* Mail to user for activate his account */
				$bodyTemp = $this->user_model->getEmailBody('registration');
				$replacement = array(
                                '#username#' => $data['postData']['username'],
                                '#password#' => $data['postData']['password']);
				$html = $this->commonfunctions->sendMailWithEmailTemplate($bodyTemp , $replacement);
				
				$subject = $bodyTemp->subject;
				$to = $data['postData']['email'];
				/*
				echo "subject=".$subject;
				echo "<br>";
				echo "to = ".$to;
				echo "<br>";
				echo "<pre>";
				print_r($html);
				exit;
				*/
				$this->commonfunctions->sendMail($to, 'noreplay@silvertouch.com', $subject, $html);
				$this->session->set_userdata(array('successMessage' => "Your Account is created"));
				
				$newdata = array(
				   'login_email'  => $data['postData']['email'],
				   'login_username'  => $data['postData']['username'],
				   'login_id' => $statId,
				   'APIkey' => $APIkey,
				);
				
				$this->session->set_userdata($newdata);
				$this->commonfunctions->header_redirect(site_url(array('emails','index')));
			}
			else{
				if(!$this->recaptcha->getIsValid()) {
					$this->session->set_userdata(array('errorMessage' => "Incorrect captcha"));
				} else {
					$this->session->set_userdata(array('errorMessage' => "captcha details inncorrect"));
				}
			}           
        }
		
		$data['recaptcha_html'] = $this->recaptcha->recaptcha_get_html();
		$data['page'] = 'login/login';
		
		$data['enabledbreadPanels'] = array('bredcrum_account');
		$data['enabledSidePanels'] = array('sidebar_signup');
        $this->session->set_userdata($cdata);
        $this->layout->view('user/register',$data);
    }
	
	function checkUserName(){
		$this->load->model('user_model');
		if(isset($_POST['email']))//If a username has been submitted
		{
			$username = mysql_real_escape_string($_POST['email']);//Some clean up :)
			$check_for_username = $this->user_model->user_name_exists($username);
			if($check_for_username)
			{
				echo 'false';//If there is a  record match in the Database - Not Available
			}
			else
			{
				echo 'true';//No Record Found - Username is available
			} 
		}
	}
	
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
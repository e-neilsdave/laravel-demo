<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Guest_user extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        Commonfunctions::loadLanguageFiles();
    }
    
    public function index() {
        $data = array();
		$data['enabledbreadPanels'] = array('bredcrum_guest_home');
        $this->layout->view('guest_user/index', $data);
    }
	
	public function feature() {
        $data = array();
		$data['enabledbreadPanels'] = array('bredcrum_guest_feature');
        $this->layout->view('guest_user/feature', $data);
    }
	

	public function pricing() {
        $data = array();
		$this->load->model('admin_model');
		$this->load->model('emails_model');
		$userid = $this->session->userdata('login_id');
		
		if($userid != ''){
			$data['membershiptype'] = $this->emails_model->getMembershipType($userid);
		}
		
		$data['pricingDetails'] = $this->admin_model->getPricingDetails();
		$data['enabledbreadPanels'] = array('bredcrum_guest_pricing');
		$this->layout->view('guest_user/pricing', $data);
    }
	
	function errorPage(){
       $data = array();
       $this->layout->view('guest_user/errorPage', $data);
    }
	
	function help(){
		$data = array();
		$data['enabledbreadPanels'] = array('bredcrum_help');
        $this->layout->view('guest_user/help', $data);
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
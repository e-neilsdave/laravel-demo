<?php

$lang['general_enter_password'] = "Please enter the password.";
$lang['general_enter_confirm_password'] = "Please enter the confirm password.";
$lang['general_password_not_match'] = "Passwords do not match.";
$lang['general_password_changed'] = "Your password has been changed successfully.";
$lang['general_enter_username'] = "Please enter the user name.";
$lang['general_password_sent'] = "Your new password is sent to your email address.";
$lang['general_invalid_username'] = "Invalid user name.";

$lang['general_username_exists'] = "Username already exists.";
$lang['general_email_exists'] = "Email address already exists.";
$lang['general_invalid_username_password'] = "Invalid user name or password.";
$lang['general_label_password'] = "Password";
$lang['general_label_confirm_password'] = "Confirm password";
$lang['general_label_change_password'] = "Change password";

$lang['general_label_username'] = "User name";
$lang['general_back_to_login'] = "Back to login";
$lang['general_label_reset'] = "Reset";
$lang['general_logged_in_as'] = "Logged in as";
$lang['general_you_are_here'] = "You are here";
$lang['general_label_my_profile'] = "My profile";
$lang['general_label_logout'] = "Logout";

$lang['general_copy_right'] = "Copyright &copy; 2012 boo (bezoo philippe) for goobing GmbH. All rights reserved.";
$lang['general_lost_password'] = "I have lost my password";
$lang['general_label_login'] = "Login";
$lang['general_label_first_name'] = "First name";
$lang['general_label_last_name'] = "Last name";
$lang['general_label_email'] = "Email";
$lang['general_label_language'] = "Language";
$lang['general_label_submit'] = "Submit";
$lang['general_label_cancel'] = "Cancel";
$lang['general_label_back'] = "Back";
$lang['general_breadcrumb_forgot_password'] = "Forgot Password";

$lang['general_access_denied_title'] = "Access Denied";
$lang['general_access_denied_content'] = "Sorry, you are not authorized to view this page. Please contact your administrator to grant this permission to you.";
$lang['general_label_confirm'] = "Confirm";
$lang['general_label_confirm_and_save'] = "Confirm and save";
$lang['Required_Field'] = "Required field";

$lang['general_enter_email'] = "Please enter email address";
$lang['general_enter_password'] = "Please enter the password.";
$lang['general_invalid_username_password'] = "Email and Password is invalid.";
$lang['login_success'] = "Login Successfully";

$lang['general_label_emailAddress'] = "Email Address";

$lang['general_password_not_match'] = 'Entered password do not match.';
$lang['general_enter_user_name'] = "Please enter the username.";


$lang['general_enter_confirm_password'] = "Please enter the confirm password.";


$lang['general_email_exists'] = "This email already exists.";

$lang['general_enter_valid_email'] = "Please enter a valid email address.";

?>

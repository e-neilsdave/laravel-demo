<?php
/*
$currentController = $this->router->class;
$currentMethod = $this->router->method;

$breedCrumbs = array();

if($currentController == 'home' && $currentMethod == 'login') {
    if ($this->session->userdata('login_id') != '' && $this->session->userdata('login_id') != '0') {
        $this->commonfunctions->header_redirect(GLOBAL_PATH . 'home/index');
    }
} else {
    if($currentMethod != 'forgotpassword') {
        if ($this->session->userdata('login_id') == '' || $this->session->userdata('login_id') == '0') {
            $this->commonfunctions->header_redirect(GLOBAL_PATH . 'home/login');
        }
    }
} 
*/
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta name="description" content="Email Validator">
<meta name="keywords" content="Email Validator">
<meta name="author" content="silvertouch.com">
<meta charset="UTF-8">

<title>Email Validator</title>
<link rel="shortcut icon" href="<?php echo $this->config->item('base_url'); ?>images/favicon.ico" type="image/x-icon"/>
<link href="<?php echo $this->config->item('base_url'); ?>css/themes/temp/stylesheets/style.css" media="all" rel="stylesheet" type="text/css" />


<script type="text/javascript" src="<?php echo $this->config->item('base_url'); ?>js/jquery.js"></script>
<script type="text/javascript" src="<?php echo $this->config->item('base_url'); ?>js/jquery.min.js"></script>
<!-- <script type="text/javascript" src="<?php echo $this->config->item('base_url');?>js/jquery-1.7.1.min.js"></script>-->
 <script type="text/javascript" src="<?php echo $this->config->item('base_url');?>js/jquery.validate.js"></script>
 <script type="text/javascript" src="<?php echo $this->config->item('base_url');?>js/validation_rule.js"></script>
</head>
<body>
<div id="wrapper">

	<?php $this->load->view('includes/header');?>
	<?php $this->load->view('includes/navigation_menu'); ?>
	<?php $this->load->view('includes/breadcrum'); ?>
  
	<div id="content">
		<div class="container"> 
			<?php echo $content_for_layout ?>
			<?php $this->load->view('includes/sidebar_right'); ?>
		</div>	
	</div>
  
</div>
<?php $this->load->view('includes/footer');?>

<script type="text/javascript" src="<?php echo $this->config->item('base_url'); ?>js/ddaccordion.js"></script>
<script type="text/javascript" src="<?php echo $this->config->item('base_url'); ?>js/script.js"></script>
<script type="text/javascript" src="<?php echo $this->config->item('base_url'); ?>js/envato.js"></script>

</body>
</html>

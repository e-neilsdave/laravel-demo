<h1 class="page-title">Pricing</h1>
<div class="messageline">
the industry lowest SMS message gateway's prices
</div>
<?php 
$errorMessage = $this->session->userdata('errorMessage');
if(trim($errorMessage) != '') { 
	echo '<div id="messageStatus" class="errorMessageHeader"><span>'.trim($errorMessage).'</span></div>'; 
	$this->session->set_userdata(array('errorMessage' => ''));
}
?>			
<div class="col-s-content-project">
	<div class="left-part-project">  
		<div id="items" class="shadowed">
		<div class="inner-boundaries">
		<div class="gried-view">
		<div class="project-box">
		<div class="gray-box-bg">
		<table width="100%" cellspacing="0" cellpadding="0" border="0" style=" text-align: center;">
             <thead>
                <tr>
					<?php $i=0;foreach($pricingDetails as $data) {
					if($data->status == 1){
						if($i == 0) { ?>
							<td class="noborder">&nbsp;</td>
						<?php } ?>
						<td>
							<div class="priceHeaderTitle">
								<h2><?php echo $data->mailtype;?></h2>
							</div>					
						</td>
						<?php }
						$i++;
					}	
					?>
				</tr>
			</thead>
                  
			<tbody>
				<tr class="priceTitle">
					<td style="text-align:right">Price:</td>
					<?php 
					foreach($pricingDetails as $data) {
						if($data->status == 1){
						?>	
						<td>
							<h3><?php echo "$".$data->price; ?></h3>
						</td> 
						<?php 
						}
					} ?>
                </tr>
				
				<tr class="priceTitle">
					<td style="text-align:right">Registration:</td>
					<?php 
					foreach($pricingDetails as $data) { 
						if($data->status == 1){
						?>					
						<td>
							<h3><?php if($data->registration == '1') { echo "Yes";}else{echo "No";} ?></h3>
						</td>
						<?php
						}
					} ?>
                </tr>
				
				<tr class="priceTitle">
					<td style="text-align:right">How Many:</td>
					<?php 
					foreach($pricingDetails as $data) { 
						if($data->status == 1){
						?>					
						<td>
							<h3><?php echo $data->no_of_mail;?></h3>
						</td>
						<?php
						}
					} ?>
                </tr>
				
				<tr class="priceTitle">
					<td style="text-align:right">Method:</td>
					<?php 
					foreach($pricingDetails as $data) { 
						if($data->status == 1){
						?>					
						<td>
							<h3>
							<?php 
							if($data->method == 0) { echo "Physical";}
							if($data->method == 1) { echo "+Bulk";}
							if($data->method == 2) { echo "+Web Service";}
							?></h3>
						</td>
						<?php
						}
					} ?>
                </tr>
				
				<tr class="priceTitle">
					<td style="text-align:right">Validity:</td>
					<?php 
					foreach($pricingDetails as $data) { 
						if($data->status == 1){
						?>					
						<td>
							<h3>
							<?php 
							if($data->validity == 0) { echo "Always On";}
							if($data->validity == 1) { echo $data->validity_month." Month";}
							if($data->validity == 2) { echo $data->validity_year." Year";}
							?></h3>
						</td>
						<?php
						}
					} ?>
                </tr>
				
				<tr class="priceTitle">
					<td style="text-align:right">Bulk Limit:</td>
					<?php 
					foreach($pricingDetails as $data) { 
						if($data->status == 1){
						?>					
						<td>
							<h3>
							<?php 
							if($data->bulk_limit == 0) { echo "No Bulk Facility";}
							else{
								echo "Upto ".$data->bulk_limit." Email";
							}
							?></h3>
						</td>
						<?php
						}
					} ?>
                </tr>
				
				
				<tr class="priceTitle">
					<td style="text-align:right">Max Per Day:</td>
					<?php 
					foreach($pricingDetails as $data) { 
						if($data->status == 1){
						?>					
						<td>
							<h3><?php echo $data->max_per_day;?></h3>
						</td>
						<?php
						}
					} ?>
                </tr>  
                
				  
                
            </tbody>

            <tfoot>
                  <tr>
                    <td>&nbsp;</td>
					<?php foreach($pricingDetails as $data) {
					if($data->status == 1){	?>
                    <td>
						<?php if ($this->session->userdata('login_id') != '') { ?>
						<a onclick="gocheckCart(<?php echo $data->id; ?>)" id="various<?php echo $data->id; ?>" href="#inline<?php echo $data->id; ?>" class="submit-button-dark"><span class="sprite"><em class="sprite">Get Started</em></span></a>
						<?php } else { ?>
						<a href="<?php echo GLOBAL_PATH . 'emails/cartpage/'.$data->id; ?>" class="submit-button-dark"><span class="sprite"><em class="sprite">Get Started</em></span></a>
						<?php } ?>
					</td>
					<?php } } ?>
				  </tr>
                  </tfoot>
                </table>
		 
		</div>
		</div>
		</div>
		</div>
		</div>
	</div>
</div>

<div style="display:none;">
	<div class="popupbox" id="inline2">
	</div>
	<div class="popupbox" id="inline3">
	</div>
	<div class="popupbox" id="inline4">
	</div>
	<div class="popupbox" id="inline5">
	</div>
</div>	

<SCRIPT language="javascript">
$(document).ready(function() {
		$('#messageStatus').fadeOut(5000);
});
</SCRIPT>

<script type="text/javascript" src="<?php echo $this->config->item('base_url');?>js/css3-mediaqueries.js"></script>
<script type="text/javascript" src="<?php echo $this->config->item('base_url');?>js/jquery.fancybox-1.3.4.pack.js"></script>
<script type="text/javascript">
function gocheckCart(username)
		{
			$.ajax({  //Make the Ajax Request
					type: "POST",
					url: "<?php echo GLOBAL_PATH . 'emails/cartpage/'; ?>",  //file name
					data: "username="+ username,  //data
					
					success: function(server_response){
						$("#inline"+username).html(server_response);
					}

				});
		
		}
		$(document).ready(function() {
		
			$("#various2").fancybox({
				'titlePosition'		: 'inside',
				'transitionIn'		: 'none',
				'transitionOut'		: 'none'
			});

$("#various3").fancybox({
				'titlePosition'		: 'inside',
				'transitionIn'		: 'none',
				'transitionOut'		: 'none'
			});
$("#various4").fancybox({
				'titlePosition'		: 'inside',
				'transitionIn'		: 'none',
				'transitionOut'		: 'none'
			});
$("#various5").fancybox({
				'titlePosition'		: 'inside',
				'transitionIn'		: 'none',
				'transitionOut'		: 'none'
			});			
		});
</script>
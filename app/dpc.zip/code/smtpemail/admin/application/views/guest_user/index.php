<h1 class="page-title"></h1>
<div class="col-s-content-project">
	<div class="left-part-project">  
		<div id="items" class="shadowed">
		<div class="inner-boundaries">
		<div class="gried-view">
		<div class="project-box">
		<div class="gray-box-bg">
		
			<div class="slide-image">
			<img width="400" height="300" border="0" alt="Text Message Examples" src="<?php echo $this->config->item('base_url'); ?>images/mail.jpg">
			</div>
			
			<div class="slide-text-right">
			<br><br>
			<div class="slide-title"><h1>Send Text Messages via our <br>Free SMS Gateway and API</h1></div>
			<div class="slide-descr">
		   
			  <p><strong>Free SMS Gateway</strong> is a simple way way for you to <strong>send text messages</strong> to a group of people via our simple interface or robust API. Integration just takes a few minutes.</p>
			  
			 
			</div>
		   <br>

			<div class="clear"></div>
				<a class="homepage_button" href=""></a>
			</div> 
		</div>
		</div>
		</div>
		</div>
		</div>
	</div>
</div>
<?php //echo "<pre>";print_r($membershiptype);?>
<?php //echo "<pre>";print_r($pricingDetails); ?>
<?php 

//tablecolActive; ?>
<h1 class="page-title">Pricing</h1>
<div class="messageline pkgSummaryBlock">
<div>Your current package is = <strong><?php echo $membershiptype->mailtype;?></strong></div>
<!--<div>Your package expiry date is = <strong><?php //echo date('d-m-Y h:i A',strtotime($membershiptype->end_date));?></strong></div>-->
<div>Your package expiry date is = <strong><?php echo $membershiptype->payment_enddate;?></strong></div>
<div>Your Point is = <a href="<?php echo GLOBAL_PATH . 'emails/myorderdetails'; ?>"><strong><?php echo $membershiptype->point;?></strong></a></div>
</div>
<?php 
$errorMessage = $this->session->userdata('errorMessage');
if(trim($errorMessage) != '') { 
	echo '<div id="messageStatus" class="errorMessageHeader"><span>'.trim($errorMessage).'</span></div>'; 
	$this->session->set_userdata(array('errorMessage' => ''));
}
?>			
<div class="col-s-content-project">
	<div class="left-part-project">  
		<div id="items" class="shadowed">
		<div class="inner-boundaries">
		<div class="gried-view">
		<div class="project-box">
		<div class="gray-box-bg">
		<table width="100%" cellspacing="0" cellpadding="0" border="0" style=" text-align: center;">
             <thead>
                <tr>
					<?php $i=0;foreach($pricingDetails as $data) {
					if($data->status == 1){
						if($i == 0) { ?>
							<td class="noborder">&nbsp;</td>
						<?php } ?>
						<td>
							<div class="priceHeaderTitle">
								<h2><?php echo $data->mailtype;?></h2>
							</div>					
						</td>
						<?php }
						$i++;
					}	
					?>
				</tr>
			</thead>
                  
			<tbody>
				<tr class="priceTitle">
					<td  style="text-align:center">Price :</td>
					<?php 
					foreach($pricingDetails as $data) {
						
						// for active class
						
						
						if($data->status == 1){
						?>	
						<td class="<?php if($membershiptype->membership_type == $data->id) { ?> tablecolActive <?php } ?>">
							<h3><?php echo "$".$data->price; ?></h3>
						</td> 
						<?php 
						}
					} ?>
                </tr>
				
				<tr class="priceTitle">
					<td style="text-align:center">Registration :</td>
					<?php 
					foreach($pricingDetails as $data) { 
						if($data->status == 1){
						?>					
						<td class="<?php if($membershiptype->membership_type == $data->id) { ?> tablecolActive <?php } ?>">
							<h3><?php if($data->registration == '1') { echo "Yes";}else{echo "No";} ?></h3>
						</td>
						<?php
						}
					} ?>
                </tr>
				
				<tr class="priceTitle">
					<td style="text-align:center">How Many :</td>
					<?php 
					foreach($pricingDetails as $data) { 
						if($data->status == 1){
						?>					
						<td class="<?php if($membershiptype->membership_type == $data->id) { ?> tablecolActive <?php } ?>">
							<h3><?php echo $data->no_of_mail;?></h3>
						</td>
						<?php
						}
					} ?>
                </tr>
				
				<tr class="priceTitle">
					<td style="text-align:center">Method :</td>
					<?php 
					foreach($pricingDetails as $data) { 
						if($data->status == 1){
						?>					
						<td class="<?php if($membershiptype->membership_type == $data->id) { ?> tablecolActive <?php } ?>">
							<h3>
							<?php 
							if($data->method == 0) { echo "Physical";}
							if($data->method == 1) { echo "+Bulk";}
							if($data->method == 2) { echo "+Web Service";}
							?></h3>
						</td>
						<?php
						}
					} ?>
                </tr>
				
				<tr class="priceTitle">
					<td style="text-align:center">Validity :</td>
					<?php 
					foreach($pricingDetails as $data) { 
						if($data->status == 1){
						?>					
						<td class="<?php if($membershiptype->membership_type == $data->id) { ?> tablecolActive <?php } ?>">
							<h3>
							<?php 
							if($data->validity == 0) { echo "Always On";}
							if($data->validity == 1) { echo $data->validity_month." Month";}
							if($data->validity == 2) { echo $data->validity_year." Year";}
							?></h3>
						</td>
						<?php
						}
					} ?>
                </tr>
				
				<tr class="priceTitle">
					<td style="text-align:center">Bulk Limit :</td>
					<?php 
					foreach($pricingDetails as $data) { 
						if($data->status == 1){
						?>					
						<td class="<?php if($membershiptype->membership_type == $data->id) { ?> tablecolActive <?php } ?>">
							<h3>
							<?php 
							if($data->bulk_limit == 0) { echo "No Bulk Facility";}
							else{
								echo "Upto ".$data->bulk_limit." Email";
							}
							?></h3>
						</td>
						<?php
						}
					} ?>
                </tr>
				
				
				<tr class="priceTitle">
					<td style="text-align:center">Max Per Day :</td>
					<?php 
					foreach($pricingDetails as $data) { 
						if($data->status == 1){
						?>					
						<td class="<?php if($membershiptype->membership_type == $data->id) { ?> tablecolActive <?php } ?>">
							<h3><?php echo $data->max_per_day;?></h3>
						</td>
						<?php
						}
					} ?>
                </tr>  
                
				  
                
            </tbody>

            <tfoot>
                  <tr>
                    <td>&nbsp;</td>
					<?php foreach($pricingDetails as $data) {
					if($data->status == 1){	?>

                    
					
					<?php
					if($membershiptype->membership_type == $data->id) { ?> 
					
					
					<?php if($membershiptype->end_date < date('Y-m-d H:i:s') || $membershiptype->point == 0 ){ ?>
						
						<td class=""><br />
						<a onclick="gocheckCart(<?php echo $data->id; ?>)" id="various<?php echo $data->id; ?>" href="#inline<?php echo $data->id; ?>" class="submit-button-dark"><span class="sprite"><em class="sprite">
						Renew	
						</em></span></a>
					</td>
					<?php } else { ?>
						<!--<td class=""><br />
							<?php //if ($this->session->userdata('login_id') != '') { ?>
							<button disable="disable" id="mc-embedded-subscribe1" class="submit-button-dark"><span class="sprite"><em class="sprite">Current Package</em></span></button>
							<?php //} ?>
						</td>-->
						
						<td class=""><br />
						<a onclick="gocheckCart(<?php echo $data->id; ?>)" id="various<?php echo $data->id; ?>" href="#inline<?php echo $data->id; ?>" class="submit-button-dark"><span class="sprite"><em class="sprite">
						Renew	
						</em></span></a>
						
					<?php } ?>
					
					
					<?php } else { ?>
					
					<td class="">
						<?php if ($this->session->userdata('login_id') != '') { ?>
						
						<a onclick="gocheckCart(<?php echo $data->id; ?>)" id="various<?php echo $data->id; ?>" href="#inline<?php echo $data->id; ?>" class="submit-button-dark"><span class="sprite"><em class="sprite">
						
						<?php if($membershiptype->membership_type > $data->id){ ?>
						Down Grade
						<?php } else { ?>
						Up Grade
						<?php } ?>	
						</em></span></a>
						
						<?php } else { ?>
						<a href="<?php echo GLOBAL_PATH . 'emails/cartpage/'.$data->id; ?>" class="submit-button-dark"><span class="sprite"><em class="sprite">Upgrade</em></span></a>
						<?php } ?>
					</td>					

					<?php } ?>

					<?php } } ?>
				  </tr>
                  </tfoot>
                </table>
		 
		</div>
		</div>
		</div>
		</div>
		</div>
	</div>
</div>

<div style="display:none;">
	<div class="popupbox" id="inline2">
	</div>
	<div class="popupbox" id="inline3">
	</div>
	<div class="popupbox" id="inline4">
	</div>
	<div class="popupbox" id="inline5">
	</div>
</div>	

<SCRIPT language="javascript">
$(document).ready(function() {
		$('#messageStatus').fadeOut(5000);
});
</SCRIPT>

<script type="text/javascript" src="<?php echo $this->config->item('base_url');?>js/css3-mediaqueries.js"></script>
<script type="text/javascript" src="<?php echo $this->config->item('base_url');?>js/jquery.fancybox-1.3.4.pack.js"></script>
<script type="text/javascript">
function gocheckCart(username)
		{
			$.ajax({  //Make the Ajax Request
					type: "POST",
					url: "<?php echo GLOBAL_PATH . 'emails/cartpage/'; ?>",  //file name
					data: "username="+ username,  //data
					
					success: function(server_response){
						$("#inline"+username).html(server_response);
					}

				});
		
		}
		$(document).ready(function() {
		
			$("#various2").fancybox({
				'titlePosition'		: 'inside',
				'transitionIn'		: 'none',
				'transitionOut'		: 'none'
			});

$("#various3").fancybox({
				'titlePosition'		: 'inside',
				'transitionIn'		: 'none',
				'transitionOut'		: 'none'
			});
$("#various4").fancybox({
				'titlePosition'		: 'inside',
				'transitionIn'		: 'none',
				'transitionOut'		: 'none'
			});
$("#various5").fancybox({
				'titlePosition'		: 'inside',
				'transitionIn'		: 'none',
				'transitionOut'		: 'none'
			});			
		});
</script>
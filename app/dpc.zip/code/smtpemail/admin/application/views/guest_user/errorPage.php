<style>
    .errorAccessPage{background-color: white;
font-family: "Lucida Grande",Helvetica,Verdana,Arial,sans-serif;
font-size: 22px;
line-height: 30px;
text-align: center;
color: #E77319;
margin: 0 auto;
padding-top: 60px;}
</style>

<div class="errorAccessPage">
<img src="<?php echo $this->config->item('base_url'); ?>/img/wartung.jpg" height="30" width="359" alt=""><br><br>
You are not authorized to access this page.
</div>

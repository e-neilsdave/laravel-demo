<h1 class="page-title">Features</h1>
<div class="messageline">
everything you want and need in a sms gateway
</div>

<div class="col-s-content-project">
	<div class="left-part-project">  
		<div id="items" class="shadowed">
		<div class="inner-boundaries">
		<div class="gried-view">
		<div class="project-box">
		<div class="gray-box-bg">
		<div class="textnew">
			<p>Free SMS Gateway is packed full of all the features you could ever need a web based SMS gateway. All these features are included for free and come with every account. Feel free to let us know if there is something that you require that you do not see listed here.</p>
            
            <div class="row">
                <div class="col col_1_3 box_textstyle-1 alpha">
                    <h2><span>Import Contacts</span> From a list or by hand</h2>                  
                    <div class="clear"></div>
                    <p>Easily import contacts via a text list, csv file or enter by hand as you grow. Contacts can be organized in lists for segmented text messaging and easy account management.</p>
   		  		</div>
                <div class="col col_1_3 box_textstyle-1">
                	<h2><span>Easy To Use</span> Very simple interface</h2>
                    <div class="clear"></div>
                    <p>An incredibly simple interface with no learning curve is standard. API integration can be completed in just minutes enabling you to start sending text messages right away.</p>           
          		</div>
          		<div class="col col_1_3 box_textstyle-1 omega">
           			<h2><span>Full Reporting</span> Detailed and simple</h2>
                    <div class="clear"></div>
                    <p>Easily view past messages, sent dates, billing statements and more. This allows you to track when you send what message to who and what the contents of the message was.</p>
                </div>
			</div>
          	<div class="divider"></div>
            
            <div class="row">
          		<div class="col col_1_3 box_textstyle-1 alpha">
                	<h2><span>API Access</span> Robust JSON interface</h2>                  
                    <div class="clear"></div>
                    <p>Easily integrate any existing application via our simple HTTP POST JSON API. Using cURL, the API intergration can be completed in just minutes. See our <a href="/api">API Documentation</a>.</p>
                    
	  			</div>
                
                <div class="col col_1_3 box_textstyle-1">
                	<h2><span>Secure Payment Processing</span> 256 bit file encryption</h2>
                    <div class="clear"></div>
                    <p>Your data and credit card are fully secured and PCI compliant. We use PayPal for monthly payment process and do not store any of your payment details on our site.</p>             
          		</div>
                
          		<div class="col col_1_3 box_textstyle-1 omega">
   				 	<h2><span>No Contracts</span> Change plans anytime</h2>
                    <div class="clear"></div>
                    <p>You can login to your account and switch plans or cancel your account at anytime. Each account starts out free and a credit card is only required when you upgrade to a paid plan.</p>
    			</div>
			</div>
        </div> 
		</div>
		</div>
		</div>
		</div>
		</div>
	</div>
</div>


      <h1 class="page-title">Dashboard</h1>
      <div class="col-s-content-project">
        <div class="left-part-project">
          <div class="shadowed DashboardArea" id="items">
            <div class="inner-boundaries gp1">
              <div class="gried-view">
                <div class="project-box">
                  <div class="gray-box-bg">
                    <ul class="dashboardUL">
                      <li class="icon1"><a href="<?php echo site_url(array('admin','userlist')); ?>" title="Customers">Customers</a></li>
                      
                      <li class="icon4"><a href="<?php echo site_url(array('admin','emailtemplatelist')); ?>" title="Email Templates">Email Templates</a></li>
                      <li class="icon6"><a href="<?php echo site_url(array('admin','price_setting')); ?>" title="Price Settings">Price Settings</a></li>
					  <li class="icon11"><a href="<?php echo site_url(array('admin','transectiondetail')); ?>" title="Transactions">Transactions</a></li>
                      <li class="icon12"><a href="<?php echo site_url(array('admin','adminLog')); ?>" title="Logs">Logs</a></li>
					  <li class="icon17"><a href="<?php echo site_url(array('admin','news_later')); ?>" title="Newsletter">Newsletter</a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    

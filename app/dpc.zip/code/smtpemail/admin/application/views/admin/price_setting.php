<?php //echo "<pre>";print_R($allpricesetting);?>
<h1 class="page-title">Price Settings</h1>
<?php 
	$successMessage = $this->session->userdata('successMessage');
	if(trim($successMessage) != '') { 
		echo '<div class="successMessageHeader"><span>'.trim($successMessage).'</span></div>'; 
		$this->session->set_userdata(array('successMessage' => ''));
	}
?>
<div class="col-s-content-project">
	<div class="left-part-project">
		<div class="shadowed" id="items">
			<div class="inner-boundaries">
				<div class="gried-view">
					<div class="project-box">
						<div class="gray-box-bg">
							<table cellpadding="0" cellspacing="0" border="0" width="100%" class="gridViewTable" >
								<tr>
									<th style="width:30px" align="left">Id</th>
									<th align="left">Package Type</th>
									<th align="left">Price</th>
									<th align="left">Discount</th>
									<th align="left">Old Price</th>
									<th align="left">Number of Emails</th>
									<th align="left">Registration</th>
									<th align="left">Action</th>
								</tr>
								<?php
								$idNo = $start+1;
								$classADD = 0;
								if(count($allpricesetting) > 0){
								foreach($allpricesetting as $number => $data) {
								?>
								<tr <?php echo $classADD == 0 ? "class = 'odd'" : "class = 'even'";?>>
									<td><?php echo $idNo;?></td>
									<td><?php echo $data->mailtype;?></td>
									<td><?php echo $data->price;?></td>
									<td><?php echo $data->discount;?></td>
									<td><?php echo $data->old_price;?></td>
									<td><?php echo $data->no_of_mail;?></td>
									<td><?php if($data->registration == 1) { echo "Yes"; }else { echo "No"; };?></td>
									<td>
									<a onclick="return confirm('<?php echo "Are you sure want to ".( ($data->status == 0) ? 'active' : 'inactive')." this package?"; ?>');" href="<?php echo GLOBAL_PATH . 'admin/price_setting?pid='.$data->id.'&action=status&status='.( ($data->status == 0) ? '1' : '0'); ?>" class="changestatus">
									<?php if($data->status == 0) { ?>
									<img src="<?php echo $this->config->item('base_url'); ?>images/publish_x.png" alt="" class="" title="Inactive">
									<?php } else { ?>
									<img src="<?php echo $this->config->item('base_url'); ?>images/spacer.png" alt="" class="sprite-smallicon sprite-smallicon_05" title="Active">
									<?php } ?>
									</a>
									<a href="<?php echo GLOBAL_PATH . 'admin/PriceSettingEdit?Itemid='.$data->id; ?>">
									<img src="<?php echo $this->config->item('base_url'); ?>images/spacer.png" alt="" class="sprite-smallicon sprite-smallicon_08" title="Edit">
									</a>
						<!--			<a class="delete" href="<?php //echo GLOBAL_PATH . 'admin/price_setting?nid='.$data->id.'&action=delete'; ?>">
									<img src="<?php //echo $this->config->item('base_url'); ?>images/spacer.png" alt="" class="sprite-smallicon sprite-smallicon_07" title="Delete">
									</a> -->
									</td>
								</tr>
								<?php $idNo++; $classADD = 1 - $classADD;}
								} else { ?>
								<tr class="odd">
									<td colspan='4'><?php echo "No Emails";?></td>
								</tr>
							<?php }
							?>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div style="float:left;width:200px;margin-top:40px;"></div>
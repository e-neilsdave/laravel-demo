<!--<SCRIPT language="javascript">
$(function(){ 
    // add multiple select / deselect functionality
    $("#selectall").click(function () {
          $('.checkbox').attr('checked', this.checked);
    });
    $(".checkbox").click(function(){
        if($(".checkbox").length == $(".checkbox:checked").length) {
            $("#selectall").attr("checked", "checked");
        } else {
            $("#selectall").removeAttr("checked");
        }
    });
});
</SCRIPT>-->

<?php //echo "<pre>";print_R($allusers);?>
	<h1 class="page-title">All Users</h1>
    <?php 
	$successMessage = $this->session->userdata('successMessage');
	if(trim($successMessage) != '') { ?>
	<table>
		<tr class="title">
			<th align="center" valign="middle" height="25" colspan="7" class="successMessage">
				<?php
				echo trim($successMessage); 
				$this->session->set_userdata(array('successMessage' => '')); ?>
			</th>
		</tr>
	</table>
	<?php } ?>	
	<?php 
	$errorMessage = $this->session->userdata('errorMessage');
	if(trim($errorMessage) != '') { 
		echo '<div class="errorMessage"><span>'.trim($errorMessage).'</span></div>'; 
		$this->session->set_userdata(array('errorMessage' => ''));
	}
	?>
	
	<div class="col-s-content-project">
        <div class="left-part-project">
		<form action="" class="selection fancy-form order" method="get">
        <div class="gried-view">
            <div class="project-list-box">
              <div class="sorter date-sorter">
				<?php 
				if(!isset($_GET['sort_by'])) {
					$_GET['sort_by'] = 25;
				}
				?>
	            <label class="font-9" for="sort_by">Show </label>
                <select style="width:30px;" class="sort_order" id="sort_by" name="sort_by" onchange="$('.checkbox').attr('checked', false); this.form.submit()" >
					<option value="5" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '5') { ?> selected = "selected" <?php } ?>>5</option>
					<option value="10" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '10') { ?> selected = "selected" <?php } ?>>10</option>
					<option value="15" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '15') { ?> selected = "selected" <?php } ?>>15</option>
					<option value="25" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '25') { ?> selected = "selected" <?php } ?>>25</option>
					<option value="50" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '50') { ?> selected = "selected" <?php } ?>>50</option>
					<option value="100" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '100') { ?> selected = "selected" <?php } ?>>100</option>
					<option value="-1" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '-1') { ?> selected = "selected" <?php } ?>>All</option>
                </select>
                  <label>&nbsp;&nbsp;&nbsp;Records</label>
				   <input type="text" name="search" class="searchbox_class" onclick="this.value = ''" <?php if(isset($_GET['search']) && $_GET['search'] != 'Search User...') { ?> value="<?php echo $_GET['search'];?>" <?php } else { ?> value="Search User..." <?php } ?> onblur="if(this.value==''){this.value='Search User...'};" />
                  <!--<select style="width:60px;" class="sort_order" id="status" name="status" onchange="$('.checkbox').attr('checked', false); this.form.submit()">
                    <option value="">--Status--</option>
                    <option value="free" <?php //if(isset($_GET['status']) && $_GET['status'] == 'free') { ?> selected = "selected" <?php //} ?>>Free</option>
                    <option value="paid" <?php //if(isset($_GET['status']) && $_GET['status'] == 'paid') { ?> selected = "selected" <?php //} ?>>Paid</option>
                  </select>-->
                  <button onclick="$('.checkbox').attr('checked', false);" class="submit-button-dark" id="mc-embedded-subscribe" type="submit" style="margin-left:10px;"><span class="sprite"><em class="sprite">GO</em></span></button>
				  <!--<button class="submit-button-dark" id="mc-embedded-subscribe" type="submit" style="margin-left:10px;"><span class="sprite"><em class="sprite">Reset</em></span></button>-->
<div style="float:right;"><a href="<?php echo site_url(array('admin','userlist')); ?>" class="submit-button-dark" id="mc-embedded-subscribe"><span class="sprite"><em class="sprite">Reset</em></span></a></div>				  
              </div>
            </div>
          </div>
		
          <div class="shadowed" id="items">
            <div class="inner-boundaries">
              <div class="gried-view">
                <div class="project-box">
                  <div class="gray-box-bg">
					<table cellpadding="0" cellspacing="0" border="0" width="100%" class="gridViewTable" >
                      <tr>
						<!--<th align="left" style="width:30px">
							<input name="selectall" id="selectall" type="checkbox">
						</th>-->
                        <th style="width:30px" align="left">Id</th>
						<th align="left">User Name</th>
                        <th align="left">Email</th>
                        <th align="left">Membership Type</th>
						<th style="width:75px" align="left">Points</th>
						<th align="left">Action</th>
                      </tr>
					    <?php
						$idNo = $start+1;
						$classADD = 0;
						if(count($allusers) > 0){
							foreach($allusers as $number => $data) {
							?>
							<tr <?php echo $classADD == 0 ? "class = 'odd'" : "class = 'even'";?>>
								<!--<td>
								<input name="checkbox[]" class="checkbox" type="checkbox"  value="<?php //echo $idNo; ?>">
								</td>-->
								<td><?php echo $idNo;?></td>
								<td><?php echo $data->username;?></td>
								<td><?php echo $data->email;?></td>
								<td><?php echo $data->mailtype;?></td>
								<td><?php echo $data->point;?></td>
								
								<td>
									<a onclick="return confirm('<?php echo "Are you sure want to ".( ($data->status == 0) ? 'active' : 'inactive')." this user?"; ?>');" href="<?php echo GLOBAL_PATH . 'admin/userlist?uid='.$data->id.'&action=status&status='.( ($data->status == 0) ? '1' : '0'); ?>" class="changestatus">
									<?php if($data->status == 0) { ?>
									<img src="<?php echo $this->config->item('base_url'); ?>images/publish_x.png" alt="" class="" title="Inactive">
									<?php } else { ?>
									<img src="<?php echo $this->config->item('base_url'); ?>images/spacer.png" alt="" class="sprite-smallicon sprite-smallicon_05" title="Active">
									<?php } ?>
									</a>

								</td>
								
							</tr>
							<?php $idNo++; $classADD = 1 - $classADD;}
						}else{ ?>
							<tr class="odd">
								<td colspan='4'><?php echo "No Emails";?></td>
							</tr>
						<?php }
						 ?>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
		  
		  </form>
		<div class="paging-box paging-dashboard">
            <div style="clear:both;" class="pagination margin10-top">               
			  <?php
				echo $pagi_data;
			  ?>
            </div>
        </div>
        </div>
      </div>
	  <div style="float:left;width:200px;margin-top:40px;"></div>
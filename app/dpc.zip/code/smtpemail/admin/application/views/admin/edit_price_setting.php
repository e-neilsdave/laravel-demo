<?php //echo "hi<pre>"; print_r($allusers);?>

<script type="text/javascript">
$(document).ready(function($){
$( "#validity" ).change(function() {
//alert($(this).val());

var n = $(this).val();
if (n == 1) {
	$("#validityMonth").show();
	$("#validityYear").hide();
} 
else if(n == 2){
	$("#validityYear").show();
	$("#validityMonth").hide();
}else if(n == 0){
	$("#validityYear").hide();
	$("#validityMonth").hide();
}

});
});	
</script>

<?php 
	$successMessage = $this->session->userdata('successMessage');
	if(trim($successMessage) != '') { 
		echo '<div class="successMessageHeader"><span>'.trim($successMessage).'</span></div>'; 
		$this->session->set_userdata(array('successMessage' => ''));
	}
?>

<div class="col-s-content">
        <div class="left-part">
          <div id="items" class="shadowed">
            <div class="inner-boundary">
              <div class="signup-content">
                <!--<form id="createAccount" action="index.html" method="post" name="createAccount">-->
					
				 
				<form enctype="application/x-www-form-urlencoded" name="myProfile" class="queryForm" action="<?php echo GLOBAL_PATH; ?>admin/PriceSettingEdit?Itemid=<?php echo $allusers->id;?>"  method="post">
				<div class="add-form-box">  
				<ul>
				
					<li>
					  <?php
						$selectedRegistration = $allusers->registration;
						if(isset($postData['registration'])) {
							$selectedRegistration = $postData['registration'];
						}
						?>
                        <label><em>*</em> Registration:</label>
                        <select class="required add-form-input" name="registration" id="registration">
                          <option value="0" <?php if($selectedRegistration == '0') { ?> selected="selected" <?php } ?>>No</option>
                          <option value="1" <?php if($selectedRegistration == '1') { ?> selected="selected" <?php } ?>>Yes</option>
                        </select>
                        <span class="field_error"> </span> </li>
						
				
                      <li>
                        <label><em>*</em> Package Type:</label>
                        <input type="text" name="mailtype" id="mailtype" value="<?php echo (isset($postData['mailtype'])) ? $postData['mailtype'] : $allusers->mailtype;?>" class="name required add-form-input" />
						<?php echo form_error('mailtype'); ?>
						</li>
                      
						
					
					  <li>
                        <label><em>*</em> Price:</label>
                        <input type="text" name="price" id="price" value="<?php echo (isset($postData['price'])) ? $postData['price'] : $allusers->price;?>" class="name required add-form-input" />
						<?php echo form_error('price'); ?>
						</li>
                 
						<li>
                        <label>Old Price:</label>
                        <input type="text" name="old_price" id="old_price" value="<?php echo (isset($postData['old_price'])) ? $postData['old_price'] : $allusers->old_price;?>" class="name add-form-input" />
						<?php echo form_error('old_price'); ?>
						</li>
						
						<li>
                        <label>Discount:</label>
                        <input type="text" name="discount" id="discount" value="<?php echo (isset($postData['discount'])) ? $postData['discount'] : $allusers->discount;?>" class="name add-form-input" />
						<?php echo form_error('discount'); ?>
						</li>
						
					  
					  <li>
                        <label><em>*</em> No of Mails:</label>
                        <input type="text" name="no_of_mail" id="no_of_mail" value="<?php echo (isset($postData['no_of_mail'])) ? $postData['no_of_mail'] : $allusers->no_of_mail;?>" class="name required add-form-input" />
						<?php echo form_error('no_of_mail'); ?>
						</li>
						
						
						
                     
                      <li>
					  <?php
						$selectedMethod = $allusers->method;
						if(isset($postData['method'])) {
							$selectedMethod = $postData['method'];
						}
						?>
                        <label><em>*</em> Method:</label>
                        <select class="required add-form-input" name="method" id="method" >
                          <option value="0" <?php if($selectedMethod == '0') { ?> selected="selected" <?php } ?> >Physical</option>
                          <option value="1" <?php if($selectedMethod == '1') { ?> selected="selected" <?php } ?> >Bulk</option>
                          <option value="2" <?php if($selectedMethod == '2') { ?> selected="selected" <?php } ?> >Web Service</option>
                        </select>
                        <span class="field_error"> </span> </li>					 
					  
					  
						<li>
						<?php
						$selectedValidity = $allusers->validity;
						if(isset($postData['validity'])) {
							$selectedValidity = $postData['validity'];
						}
						?>
                        <label><em>*</em> Validity:</label>
                        <select class="required add-form-input" id="validity" name="validity" >
                          <option value="0" <?php if($selectedValidity == '0') { ?> selected="selected" <?php } ?> >Always On</option>
                          <option value="1" <?php if($selectedValidity == '1') { ?> selected="selected" <?php } ?> >Months</option>
                          <option value="2" <?php if($selectedValidity == '2') { ?> selected="selected" <?php } ?> >Years</option>
                        </select>
						</li>	
						
						<?php 
						// selected month
						$selectedMonth = $allusers->validity_month;
						if(isset($postData['validity_month'])) {
							$selectedMonth = $postData['validity_month'];
						}
						?>
						<li <?php if($selectedValidity != '1'){ ?> style="display:none" <?php } ?> id="validityMonth" >
						<label><em>*</em> Select Month:</label>
						<select  class="required add-form-input " name="validity_month" >
                          <?php for($m=1;$m<=12;$m++) { ?>
						  <option value="<?php echo $m;?>" <?php if($selectedMonth == $m) { ?> selected="selected" <?php } ?> ><?php echo $m;?></option>
						  <?php } ?>
                        </select>
						</li>
						
						<?php 
						// selected year
						$selectedYear = $allusers->validity_year;
						if(isset($postData['validity_year'])) {
							$selectedYear = $postData['validity_year'];
						}
						?>
						<li <?php if($selectedYear != '2'){ ?> style="display:none" <?php } ?> id="validityYear">
						<label><em>*</em> Select Year:</label>
						<select  class="required add-form-input " name="validity_year"  >
                          <?php for($y=1;$y<=12;$y++) { ?>
						  <option value="<?php echo $y;?>" <?php if($selectedYear == $y) { ?> selected="selected" <?php } ?> ><?php echo $y;?></option>
						  <?php } ?>
                        </select>
						</li>
						
						<li>
						<?php
						$selectedBulkLimit = $allusers->bulk_limit;
						if(isset($postData['bulk_limit'])) {
							$selectedBulkLimit = $postData['bulk_limit'];
						}
						?>
                        <label><em>*</em> bulk_limit:</label>
                        <select class="required add-form-input" id="bulk_limit" name="bulk_limit" >
                          <option value="0" <?php if($selectedBulkLimit == '0') { ?> selected="selected" <?php } ?> >0</option>
                          <option value="10" <?php if($selectedBulkLimit == '10') { ?> selected="selected" <?php } ?> >10</option>
                          <option value="50" <?php if($selectedBulkLimit == '50') { ?> selected="selected" <?php } ?> >50</option>
                          <option value="100" <?php if($selectedBulkLimit == '100') { ?> selected="selected" <?php } ?> >100</option>
                          <option value="500" <?php if($selectedBulkLimit == '500') { ?> selected="selected" <?php } ?> >500</option>
                        </select>
						</li>
						
						
						<li>
						<?php
						$selectedMaxPerDay = $allusers->max_per_day;
						if(isset($postData['max_per_day'])) {
							$selectedMaxPerDay = $postData['max_per_day'];
						}
						?>
                        <label><em>*</em> max_per_day:</label>
                        <select class="required add-form-input" id="max_per_day" name="max_per_day" >
                          <option value="10" <?php if($selectedMaxPerDay == '10') { ?> selected="selected" <?php } ?> >10</option>
                          <option value="50" <?php if($selectedMaxPerDay == '50') { ?> selected="selected" <?php } ?> >50</option>
                          <option value="100" <?php if($selectedMaxPerDay == '100') { ?> selected="selected" <?php } ?> >100</option>
                          <option value="500" <?php if($selectedMaxPerDay == '500') { ?> selected="selected" <?php } ?> >500</option>
                        </select>
						</li>	
						
					  
					  <li>
					  <?php
						$selectedStatus = $allusers->status;
						if(isset($postData['status'])) {
							$selectedStatus = $postData['status'];
						}
						?>
                        <label><em>*</em> Status:</label>
                        <select class="required add-form-input" name="status" id="status">
                          <option value="1" <?php if($selectedStatus == '1') { ?> selected="selected" <?php } ?>>Active</option>
                          <option value="0" <?php if($selectedStatus == '0') { ?> selected="selected" <?php } ?>>Inactive</option>
                        </select>
                        <span class="field_error"> </span> </li>
                    </ul>	
				<div class="submit-btn noMargin">
                
				<button type="submit" name="submit" id="mc-embedded-subscribe1" class="submit-button-dark"><span class="sprite"><em class="sprite">Update</em></span></button>
				
				<!--<input type="submit" name="submit" id="mc-embedded-subscribe1" value="Update" class="submit-button-dark" />-->
				
				<!--<div style="float:right;"><a href="<?php echo site_url(array('admin','price_setting')); ?>" class="submit-button-dark" id="mc-embedded-subscribe"><span  class="sprite"><em style="display:block" class="sprite">Cancel</em></span></a></div>-->
				
				
				<a href="<?php echo site_url(array('admin','price_setting')); ?>" class="submit-button-dark" id="mc-embedded-subscribe"><span class="sprite" ><em style="display:block" class="sprite">Cancel</em></span></a>
				
                </div>
				
				</div>
				</form>
				  
               
              </div>
            </div>
          </div>
        </div>
      </div>
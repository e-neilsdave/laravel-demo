
      <h1 class="page-title">Dashboard</h1>
      <div class="col-s-content-project">
        <div class="left-part-project">
          <div class="shadowed DashboardArea" id="items">
            <div class="inner-boundaries gp1">
              <div class="gried-view">
                <div class="project-box">
                  <div class="gray-box-bg">
                    <ul class="dashboardUL">
                      <li class="icon1"><a href="<?php echo site_url(array('admin','userlist')); ?>" title="Customers">Customers</a></li>
                      <li class="icon2"><a href="#" title="Web Sites">Web Sites</a></li>
                      <li class="icon3"><a href="#" title="Packages">Packages</a></li>
                      <li class="icon4"><a href="#" title="Email Templates">Email Templates</a></li>
                      <li class="icon5"><a href="#" title="CMS">CMS</a></li>
                      <li class="icon6"><a href="#" title="Settings">Settings</a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div class="inner-boundaries gp2">
              <div class="gried-view">
                <div class="project-box">
                  <div class="gray-box-bg">
                    <ul class="dashboardUL">
                      <li class="icon7"><a href="#" title="Roles">Roles</a></li>
                      <li class="icon8"><a href="#" title="Permissions">Permissions</a></li>
                      <li class="icon9"><a href="#" title="Backups">Backups</a></li>
                      <li class="icon10"><a href="#" title="Subscriptions">Subscriptions</a></li>
                      <li class="icon11"><a href="#" title="Transactions">Transactions</a></li>
                      <li class="icon12"><a href="#" title="Logs">Logs</a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div class="inner-boundaries gp3">
              <div class="gried-view">
                <div class="project-box">
                  <div class="gray-box-bg">
                    <ul class="dashboardUL">
                      <li class="icon13"><a href="#" title="Menu Type">Menu Type</a></li>
                      <li class="icon14"><a href="#" title="Menu">Menu</a></li>
                      <li class="icon15"><a href="#" title="Storage Space">Storage Space</a></li>
                      <li class="icon16"><a href="#" title="Schedule">Schedule</a></li>
                      <li class="icon17"><a href="#" title="Newsletter">Newsletter</a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    

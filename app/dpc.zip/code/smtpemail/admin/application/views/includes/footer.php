<div id="footer-box">
  <div id="footer" class="large">
    <div class="container">
      <div class="left">

      </div>
      <div class="middle vert_sprite">
        <div>
          <div class="content-left">
            <div style="width:450px" class="newsletter">
              <h3>What is EmailValidated?</h3>
              <p>EmailValidated is a email validator service developed and powered by SilverTouch Technologies Ltd. With EmailValidated, you can validate as many number of emails you wish to. Emails can be validated not only as per the typography of email addresses but are validated such that whether they actually exist or not and there is someone who is actually receiving it.</p>
			  <p>Reading in between the lines, we call it as - Emails(Authenticity)Validated.</p>
            </div>
          </div>

        </div>
      </div>
      <div class="right vert_sprite">

      </div>
    </div>
    <div class="clear"></div>
  </div>
  
  <div id="copyright">
    <div class="container">
      <div class="powered-by-envato"> <a href="http://www.silvertouch.com/" title="POWERED BY SILVER TOUCH">Product By SilverTouch</a> </div>
      <div class="copyright">
<!--       <p> <span>Copyright &copy <?php //echo date("Y");?> SilverTouch Technologies Ltd. | | Privacy Policy | Disclaimer | Terms of Use</span></p> -->
      </div>
    </div>
  </div>
  
</div>
<?php
$enabledbreadPanel = array();
if(isset($enabledbreadPanels)) {
	$enabledbreadPanel = $enabledbreadPanels;
} 
?>

<div class="page-info">    
		<?php if(in_array('bredcrum_home', $enabledbreadPanel)) { ?>
	<div class="container">

	<div class="add-btn"> <a href="<?php echo site_url(array('emails','import')); ?>" title=""> <img width="14" height="14" alt="" src="<?php echo $this->config->item('base_url'); ?>/images/add-icon.png"> <span>Import Emails (CSV) </span> </a> </div>

    <div id="breadcrumbs"> <a class="first" href="<?php echo site_url(array('emails','index')); ?>">Home</a> \ All Emails </div>
	</div>
    <div id="tab-width">
      <div id="tab-box" >
        <div id="page-tabs">		
          <ul>
            <li class="selected">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('emails','index')); ?>">All Emails</a> </li>
            <li class="last">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('emails','import')); ?>">Import Emails</a>
              <div class="last"></div>
            </li>
          </ul>
		</div>
      </div>
    </div>  
		<?php } ?>
		
		<?php if(in_array('bredcrum_import', $enabledbreadPanel)) { ?>
		<div class="container">
      <div id="breadcrumbs"> <a class="first" href="<?php echo site_url(array('emails','index')); ?>">Home</a> \ Import Emails </div>
	</div>
    <div id="tab-width">
      <div id="tab-box" >
        <div id="page-tabs">
		<ul>
            <li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('emails','index')); ?>">All Emails</a></li>
            <li class="selected last">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('emails','import')); ?>">Import Emails</a>
              <div class="last"></div>
            </li>
        </ul>
		</div>
      </div>
    </div>		
		<?php } ?> 

		<?php if(in_array('bredcrum_login', $enabledbreadPanel)) { ?>
		<div class="container">
      <div id="breadcrumbs"> <a class="first" href="<?php echo site_url(array('emails','index')); ?>">Home</a> \ Login </div>
	</div>
    <div id="tab-width">
      <div id="tab-box" >
        <div id="page-tabs">
		<ul>
            <li class="selected">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('home','login')); ?>">Login</a></li>
            <li class="last">
              <div>&nbsp;</div>
              <a href="#">Forgot Password?</a>
              <div class="last"></div>
            </li>
        </ul>
		</div>
      </div>
    </div>	
		<?php } ?> 
    <div class="clear"></div>
  </div>

<?php
// for home page
$currentController = $this->router->class;
$currentMethod = $this->router->method;

// for guest user no added bredcrum

//echo $currentController. " and " .$currentMethod;
$enabledbreadPanel = array();
if(isset($enabledbreadPanels)) {
	$enabledbreadPanel = $enabledbreadPanels;
} 

//echo "<pre>";print_R($enabledbreadPanel);
//$noBreadcrum = array('guest_user');
//if(in_array($currentController , $noBreadcrum)) { ?>
<?php //} else{ ?>
<?php if($currentMethod != 'thankyou'){ ?>
<div class="page-info">    
	<?php if(in_array('bredcrum_home', $enabledbreadPanel)) { ?>
	<div class="container">

	<div class="add-btn emailscsv"> <a href="<?php echo site_url(array('emails','import')); ?>" title=""> <img width="14" height="14" alt="" src="<?php echo $this->config->item('base_url'); ?>/images/add-icon.png"> <span>Validate Emails (CSV) </span> </a> </div>

    <div id="breadcrumbs"> <a class="first" href="<?php echo site_url(array('emails','dashbord')); ?>">Dashbord</a>\<a class="first" href="<?php echo site_url(array('emails','index')); ?>"><span class="breadcrumMenu">My Account</span></a>\<span class="breadcrumMenu">All Emails</span></div>
	</div>
    <div id="tab-width">
      <div id="tab-box" >
        <div id="page-tabs">		
          <ul>
            <li class="selected">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('emails','index')); ?>">All Emails</a> </li>

			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('emails','userLog')); ?>">User Log</a> </li>
			  
            <li class="last">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('emails','import')); ?>">Validate Emails</a>
              <div class="last"></div>
            </li>
          </ul>
		</div>
      </div>
    </div>  
	<?php } ?>
		
	<?php if(in_array('bredcrum_import', $enabledbreadPanel)) { ?>
	<div class="container">
    <div id="breadcrumbs"> <a class="first" href="<?php echo site_url(array('emails','dashbord')); ?>">Dashbord</a>\<a class="first" href="<?php echo site_url(array('emails','index')); ?>"><span class="breadcrumMenu">My Account</span></a>\<span class="breadcrumMenu">Validate Emails</span></div>
	</div>
    <div id="tab-width">
      <div id="tab-box" >
        <div id="page-tabs">
		<ul>
            <li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('emails','index')); ?>">All Emails</a></li>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('emails','userLog')); ?>">User Log</a> </li>
			<li class="selected last">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('emails','import')); ?>">Validate Emails</a>
              <div class="last"></div>
            </li>
        </ul>
		</div>
      </div>
    </div>		
	<?php } ?> 
	
	
	<?php if(in_array('bredcrum_userlog', $enabledbreadPanel)) { ?>
	<div class="container">

	<div class="add-btn emailscsv"> <a href="<?php echo site_url(array('emails','import')); ?>" title=""> <img width="14" height="14" alt="" src="<?php echo $this->config->item('base_url'); ?>/images/add-icon.png"> <span>Validate Emails (CSV) </span> </a> </div>

    <div id="breadcrumbs"> <a class="first" href="<?php echo site_url(array('emails','dashbord')); ?>">Dashbord</a>\<a class="first" href="<?php echo site_url(array('emails','index')); ?>"><span class="breadcrumMenu">My Account</span></a>\<span class="breadcrumMenu">All Emails</span></div>
	</div>
    <div id="tab-width">
      <div id="tab-box" >
        <div id="page-tabs">		
          <ul>
            <li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('emails','index')); ?>">All Emails</a> </li>
			<li class="selected">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('emails','userlog')); ?>">User Log</a> </li>		
            <li class="last">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('emails','import')); ?>">Validate Emails</a>
              <div class="last"></div>
            </li>
          </ul>
		</div>
      </div>
    </div>  
	<?php } ?>
	
	
	

	<?php if(in_array('bredcrum_login', $enabledbreadPanel)) { ?>

	<div class="container">
    <div id="breadcrumbs"><span class="breadcrumMenu">Login</span></div>
	</div>
    <div id="tab-width">
      <div id="tab-box" >
        <div id="page-tabs">
		<ul>
            <li class="selected">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('home','login')); ?>">Login</a></li>
			<li class="last">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('home','forgotpassword')); ?>">Forgot Password?</a>
              <div class="last"></div>
            </li>
        </ul>
		</div>
      </div>
    </div>	
	<?php } ?> 
	
	
	<?php if(in_array('bredcrum_forgot', $enabledbreadPanel)) { ?>
	<div class="container">
    <div id="breadcrumbs"><span class="breadcrumMenu">Forgot Password</span></div>
	</div>
    <div id="tab-width">
      <div id="tab-box" >
        <div id="page-tabs">
		<ul>
            <li >
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('home','login')); ?>">Login</a></li>
			<li class="selected last">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('home','forgotpassword')); ?>">Forgot Password?</a>
              <div class="last"></div>
            </li>
        </ul>
		</div>
      </div>
    </div>			
	<?php } ?>
	
	<?php if(in_array('bredcrum_editaccount', $enabledbreadPanel)) { ?>
	<div class="container">
    
	<?php if($this->session->userdata('user_type') == 'admin') { ?>
	<div id="breadcrumbs"> <a class="first" href="<?php echo site_url(array('admin','index')); ?>">Dashbord</a>\ <span class="breadcrumMenu">Edit User Account</span> </div>
	<?php } else { ?>
	<div id="breadcrumbs"> <a class="first" href="<?php echo site_url(array('guest_user','index')); ?>">Home</a>\ <span class="breadcrumMenu">Edit User Account</span></div>
	<?php } ?>
	
	</div>
    <div id="tab-width">
      <div id="tab-box" >
        <div id="page-tabs">
		<ul>
            <?php if($this->session->userdata('login_email')  == 'admin@silvertouch.com' ) { ?>
			<li class="selected last">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('emails','editregisteruser')); ?>">Edit User Account</a>
			  <div class="last"></div>
			</li>
			<?php } else { ?>
			
			<li class="selected">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('emails','editregisteruser')); ?>">Edit User Account</a></li>
			<li class="last">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('emails','myorderdetails')); ?>">My Order Details</a>
              <div class="last"></div>
            </li>
			<?php } ?>
        </ul>
		</div>
      </div>
    </div>			
	<?php } ?>
	
	
	<?php if(in_array('bredcrum_myorderlist', $enabledbreadPanel)) { ?>
	<div class="container">
    
	<?php if($this->session->userdata('login_email') == 'admin@silvertouch.com') { ?>
	<div id="breadcrumbs"> <a class="first" href="<?php echo site_url(array('admin','index')); ?>">Dashbord</a>\ <span class="breadcrumMenu">Edit User Account</span> </div>
	<?php } else { ?>
	<div id="breadcrumbs"> <a class="first" href="<?php echo site_url(array('guest_user','index')); ?>">Home</a>\ <span class="breadcrumMenu">My Order Details</span></div>
	<?php } ?>
	
	</div>
    <div id="tab-width">
      <div id="tab-box" >
        <div id="page-tabs">
		<ul>
            <!--<li class="selected last">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('emails','editregisteruser')); ?>">Edit User Account</a>
			  <div class="last"></div>
			</li>-->
			
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('emails','editregisteruser')); ?>">Edit User Account</a></li>
			<li class="selected last">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('emails','myorderdetails')); ?>">My Order Details</a>
              <div class="last"></div>
            </li>
			
        </ul>
		</div>
      </div>
    </div>			
	<?php } ?>
	
	<?php if(in_array('bredcrum_admin_home', $enabledbreadPanel)) { ?>
	<div class="container">
    <div id="breadcrumbs"> <a class="first" href="<?php echo site_url(array('admin','index')); ?>">Dashbord</a>\<span class="breadcrumMenu">All User List</span></div>
	</div>
    <div id="tab-width">
      <div id="tab-box" >
        <div id="page-tabs">
		
		<ul>
			<li class="selected">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','userlist')); ?>">All User List</a>
			</li>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','emailtemplatelist')); ?>">Email Templates</a>
			</li>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','transectiondetail')); ?>">Transaction Details</a>
			</li>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','adminLog')); ?>">Logs</a>
			</li>
			
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','news_later')); ?>">Newsletter</a>
			</li>
			
            <li class="last">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','price_setting')); ?>">Price Settings</a>
			  <div class="last"></div>
			</li>
			
			
			
        </ul>
		
		</div>
      </div>
    </div>			
	<?php } ?>
	
	
	<?php if(in_array('bredcrum_admin_dashbord', $enabledbreadPanel)) { ?>
	<div class="container">
    <div id="breadcrumbs"> 
	&nbsp
	<!--<a class="first" href="<?php echo site_url(array('admin','index')); ?>">Home</a> \ Dashbord -->
	</div>
	</div>
    <div id="tab-width">
      <div id="tab-box" >
        <div id="page-tabs">
		<ul>
            <li class="selected last">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','index')); ?>">Dashbord</a>
			  <div class="last"></div>
			</li>
        </ul>
		</div>
      </div>
    </div>			
	<?php } ?>
	
	
	<?php if(in_array('bredcrum_admin_price', $enabledbreadPanel)) { ?>
	<div class="container">
    
	<?php if($this->input->get('Itemid') != '' ) { ?>
	<div id="breadcrumbs"> <a class="first" href="<?php echo site_url(array('admin','index')); ?>">Dashbord</a>\<a href="<?php echo site_url(array('admin','price_setting')); ?>"><span class="breadcrumMenu">Price Settings</span></a>\<span class="breadcrumMenu">Edit Price Settings</span></div>
	<?php } else { ?>
	<div id="breadcrumbs"> <a class="first" href="<?php echo site_url(array('admin','index')); ?>">Dashbord</a>\<span class="breadcrumMenu">Price Settings</span></div>
	<?php } ?>
	</div>
    <div id="tab-width">
      <div id="tab-box" >
        <div id="page-tabs">
		
		<ul>
			<li>
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','userlist')); ?>">All User List</a>
			</li>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','emailtemplatelist')); ?>">Email Templates</a>
			</li>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','transectiondetail')); ?>">Transaction Details</a>
			</li>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','adminLog')); ?>">Logs</a>
			</li>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','news_later')); ?>">Newsletter</a>
			</li>
            <li class="last selected">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','price_setting')); ?>">Price Settings</a>
			  <div class="last"></div>
			</li>
        </ul>
		
		</div>
      </div>
    </div>			
	<?php } ?>
	
	
	<?php if(in_array('bredcrum_admin_mail', $enabledbreadPanel)) { ?>
	<div class="container">
	
	<div class="add-btn"> <a href="<?php echo site_url(array('admin','emailTemplate')); ?>" title=""> <img width="14" height="14" alt="" src="<?php echo $this->config->item('base_url'); ?>/images/add-icon.png"> <span>ADD NEW </span> </a> </div>
	
    <div id="breadcrumbs"> <a class="first" href="<?php echo site_url(array('admin','index')); ?>">Dashbord</a>\<span class="breadcrumMenu">Email Templates</span></div>
	</div>
    <div id="tab-width">
      <div id="tab-box" >
        <div id="page-tabs">
		
		<ul>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','userlist')); ?>">All User List</a>
			</li>
			<li class="selected">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','emailtemplatelist')); ?>">Email Templates</a>
			</li>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','transectiondetail')); ?>">Transaction Details</a>
			</li>
			
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','adminLog')); ?>">Logs</a>
			</li>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','news_later')); ?>">Newsletter</a>
			</li>
            <li class="last">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','price_setting')); ?>">Price Settings</a>
			  <div class="last"></div>
			</li>
        </ul>
		
		</div>
      </div>
    </div>			
	<?php } ?>
	
	
	<?php if(in_array('bredcrum_admin_mail_new', $enabledbreadPanel)) { ?>
	
	<div class="container">
	
	<div id="breadcrumbs"> <a class="first" href="<?php echo site_url(array('admin','index')); ?>">Dashbord</a>\<a class="first" href="<?php echo site_url(array('admin','emailtemplatelist')); ?>"><span class="breadcrumMenu">Email Templates</span></a>\<span class="breadcrumMenu">Add New Email Template</span></div>
	
	</div>
    <div id="tab-width">
      <div id="tab-box" >
        <div id="page-tabs">
		
		<ul>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','userlist')); ?>">All User List</a>
			</li>
			<li class="selected">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','emailtemplatelist')); ?>">Email Templates</a>
			</li>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','transectiondetail')); ?>">Transaction Details</a>
			</li>
			
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','adminLog')); ?>">Logs</a>
			</li>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','news_later')); ?>">Newsletter</a>
			</li>
            <li class="last">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','price_setting')); ?>">Price Settings</a>
			  <div class="last"></div>
			</li>
        </ul>
		
		</div>
      </div>
    </div>			
	<?php } ?>
	
	<?php if(in_array('bredcrum_admin_mail_edit', $enabledbreadPanel)) { ?>
	<div class="container">
	
	<div id="breadcrumbs"> <a class="first" href="<?php echo site_url(array('admin','index')); ?>">Dashbord</a>\<a class="first" href="<?php echo site_url(array('admin','emailtemplatelist')); ?>"><span class="breadcrumMenu">Email Templates</span></a>\<span class="breadcrumMenu">Edit Email Templates</span></div>
	
	</div>
    <div id="tab-width">
      <div id="tab-box" >
        <div id="page-tabs">
		
		<ul>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','userlist')); ?>">All User List</a>
			</li>
			<li class="selected">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','emailtemplatelist')); ?>">Email Templates</a>
			</li>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','transectiondetail')); ?>">Transaction Details</a>
			</li>
			
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','adminLog')); ?>">Logs</a>
			</li>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','news_later')); ?>">Newsletter</a>
			</li>
            <li class="last">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','price_setting')); ?>">Price Settings</a>
			  <div class="last"></div>
			</li>
        </ul>
		
		</div>
      </div>
    </div>			
	<?php } ?>
	
	
	<?php if(in_array('bredcrum_admin_transectiondetails', $enabledbreadPanel)) { ?>
	<div class="container">
	
	<div id="breadcrumbs"> <a class="first" href="<?php echo site_url(array('admin','index')); ?>">Dashbord</a>\<span class="breadcrumMenu">Transaction Details</span></div>
	
	</div>
    <div id="tab-width">
      <div id="tab-box" >
        <div id="page-tabs">
		
		<ul>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','userlist')); ?>">All User List</a>
			</li>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','emailtemplatelist')); ?>">Email Templates</a>
			</li>
			<li class="selected">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','transectiondetail')); ?>">Transaction Details</a>
			</li>
			
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','adminLog')); ?>">Logs</a>
			</li>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','news_later')); ?>">Newsletter</a>
			</li>
            <li class="last">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','price_setting')); ?>">Price Settings</a>
			  <div class="last"></div>
			</li>
        </ul>
		
		</div>
      </div>
    </div>			
	<?php } ?>
	
	
	<?php if(in_array('bredcrum_admin_generatelog', $enabledbreadPanel)) { ?>
	<div class="container">
	
	<div id="breadcrumbs"> <a class="first" href="<?php echo site_url(array('admin','index')); ?>">Dashbord</a>\<span class="breadcrumMenu">Logs</span></div>
	
	</div>
    <div id="tab-width">
      <div id="tab-box" >
        <div id="page-tabs">
		
		<ul>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','userlist')); ?>">All User List</a>
			</li>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','emailtemplatelist')); ?>">Email Templates</a>
			</li>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','transectiondetail')); ?>">Transaction Details</a>
			</li>
			
			<li class="selected">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','adminLog')); ?>">Logs</a>
			</li>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','news_later')); ?>">Newsletter</a>
			</li>
            <li class="last">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','price_setting')); ?>">Price Settings</a>
			  <div class="last"></div>
			</li>
			
        </ul>
		
		</div>
      </div>
    </div>			
	<?php } ?>
	
	
	<?php if(in_array('bredcrum_admin_news', $enabledbreadPanel)) { ?>
	<div class="container">
	
	<div id="breadcrumbs"> <a class="first" href="<?php echo site_url(array('admin','index')); ?>">Dashbord</a>\<span class="breadcrumMenu">Newsletter</span></div>
	
	</div>
    <div id="tab-width">
      <div id="tab-box" >
        <div id="page-tabs">
		
		<ul>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','userlist')); ?>">All User List</a>
			</li>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','emailtemplatelist')); ?>">Email Templates</a>
			</li>
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','transectiondetail')); ?>">Transaction Details</a>
			</li>
			
			<li class="">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','adminLog')); ?>">Logs</a>
			</li>
			<li class="selected">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','news_later')); ?>">Newsletter</a>
			</li>
            <li class="last">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('admin','price_setting')); ?>">Price Settings</a>
			  <div class="last"></div>
			</li>
			
        </ul>
		
		</div>
      </div>
    </div>			
	<?php } ?>
	
	
	<?php if(in_array('bredcrum_help', $enabledbreadPanel)) { ?>
	<div class="container">
    <div id="breadcrumbs"> <a class="first" href="<?php echo site_url(array('guest_user','index')); ?>">Home</a>\<span class="breadcrumMenu">FAQ</span></div>
	</div>
    <div id="tab-width">
      <div id="tab-box" >
        <div id="page-tabs">
		<ul>
            <li class="selected last">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('guest_user','help')); ?>">FAQ</a>
			  <div class="last"></div>
			</li>
        </ul>
		</div>
      </div>
    </div>			
	<?php } ?>
	
	<?php if(in_array('bredcrum_guest_home', $enabledbreadPanel)) { ?>
	<div class="container">
    <div id="breadcrumbs">&nbsp </div>
	</div>
    <div id="tab-width">
      <div id="tab-box" >
        <div id="page-tabs">
		<ul>
            <li class="selected last">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('guest_user','index')); ?>">Home</a>
			  <div class="last"></div>
			</li>
        </ul>
		</div>
      </div>
    </div>		
	<?php } ?>
	
	<?php if(in_array('bredcrum_guest_feature', $enabledbreadPanel)) { ?>
	<div class="container">
    <div id="breadcrumbs"> <a class="first" href="<?php echo site_url(array('guest_user','index')); ?>">Home</a>\<span class="breadcrumMenu">Feature</span></div>
	</div>
    <div id="tab-width">
      <div id="tab-box" >
        <div id="page-tabs">
		<ul>
            <li class="selected last">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('guest_user','feature')); ?>">Feature</a>
			  <div class="last"></div>
			</li>
        </ul>
		</div>
      </div>
    </div>			
	<?php } ?>
	
	<?php if(in_array('bredcrum_guest_pricing', $enabledbreadPanel)) { ?>
	<div class="container">
    <div id="breadcrumbs"> <a class="first" href="<?php echo site_url(array('guest_user','index')); ?>">Home</a>\<span class="breadcrumMenu">Pricing</span></div>
	</div>
    <div id="tab-width">
      <div id="tab-box" >
        <div id="page-tabs">
		<ul>
            <li class="selected last">
              <div>&nbsp;</div>
              <a href="<?php echo site_url(array('guest_user','pricing')); ?>">Pricing</a>
			  <div class="last"></div>
			</li>
        </ul>
		</div>
      </div>
    </div>			
	<?php } ?>
	
	<div class="clear"></div>
</div>
<?php }	?>
<?php // } ?>
    
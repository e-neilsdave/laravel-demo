<?php
$enabledPanels = array();
if(isset($enabledSidePanels)) {
	$enabledPanels = $enabledSidePanels;
} 

//echo "<pre> keys = ";print_r($privateKeys);
?>
<script type="text/javascript" src="<?php echo $this->config->item('base_url');?>js/css3-mediaqueries.js"></script>
<script type="text/javascript" src="<?php echo $this->config->item('base_url');?>js/jquery.fancybox-1.3.4.pack.js"></script>
<script type="text/javascript">
		$(document).ready(function() {
			$("#various1").fancybox({
				'titlePosition'		: 'inside',
				'transitionIn'		: 'none',
				'transitionOut'		: 'none'
			});
					
		});
</script>

<style>
.editbox
{
font-size:14px;
border:solid 1px #000;
padding:4px;
}
.edit_td_auth:hover
{
<!--background:url(edit.png) right no-repeat #80C8E5;
cursor:pointer;-->
}
</style>

<script type="text/javascript">
$(document).ready(function()
{
	$(".editAjax").click(function()
	{
		var ID=$(this).attr('id');
		$("#auth_Token").hide();
		$("#auth_input_Token").show();
		$(".saveAjax").show();
		$(".editAjax").hide();
		
	});
	
	$(".saveAjax").click(function()
	{
		var ID='<?php echo $privateKeys->id;?>';
		var auth=$("#auth_input_Token").val();
		var dataString = 'id='+ ID +'&auth='+auth;
		
		var pattn = /^[a-zA-Z0-9]+$/;
		
		if(!auth || auth.length==0){
			$('#token_error').html('Please Enter Auth Token').show();
		}
		else if(!pattn.test(auth)){
			$('#token_error').html('Please Enter Valid Auth Token').show();
		}else if(auth.length<10 || auth.length>15){
			$('#token_error').html('Please Enter min 10 and max 15 charecter').show();
		} else {
			$('#token_error').html('').hide();
			$.ajax({
			type: "POST",
			url: "<?php echo GLOBAL_PATH . 'emails/editAuthKey/'; ?>",
			data: dataString,
			cache: false,
			success: function(html)
			{
				if(html==1){
					$("#auth_Token").html(auth);
					$(".saveAjax").hide();
					$(".editAjax").show();
					$(".editbox").hide();
					$(".textAuth").show();
				}
			}
			});
		}
		
	});
	
});
</script>

<?php 

if(in_array('sidebar_points', $enabledPanels)) { ?>	
	
	<!-- start code auth detail -->
	
	
	<?php if($points->membership_type == 3 || $points->membership_type == 4 ) { ?>
	<div style="display:none;">
		<div class="popupbox search-box" id="inline1">
			<h3> Authentication Details </h3>
			<?php
			$id=$privateKeys->id;
			$auth=$privateKeys->auth_token;
			?>
			<div style="float:left;width:100%">
			<span style="color:#31AAE3;font-weight:bold;width:30%;float:left;padding-bottom:10px">My API Key :</span>
			<span id="apiKey" class="textAPI"><?php echo $privateKeys->apicode;?></span>
			</div>
			<div style="float:left;width:100%">
			<span style="color:#31AAE3;font-weight:bold;width:30%;float:left;padding-bottom:10px">My Auth Token :</span>
			<span id="auth_Token" class="textAuth"><?php echo $auth; ?></span>
			
			<input style="display:none;" type="text" value="<?php echo $auth; ?>" class="editbox" id="auth_input_Token" >
			
			<a href="#" style="display:none;padding-left:15px" class="saveAjax">Save</a> 
			<a href="#" style="padding-left:15px" class="editAjax">Edit</a>
			
			<span style="color: #FF0000;margin-left: 10px;" id="token_error" class="ur_error errorReq"></span>
			</div>

		</div>        
	</div>

	<div class="large-sidebar" style="margin-bottom:10px">
		<div class="inner-boundary first-item last-item">
			<div class="inner-border_point">
			<p style="color:#31AAE3;font-weight:bold;";>
			<!-- <a href="<?php echo site_url(array('emails','myorderdetails')); ?>"> -->
			<a id="various1" href="#inline1">My API Detail</a>
			<!--</a>-->
			</p>
			</div>
		</div>
	</div>
	<?php } ?>

	<!-- end code auth detail -->


	<div class="large-sidebar" style="margin-bottom:10px">
		<div class="inner-boundary first-item last-item">
            <div class="inner-border_point">
              <p style="color:#31AAE3;font-weight:bold;";>My CREDIT POINTS - <a href="<?php echo site_url(array('emails','myorderdetails')); ?>"><span style="color:#000"><?php echo $points->point;?><span></a></p>
            </div>
        </div>
	</div>
	
	<div class="large-sidebar">
        <div class="section">
          <h4 class="decorator title sprite">BUY CREDIT POINTS:</h4>
          <div class="inner-boundary first-item last-item">
            <div class="inner-border">
              <p>Everything you want and need to validate emails. Buy credit pointdand increase your email validation limit. checkout various plans:</p>
              <!--<a href="#">
              <button class="submit-button-dark" id="mc-embedded-subscribe1" name="subscribe"><span class="sprite"><em class="sprite">View Plans</em></span></button>
              </a>-->
			  
			  <a href="<?php echo site_url(array('guest_user','pricing')); ?>" class="submit-button-dark" id="mc-embedded-subscribe"><span class="sprite"><em class="sprite">View Plans</em></span></a>
			  
			  
	<!--		<p>
			Additional validations are billed at $0.01 per email.
			</p>-->
			</div>
          </div>
        </div>
    </div>
<?php } ?>

<?php if(in_array('sidebar_signup', $enabledPanels)) { ?>
	<div class="large-sidebar">
        <div class="section">
          <h4 class="decorator title sprite">Free Trial!</h4>
          <div class="inner-boundary first-item last-item">
            <div class="inner-border">
				<p>It takes couple of minutes to create a free trial account. 
					Create a free trail account now and validate 10 emails for FREE and upgrade anytime then after.
				</p>
				<?php $mainSite = $this->config->item("base_url_mainsite");?>
				<a href="<?php echo $mainSite.'index.php/home/register'; ?>" class="submit-button-dark" id="mc-embedded-subscribe">
				<!--<a href="#" class="submit-button-dark" id="mc-embedded-subscribe">-->
					<span class="sprite"><em class="sprite">Sign Up Now</em></span>
				</a>
			</div>
          </div>
        </div>
      </div>
<?php } ?>


<?php
$activeMenu = $this->commonfunctions->activeClass();
?>

<div class="navigation-box"><div class="container"><div class="navigation" id="chromemenu1">
    <ul>

		<!-- Admin Part-->
		<?php if($this->session->userdata('user_type') == 'admin') { ?>
		<li>
			<a class = "<?php echo (($activeMenu == 'dashbord') ? 'selected' : ''); ?>"  rel="dropmenu11" href="<?php echo site_url(array('admin','index')); ?>" >Dashbord</a>
		</li>
		<?php } else { ?>
		<!-- All Users Part -->
		
		<?php if ($this->session->userdata('login_id') != '') { ?>
		<li>
			<a class = "<?php echo ($activeMenu == 'dashbord_account' ? 'selected' : ''); ?>" rel="dropmenu11" href="<?php echo site_url(array('emails','dashbord')); ?>" >Dashbord</a>
		</li>
		
		<li>
			<a class = "<?php echo ($activeMenu == 'managa_account' ? 'selected' : ''); ?>" rel="dropmenu11" href="<?php echo site_url(array('emails','index')); ?>" >Email Validator</a>
		</li>
		
		<li>
			<a class = "<?php echo ($activeMenu == 'transection_account' ? 'selected' : ''); ?>" rel="dropmenu11" href="<?php echo site_url(array('emails','myorderdetails')); ?>" >Transactions Detail</a>
		</li>
		
		<li>
			<a class = "<?php echo ($activeMenu == 'pricing' ? 'selected' : ''); ?>" rel="dropmenu11" href="<?php echo site_url(array('guest_user','pricing')); ?>" >Packages</a>
		</li>
		
		<?php } else { ?>
		<li>
			<a class = "<?php echo ($activeMenu == 'login' || 'forgotpassword' ? 'selected' : ''); ?>" rel="dropmenu11" href="<?php echo site_url(array('home','index')); ?>" >Login</a>
		</li>
		<?php } ?>
		
		<?php } ?>
		
	</ul>
</div></div></div>
<div class="header">
    <div class="container">
      <div class="logo"> <a href="<?php echo $this->config->item('base_url_mainsite'); ?>" title="Silver Touch"><img src="<?php echo $this->config->item('base_url'); ?>images/logo-inner.png" alt="Silver Touch" /></a> </div>
	  <?php if ($this->session->userdata('login_id') != '') { ?>
	  <div class="account-wrapper">
        <ul>
          <li  class="create-account"> <a class = "<?php echo (($this->commonfunctions->activeClass() == 'edit_user') ? 'selected' : ''); ?>" href="<?php echo site_url(array('emails','editregisteruser')); ?>"> <?php echo ucwords($this->session->userdata('login_username'));?></a> </li>
          <li class="sign-in"><a href="<?php echo site_url(array('home','logout')); ?>">Logout</a></li>
        </ul>
      </div>
	  <?php } ?>
     <!-- <div class="top-navigation-box">
        <div class="top-navigation" id="chromemenu">
          <ul>
            <li>
			<?php /*if($this->session->userdata('user_type') != 'admin') { ?>
			<a class = "<?php echo (($this->commonfunctions->activeClass() == 'help') ? 'selected' : ''); ?>"  href="<?php echo site_url(array('guest_user','help')); ?>" rel="dropmenu5" title="Help">Help</a>
			<?php } */ ?>
			</li>
          </ul>
        </div>
      </div>-->
    </div>
</div>
  
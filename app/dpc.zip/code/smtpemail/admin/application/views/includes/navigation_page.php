<?php

// for home page
$currentController = $this->router->class;
$currentMethod = $this->router->method;

$loginPage = array('login'=>'Login','forgot_password'=>'Forgot Password?');
$emailsPage = array('index'=>'All Emails','import'=>'Import Emails');


$NavPage = array();
if($currentController == 'emails'){
	$NavPage['nav'] = $emailsPage;
	if($currentMethod == 'index'){
		$selected = 'index';
		$MethodName = "All Emails";
		$controllerName = "Home";
		$cname = 'emails';
	} else if($currentMethod == 'import'){
		$selected = 'import';
		$MethodName = "Import Emails";
		$controllerName = "Home";		
		$cname = 'emails';
	}
}
if($currentController == 'home'){
	$NavPage['nav'] = $loginPage;
	if($currentMethod == 'login'){
		$selected = 'login';
		$MethodName = "Login";
		$controllerName = "Home";
		$cname = 'home';
		
	} else if($currentMethod == 'forgot_password'){
		$selected = 'forgot_password';
		$MethodName = "Forgot Password";
		$controllerName = "Home";
		$cname = 'home';
	}
}
?>
<div class="page-info">

	<div class="container">
		<?php if($currentController = 'emails' && $currentMethod == 'index') { ?>
		<div class="add-btn"> 
			<a href="<?php echo site_url(array('emails','import')); ?>" title=""> 
			<img width="14" height="14" alt="" src="<?php echo $this->config->item('base_url'); ?>/images/add-icon.png"> 
			<span>Import Emails (CSV) </span> 
			</a> 
		</div>
		<?php } ?>

		<div id="breadcrumbs"> 
			<a class="first" href="<?php echo site_url(array('emails','index')); ?>"><?php echo $controllerName;?></a> \ <?php echo $MethodName;?> 
		</div>

	</div>

	<div id="tab-width">
		  <div id="tab-box" >
			<div id="page-tabs">		
			  <ul>
		<?php

		$count = count($NavPage['nav']);
		$i = 1;
		foreach($NavPage['nav'] as $key => $name){ ?>
				<li  <?php if($key == $selected && $i == $count) { ?> class = "selected last" <?php } else { ?> <?php } if($key == $selected) { ?> class= "selected" <?php  } else { ?> class= "last" <?php } ?> >
				  <div>&nbsp;</div>
				  <a href="<?php echo site_url(array($cname,$key)); ?>"><?php echo $name;?></a>
				  <?php if($i == $count) { ?><div class="last"></div><?php } ?>
				</li>
		<?php $i++; } ?>
			</ul>
		</div>
	  </div>
	</div> 
</div>


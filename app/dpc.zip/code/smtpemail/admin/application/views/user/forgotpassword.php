		<script type="text/javascript">
		$(document).ready(function()//When the dom is ready
		{
			$("#email").change(function()
			{ //if theres a change in the username textbox
			var username = $("#email").val();//Get the value in the username textbox
			if(username.length > 3)//if the lenght greater than 3 characters
			{
				$.ajax({  
				//Make the Ajax Request
				type: "POST",
				url: "<?php echo GLOBAL_PATH; ?>home/checkUserName",  //file name
				data: "username="+ username,  //data
				success: function(server_response){
					$("#availability_status").ajaxComplete(function(event, request){
					if(server_response == '0')//if ajax_check_username.php return value "0"
					{
					$("#availability_status").html('<font color="red">Username not Avalable</font>');
					//add this image to the span with id "availability_status"
					}
					});
				}
				});
			}
			else
			{
				$("#availability_status").html('<font color="#cc0000">Username not Valid</font>');
			}
			return false;
			});
		});
		</script>


	<h1 class="page-title">Forgot Password</h1>
		
		<?php if(isset($errorMsg)) { ?>
			<div class="errorMessageHeader"><span><?php echo $errorMsg; ?></span></div>
		<?php } ?>
		
		<div class="errorMessageHeader"><span>
		<?php if ($this->session->flashdata('error') !== FALSE) 
		{ echo $this->session->flashdata('error'); } ?>
		</span></div>
		
      <div class="col-s-content">
        <div class="left-part">
          <div class="shadowed" id="items">
            <div class="inner-boundary">
			<form action="<?php echo GLOBAL_PATH; ?>home/forgotpassword" method="post" class="queryForm" id="formForgot" style="float: none;">
				<div class="add-form-box">
				
                  <ul>
                    <li>
                      <label>Username</label>
                      <input type="text" name="email" id="email" class="add-form-input" />
					  <span id="availability_status" class="error"></span>
                    </li>
					
					
					<li>
					<div class="capcha-box">
					<?php echo $recaptcha_html; ?>
					</div>
					</li>
					
					
                    <li>
                      <label>&nbsp;</label>
                      <div class="button-padd-top">
                        <div style="float:left; width:100px">
						<button class="submit-button-dark" id="mc-embedded-subscribe" name="reset" type="submit"><span class="sprite"><em class="sprite">Reset</em></span></button>
						</div>
						<div style="float:left; width:100px">
						<a href="<?php echo site_url(array('home','login')); ?>" class="submit-button-dark" id="mc-embedded-subscribe"><span class="sprite"><em style="padding-left: 14px;" class="sprite">Back to login</em></span></a>
						</div>
						
                      </div>
					  
                    </li>
					
					
                  </ul>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
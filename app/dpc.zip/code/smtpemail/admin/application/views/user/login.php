
      <h1 class="page-title">Login</h1>
		
		<?php if(isset($errorMsg)) { ?>
			<div class="errorMessageHeader"><span><?php echo $errorMsg; ?></span></div>
		<?php } ?>
		
      <div class="col-s-content">
        <div class="left-part">
          <div class="shadowed" id="items">
            <div class="inner-boundary">
			<form action="<?php echo GLOBAL_PATH; ?>home/login" method="post" class="queryForm" id="formLogin" style="float: none;">
              <!--<form method="post" action="dashboard.html" class="selection fancy-form">-->
                <div class="add-form-box">
				
                  <ul>
                    <li>
                      <label>Username</label>
                      <input type="text" name="username" id="username" class="add-form-input" />
					  
                    </li>
                    <li>
                      <label>Password</label>
                      <input type="password" value="" name="password" id="password" class="add-form-input" />
                    </li>
                    <li class="noPadding">
                      <div class="remeber-box">
                        <input name="" type="checkbox" value="" />
                        Remember Me</div>
                    </li>
                    <li>
                      <label>&nbsp;</label>
                      <div class="button-padd-top">
                        <button class="submit-button-dark" id="mc-embedded-subscribe" name="login" type="submit"><span class="sprite"><em class="sprite">Login</em></span></button>
						<!--<div style="text-align: right; display: inline;">
							<input type="submit" name="login" value="<?php echo $this->lang->line('general_label_login'); ?> &#187;" tabindex="3" class="deleteButton"/>
						</div>-->
                      </div>
                    </li>
                  </ul>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      
    
<div id="login-form">	
    <form action="<?php echo GLOBAL_PATH; ?>home/changepassword" method="post">
        <table>
            <?php if(isset($errorMsg)) { ?>
                <tr>
                    <td colspan="2">
                        <span class="errorMessage"><?php echo $errorMsg; ?></span>
                </td>
                </tr>
            <?php } ?>
            <tr>
                <td align="right"><label for="username"><?php echo $this->lang->line('general_label_password'); ?>:</label></td>
                <td align="left"><input id="password1" name="password1" tabindex="1" type="password" value="" /></td>
            </tr>
            <tr>
                <td align="right"><label for="username"><?php echo $this->lang->line('general_label_confirm_password'); ?>:</label></td>
                <td align="left"><input id="password2" name="password2" tabindex="1" type="password" value="" /></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td>
                    
                </td>
                <td>
                    <input type="submit" name="change" value="<?php echo $this->lang->line('general_label_change_password'); ?> &#187;" tabindex="3" class="deleteButton"/>
                </td>
            </tr>
        </table>
    </form>
</div>
<h1 class="page-title">Sign Up</h1>
<SCRIPT language="javascript">
$(document).ready(function() {
	$('#messageStatus').fadeOut(5000);
});
</SCRIPT>

<script type="text/javascript">
		$(document).ready(function()//When the dom is ready
		{
			
			$("#email").blur(function()
			{ 
				$("#hideSpan").hide();
			});	
			
			if($('#email').val() != ''){
				checkEmail($('#email').val());
			}
			$("#email").change(function()
			{ 
				checkEmail($(this).val());
			});			
		});
		
		function checkEmail(username)
		{
				$("#availability_status").html('');
				var hasError = false;
				var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
			//	var username = $("#email").val();//Get the value in the username textbox
							
				if(username == ''){
					//$("#availability_status").html('<font color="#FF0000">Please enter your email address</font>');
					hasError = true;
				}
				 else if(!emailReg.test(username)) {
					//$("#availability_status").html('<font color="#FF0000">Enter a valid email address.</font>');
					hasError = true;
				} else {
					//$("#availability_status").html('<img src="<?php echo $this->config->item('base_url'); ?>images/loading.gif" align="absmiddle">&nbsp;Checking availability...');
					//Add a loading image in the span id="availability_status"

					$.ajax({  //Make the Ajax Request
					type: "POST",
					url: "<?php echo GLOBAL_PATH; ?>home/checkUserName",  //file name
					data: "username="+ username,  //data
					success: function(server_response){
						//alert(server_response);
						$("#availability_status").ajaxComplete(function(event, request){
							if(server_response == '0')//if ajax_check_username.php return value "0"
							{
								$("#setvar").val('1');
								$('#availability_status').hide();
								//$("#availability_status").html('<font color="Green"> Available </font>  ');
								//add this image to the span with id "availability_status"
							}
							else  if(server_response == '1')//if it returns "1"
							{
								$("#setvar").val('0');
								$('#availability_status').show();
								$("#availability_status").html('<font color="red">All ready exist.</font>');
								hasError = true;
							}
						});
					}

					});
				
				}
				if(hasError == true) { 
					return false;
				}
		}
		
		function check(){
			if($("#setvar").val() == '0'){
			 return false;
			}else{
				return true;
			}
		}
		</script>

<?php 
$errorMessage = $this->session->userdata('errorMessage');
if(trim($errorMessage) != '') { 
	echo '<div id="messageStatus"  class="errorMessageHeader"><span>'.trim($errorMessage).'</span></div>'; 
	$this->session->set_userdata(array('errorMessage' => ''));
}
?>
<div class="col-s-content">
	<div class="left-part">
		<div class="shadowed" id="items">
			<div class="inner-boundary">
				<form id="formSignup" name="formSignup" action="" method="post" class="queryForm" style="float: none;" onsubmit="return check();">
					<input type="hidden" id="setvar" name="setvar" value="0" />
					<div class="add-form-box">
						<ul>
							<li>
								<label>Full Name</label>
								<input type="text" name="username" id="username" value="<?php echo (isset($postData['username'])) ? $postData['username'] : '';?>" class="add-form-input" />
								<div><?php echo form_error('username'); ?></div>
							</li>

							<li>
								<label>Email Address</label>
								<input type="text" name="email" id="email" value="<?php echo (isset($postData['email'])) ? $postData['email'] : '';?>" class="add-form-input" />
								<div><?php echo form_error('email'); ?></div>
								<span id="availability_status" class="checkAval"></span>
							</li>

							<input type="hidden" name="id" id="id" value="<?php echo (isset($postData['id'])) ? $postData['id'] : '';?>" class="add-form-input" />

							<li>
								<label>Password</label>
								<input type="password" value="" name="password" id="password" class="add-form-input" />
								<div><?php echo form_error('password'); ?></div>
							</li>
							<li>
								<label>Confirm Password</label>
								<input type="password" value="" name="confirm_password" id="confirm_password" class="add-form-input" />
								<div><?php echo form_error('confirm_password'); ?></div>
							</li>
							<li>
							<div class="capcha-box">
							<?php echo $recaptcha_html; ?>
							</div>
							</li>
						</ul>
					</div>
					<div class="submit-btn noMargin">
						<button class="submit-button-dark" id="mc-embedded-subscribe2" name="subscribe" type="submit"><span class="sprite"><em class="sprite">Create Your Account</em></span></button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

    
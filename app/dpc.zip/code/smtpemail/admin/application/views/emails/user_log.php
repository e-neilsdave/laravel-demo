<!--<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>-->
 
<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">

<script src="http://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>

 <script>
$(function() {
$( "#from" ).datepicker({
defaultDate: "+1w",
changeMonth: true,
numberOfMonths: 1,
onClose: function( selectedDate ) {
$( "#to" ).datepicker( "option", "minDate", selectedDate );
}
});
$( "#to" ).datepicker({
defaultDate: "+1w",
changeMonth: true,
numberOfMonths: 1,
onClose: function( selectedDate ) {
$( "#from" ).datepicker( "option", "maxDate", selectedDate );
}
});
});
</script>

	<?php //echo "<pre>";print_R($alllogs);exit;?>
	<h1 class="page-title">All Logs</h1>
	
    <div class="col-s-content-project">
        <div class="col-s-content-project">
		<form action="" class="selection fancy-form order" method="get" id="frmEmails">
        <div class="gried-view">
            <div class="project-list-box-test" style="float:left">
              <div class="sorter date-sorter">
				<?php 
				if(!isset($_GET['sort_by'])) {
					$_GET['sort_by'] = 25;
				}
				?>
	            <label class="font-9" for="sort_by">Show </label>
                <select style="width:30px;" class="sort_order" id="sort_by" name="sort_by" onchange="$('.checkbox').attr('checked', false); this.form.submit()" >
					<option value="5" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '5') { ?> selected = "selected" <?php } ?>>5</option>
					<option value="10" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '10') { ?> selected = "selected" <?php } ?>>10</option>
					<option value="15" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '15') { ?> selected = "selected" <?php } ?>>15</option>
					<option value="25" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '25') { ?> selected = "selected" <?php } ?>>25</option>
					<option value="50" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '50') { ?> selected = "selected" <?php } ?>>50</option>
					<option value="100" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '100') { ?> selected = "selected" <?php } ?>>100</option>
					<option value="-1" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '-1') { ?> selected = "selected" <?php } ?>>All</option>
                </select>
                  <label>&nbsp;&nbsp;&nbsp;Records</label>
				   <input type="text" name="search" class="searchbox_class" onclick="this.value = ''" <?php if(isset($_GET['search']) && $_GET['search'] != 'Search Emails...') { ?> value="<?php echo $_GET['search'];?>" <?php } else { ?> value="Search Emails..." <?php } ?> onblur="if(this.value==''){this.value='Search Emails...'};" />
                  <select style="width:60px;" class="sort_order" id="status" name="status" onchange="$('.checkbox').attr('checked', false); this.form.submit()">
                    <option value="">Plateform</option>
                    <option value="manually" <?php if(isset($_GET['status']) && $_GET['status'] == 'manually') { ?> selected = "selected" <?php } ?>>Manually</option>
                    <option value="csv_bulk" <?php if(isset($_GET['status']) && $_GET['status'] == 'csv_bulk') { ?> selected = "selected" <?php } ?>>CSV Bulk</option>
                    <option value="api_magento" <?php if(isset($_GET['status']) && $_GET['status'] == 'api_magento') { ?> selected = "selected" <?php } ?>>Magento</option>
                    <option value="api_joomla" <?php if(isset($_GET['status']) && $_GET['status'] == 'api_joomla') { ?> selected = "selected" <?php } ?>>Joomla</option>
                  </select>
				  
					<label style="padding-left:10px" for="from">From</label>
					<input type="text" <?php if(isset($_GET['from']) && $_GET['from'] != '') { ?> value="<?php echo $_GET['from'];?>" <?php } ?>  id="from" name="from">
					<label style="padding-left:10px" for="to">to</label>
					<input type="text" <?php if(isset($_GET['to']) && $_GET['to'] != '') { ?> value="<?php echo $_GET['to'];?>" <?php } ?> id="to" name="to">
                  
				  <div style="float:left;">
				  <button onclick="$('.checkbox').attr('checked', false);" class="submit-button-dark" id="mc-embedded-subscribe" type="submit" style="margin-left:10px !important;"><span class="sprite"><em class="sprite">GO</em></span></button>
				  </div>
				  
				  <!--<button class="submit-button-dark" id="mc-embedded-subscribe" type="submit" style="margin-left:10px;"><span class="sprite"><em class="sprite">Reset</em></span></button>-->

				  <div style="float:left; margin-top:1px;">
				  <!--<a href="<?php //echo site_url(array('admin','adminLog')); ?>" class="submit-button-dark" id="mc-embedded-subscribe"><span class="sprite"><em class="sprite">Reset</em></span></a>-->
                                  <a href="<?php echo site_url(array('emails','userLog')); ?>" class="submit-button-dark" id="mc-embedded-subscribe"><span class="sprite"><em class="sprite">Reset</em></span></a>
				  </div>

					
              </div>
            </div>
          </div>
		
		<!--<div id="msg" style="display:none;color:red;margin-bottom:10px;"> Please select checkbox for export data</div>-->
		
          <div class="shadowed" id="items">
            <div class="inner-boundaries">
			
              <div class="gried-view">
                <div class="project-box">
                  <div class="gray-box-bg">
					<table cellpadding="0" cellspacing="0" border="0" width="100%" class="gridViewTable" >
                      <tr>
						<!--<th align="left" style="width:30px">
							<input name="selectall" id="selectall" type="checkbox">
						</th>-->
                        <th style="width:30px" align="left">Id</th>
                        <th style="width:30px" align="left">Test Email</th>
                        <th style="width:30px" align="left">Status Result</th>
                        <th align="left">IP Address</th>
                        <th align="left">Domain</th>
                        <th align="left">Platform</th>
                        <th align="left">Date</th>
                      </tr>
					    <?php
						$idNo = $start+1;
						$classADD = 0;
						if(count($alllogs) > 0){
							foreach($alllogs as $number => $data) {
							?>
							<tr <?php echo $classADD == 0 ? "class = 'odd'" : "class = 'even'";?>>
								<!--<td>
								<input name="checkbox[]" class="checkbox" type="checkbox"  value="<?php echo $data->id; ?>">
								</td>-->
								<td><?php echo $idNo;?></td>
								<td><?php 
								if($data->req_status == 0){
									echo $data->req_message;
								}else{
									echo $data->email;
								} ?></td>
								<td><?php if($data->req_status == 0){ echo "Fail";} else { echo $data->email_result; } ?></td>
								<td><?php echo $data->ipaddress;?></td>
								<td><?php echo $data->domain;?></td>
								<td><?php 
								if($data->platform == 'manually'){
									echo "Manually";
								}
								if($data->platform == 'csv_bulk'){
									echo "CSV Bulk";
								}
								if($data->platform == 'api_magento'){
									echo "API Magento";
								}
								
								if($data->platform == 'api_joomla_server'){
									echo "API Joomla Server";
								} 
								if($data->platform == 'api_joomla_client'){
									echo "API Joomla Client";
								}
								
								if($data->platform == 'api_joomla'){
									echo "API Joomla";
								}
								?></td>
								<td><?php echo $data->date;?></td>
							</tr>
							<?php $idNo++; $classADD = 1 - $classADD;}
						}else{ ?>
							<tr class="odd">
								<td colspan='4'><?php echo "No Logs";?></td>
							</tr>
						<?php }
						 ?>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
		  <div class="btnLeft">
          	<input type="submit" id="generateLog" value="Export Selected" name="generateLog" class="btnExport submit-button-dark" />
          </div>
		  
		  
		  
		  </form>
		<div class="paging-box paging-dashboard">
            <div style="clear:both;" class="pagination margin10-top">               
			  <?php
				echo $pagi_data;
			  ?>
            </div>
        </div>
        </div>
      </div>
	  <div style="float:left;width:200px;margin-top:40px;"></div>
	  
	  <SCRIPT language="javascript">
/*$(document).ready(function() {
	//var msgDis = $('#messageStatus').attr('display');
//	if(is_object($('#messageStatus'))) {
		$('#messageStatus').fadeOut(15000);
//		alert('k');
// 	
//	}
	//$('#messageStatus').delay(3000).fadeOut('slow');
	// add multiple select / deselect functionality
    $("#selectall").click(function () {
		$('#msg').hide();
        $('.checkbox').attr('checked', this.checked);
    });
    $(".checkbox").click(function(){
		
		if($(".checkbox").length == $(".checkbox:checked").length) {
			$('#msg').hide();
            $("#selectall").attr("checked", "checked");
        } else {
			$('#msg').hide();
            $("#selectall").removeAttr("checked");
        }
 
    });
	
	$('#mc-embedded-subscribe1').click(function(e){
		e.preventDefault();
		//alert($('.checkbox').is(':checked'));
		if($('.checkbox').is(':checked') == false){
			$('#msg').show();
			return false;
		} else {
			$('#frmEmails').submit();
		}
	});
});
*/
</SCRIPT>
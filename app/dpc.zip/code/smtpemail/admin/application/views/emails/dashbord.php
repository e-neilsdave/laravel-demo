
      <h1 class="page-title">Dashboard</h1>
      <div class="col-s-content-project">
        <div class="left-part-project">
          <div class="shadowed DashboardArea" id="items">
            <div class="inner-boundaries gp2">
              <div class="gried-view">
                <div class="project-box">
                  <div class="gray-box-bg">
                    <ul class="dashboardUL">
                      <li class="icon7"><a href="<?php echo site_url(array('emails','index')); ?>" title="Roles">All Emails</a></li>
                      <li class="icon11"><a href="<?php echo site_url(array('emails','myorderdetails')); ?>" title="Transactions">Transactions</a></li>
                      <li class="icon12"><a href="<?php echo site_url(array('emails','userLog')); ?>" title="Logs">Logs</a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            
          </div>
        </div>
      </div>
    

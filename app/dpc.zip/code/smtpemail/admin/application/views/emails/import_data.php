  <!--<script src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.6.1.min.js"></script>-->
<script type="text/javascript">
$(document).ready(function() {
	$("#add").click(function() {
		var cId = parseInt($("#count").val()) + 1;
        var intId = $("#buildyourform div").length + 1;
        var fieldWrapper = $("<div class=\"fieldwrapper\" />");
        var fName = $("<input type=\"text\" name=\"email[]\" class=\"name required add-form-input\" id=\"field" + cId + "\"/><div class=\"loadmsg\" id=\"msg" + cId + "\"></div>");
		
        var removeButton = $("<input style=\"float:left;padding: 4px 5px;\" type=\"button\" class=\"remove\" value=\"-\" />");
        removeButton.click(function() {
            $(this).parent().remove();
			var count = parseInt($("#count").val())-1; 
			$("#count").val(count);
			
			var obj = $('input[id^=field]');
			$.each( obj, function( i, val ) {
			var j = i + 1;
			$(this).attr('id','field'+j);
			});
			
			var divobj = $('div[id^=msg]');
			$.each( divobj, function( k, val ) {
			var m = k + 1;
			$(this).attr('id','msg'+m);
			});
        });
        fieldWrapper.append(fName);
        fieldWrapper.append(removeButton);
        $("#buildyourform").append(fieldWrapper);
		var count = parseInt($("#count").val())+1; 
		$("#count").val(count);
    });
});

function loadXmlDoc() {
	var counter = $("#count").val();
	var errorFlag = false;
	for(currntId=1;currntId<=counter;currntId++)
	{
		$('#msg'+currntId).html('');
		var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
		if($('#field'+currntId).val() == '') {
			$('#msg'+currntId).html('Please enter the email address.');
			errorFlag = true;
		}
		else if( !emailReg.test( $('#field'+currntId).val() ) ) {
			$('#msg'+currntId).html('Please enter proper email address.');
			errorFlag = true;
		} 
	}
	
	
	
	//
		if(errorFlag == false){
			$('#msg'+currntId).hide();
			var emailString = '';
			var emailobj = $('input[name^=email]');
			$.each( emailobj, function( iObj, valObj ) {
				emailString += $(this).val()+',';
			});
			
		//	alert(emailString);
			$('#load').show();
			$.ajax({
			type: 'post',
			url: "<?php echo site_url() . '/emails/import'; ?>",
			data: {emailString:emailString}, //'email=' + $('#file'+currntId).val(),
			success: function(data) {
				
				if(data == '1') {
			//		alert('Success');
					$('#load').hide();
					//$('#msg'+currntId).html('Success').hide().fadeIn(1500)  ;
					location.href = '<?php echo site_url() . '/emails/index/success'; ?>';
				} else {
			//		alert('Invalid');
					//$('#msg'+currntId).html('Invalid').hide().fadeIn(1500)  ;
				}
			}
			})
		}
	
}
</script>
  
  
  
  <h2 class="page-title">Validate Emails Manually</h2>
  <?php if(isset($errorMsg)) { ?>
	<div class="errorMessageHeader"><span><?php echo $errorMsg; ?></span></div>
  <?php } ?>
  
	<?php 
	$successMessage = $this->session->userdata('successMessage');
	if(trim($successMessage) != '') { 
		echo '<div class="successMessageHeader"><span>'.trim($successMessage).'</span></div>'; 
		$this->session->set_userdata(array('successMessage' => ''));
	}
	?>
  
    <div class="col-s-content">
        <div class="left-part">
		<?php 
		/*
		echo "yes = <pre>";print_R($perdaylimit);
		echo "yes = <pre>";print_R($priceDetails);
		
		
		
		
		if($perdaylimit->countData <= $priceDetails->max_per_day){
			echo "you can";
		} else {
			echo "you can not";
		}
		*/
		//$perdaylimit->countData = 102;
		//echo "<pre>";print_r($points->end_date);echo "<br />".date('Y-m-d H:i:s');
		if($points->end_date >= date('Y-m-d H:i:s')){
			
			if($perdaylimit->countData <= $priceDetails->max_per_day){
				
				if($points->point == 0){ ?>
				<div class="shadowed" id="items" style="margin-bottom:10px">
					<div class="inner-boundary">
					  <div class="signup-content">
					  Please Buy the Credit Points.
					  </div>
					 </div>
				</div>
				<?php } else { ?>
				<div class="shadowed" id="items" style="margin-bottom:10px">
					<div class="inner-boundary">
					  <div class="signup-content">
						<form name="singleMail" method="post" action="" id="singleMail" enctype="multipart/form-data">
						  <div class="add-form-box">
							
							<div id="buildyourform">
								<div class="fieldwrapper">
									<input type="text" name="email[]" class="name required add-form-input" id="field1" >
									<div class="loadmsg" id="msg1"></div>
								</div>
								
							</div>
							<input type="hidden" id="count" name="count" value="1">
							<div style="float:left;width:100%;margin:10px 0">
								<input type="button" value="Add a field" class="add" id="add" >
							</div>
							<div style="float:left;">
								<input style="margin:10px 0" type="button" class="validateButton" id="submit" name="submit" value="Submit" onclick="loadXmlDoc()" >
							</div>
							<div class="loading" id="load"></div>
							<!--<li>
								<input value="" type="text" name="file<?php echo $i;?>" id="file<?php echo $i;?>" class="name required add-form-input">
								
								<input type="button" class="validateButton" id="submit<?php echo $i;?>" name="submit<?php echo $i;?>" value="Validate" onclick="loadXmlDoc(<?php echo $i;?>)" />
								<div class="loading" id="load<?php echo $i;?>"></div>
								<div class="loadmsg" id="msg<?php echo $i;?>"></div>
								<span class="field_error" style="display: none;"> </span> 
							</li>-->
						
						  </div>
						</form>
					  </div>
					</div>	
				</div>
				
				<h2 class="page-title">Validate Emails bulk CSV</h2>
				<div class="shadowed" id="items">
					<div class="inner-boundary">
					  <div class="signup-content">
						<form name="createAccount" method="post" action="" id="createAccount" enctype="multipart/form-data">
						<div class="add-form-box">
							<p>To validate various emails in bulk, simply download the Simple CSV, and change  the email address  whom you want to validate. Once your CSV is ready upload it below and hit validation button.</p>
							<br />
							<ul>
							  <li>
								<label style="font-weight:bold"><em>*</em> Upload CSV:</label>
								<input type="file" name="file_csv" id="file_csv" class="name required add-form-input">
								<span class="field_error" style="display: none;"> </span> </li>
							</ul>
						</div>
						<div class="submit-btn noMargin">
						   <button class="submit-button-dark" id="mc-embedded-subscribe1" name="importdata" type="submit"><span class="sprite"><em class="sprite">Submit</em></span></button>
							<button class="submit-button-dark" id="mc-embedded-subscribe1" name="cancel" value="cancel" type=		"submit"><span class="sprite"><em class="sprite">Cancel</em></span></button>
						</div>
							
						<div id="downloadSample">Download: <a target="_blank" id= "downloadSampleMain" href="<?php echo base_url("sampleData/emails.csv");?>"><span >Sample CSV</span></a>
						</div>
						</form>
					  </div>
					</div>
				  </div>
				  <?php }
			
			} else {
				?>
				
				<div class="shadowed" id="items" style="margin-bottom:10px">
					<div class="inner-boundary">
					  <div class="signup-content">
					  You can not validate more then <?php echo $priceDetails->max_per_day; ?> emails per day.
					  </div>
					 </div>
				</div>
				
			<?php }
			
		
		}
		else{?>
			<div class="shadowed" id="items" style="margin-bottom:10px">
				<div class="inner-boundary">
				  <div class="signup-content">
				  Please Buy the Credit Points. Your validity is expired.
				  </div>
				 </div>
			</div>
		<?php } ?>
		
        </div>
      </div>

<h1 class="page-title thank-you-title">Thank You</h1>
<div class="col-s-content thank-you-style">
    <div class="left-part">
		<div class="gried-view">
                    <div class="project-list-box shadowed">
                      <div class="sorter date-sorter inner-boundaries">
                          <div class="gried-view">
                              <div class="project-box">
                                <?php echo $message; //echo "<pre>";print_r($alldata); ?>	
                              </div>    
                          </div>
                        </div>
                     </div>
		</div>
	</div>
</div>
    
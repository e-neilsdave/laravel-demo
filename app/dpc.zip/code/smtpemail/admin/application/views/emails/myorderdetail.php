<SCRIPT language="javascript">
$(function(){ 
    // add multiple select / deselect functionality
    $("#selectall").click(function () {
          $('.checkbox').attr('checked', this.checked);
    });
    $(".checkbox").click(function(){
        if($(".checkbox").length == $(".checkbox:checked").length) {
            $("#selectall").attr("checked", "checked");
        } else {
            $("#selectall").removeAttr("checked");
        }
    });
});
</SCRIPT>
<?php //echo "<pre>";print_r($allTransectionDetails);?>
	<h1 class="page-title">My Order Details</h1>
    <?php 
	$successMessage = $this->session->userdata('successMessage');
	if(trim($successMessage) != '') { ?>
	<table>
		<tr class="title">
			<th align="center" valign="middle" height="25" colspan="7" class="successMessage">
				<?php
				echo trim($successMessage); 
				$this->session->set_userdata(array('successMessage' => '')); ?>
			</th>
		</tr>
	</table>
	<?php } ?>	
	<?php 
	$errorMessage = $this->session->userdata('errorMessage');
	if(trim($errorMessage) != '') { 
		echo '<div class="errorMessage"><span>'.trim($errorMessage).'</span></div>'; 
		$this->session->set_userdata(array('errorMessage' => ''));
	}
	?>
	
	<div class="col-s-content-project">
        <div class="left-part-project">
		<form action="" class="selection fancy-form order" method="get">
        <div class="gried-view">
            <div class="project-list-box">
              <div class="sorter date-sorter">
				<?php 
				if(!isset($_GET['sort_by'])) {
					$_GET['sort_by'] = 25;
				}
				?>
	            <label class="font-9" for="sort_by">Show </label>
                <select style="width:30px;" class="sort_order" id="sort_by" name="sort_by" onchange="$('.checkbox').attr('checked', false); this.form.submit()" >
					<option value="5" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '5') { ?> selected = "selected" <?php } ?>>5</option>
					<option value="10" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '10') { ?> selected = "selected" <?php } ?>>10</option>
					<option value="15" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '15') { ?> selected = "selected" <?php } ?>>15</option>
					<option value="25" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '25') { ?> selected = "selected" <?php } ?>>25</option>
					<option value="50" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '50') { ?> selected = "selected" <?php } ?>>50</option>
					<option value="100" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '100') { ?> selected = "selected" <?php } ?>>100</option>
					<option value="-1" <?php if(isset($_GET['sort_by']) && $_GET['sort_by'] == '-1') { ?> selected = "selected" <?php } ?>>All</option>
                </select>
                  <label>&nbsp;&nbsp;&nbsp;Records</label>
				<!--   <input type="text" name="search" class="searchbox_class" onclick="this.value = ''" <?php /* if(isset($_GET['search']) && $_GET['search'] != 'Search by email...') { ?> value="<?php echo $_GET['search'];?>" <?php } else { ?> value="Search by email..." <?php } ?> onblur="if(this.value==''){this.value='Search by email...'};" />
                  <select style="width:85px;" class="sort_order" id="membership" name="membership" onchange="$('.checkbox').attr('checked', false); this.form.submit()">
                    <option value="">--Membership--</option>
                    <option value="bronze" <?php if(isset($_GET['membership']) && $_GET['membership'] == 'bronze') { ?> selected = "selected" <?php } ?>>bronze</option>
                    <option value="silver" <?php if(isset($_GET['membership']) && $_GET['membership'] == 'silver') { ?> selected = "selected" <?php } ?>>silver</option>
					<option value="gold" <?php if(isset($_GET['membership']) && $_GET['membership'] == 'gold') { ?> selected = "selected" <?php } ?>>gold</option>
					<option value="platinum" <?php if(isset($_GET['membership']) && $_GET['membership'] == 'platinum') { ?> selected = "selected" <?php } ?>>platinum</option>
                  </select>
                  <button onclick="$('.checkbox').attr('checked', false);" class="submit-button-dark" id="mc-embedded-subscribe" type="submit" style="margin-left:10px;"><span class="sprite"><em class="sprite">GO</em></span></button>
				  
<div style="float:right;"><a href="<?php echo site_url(array('admin','transectiondetail')); */?>" class="submit-button-dark" id="mc-embedded-subscribe"><span class="sprite"><em class="sprite">Reset</em></span></a></div>	-->			  
              </div>
            </div>
          </div>
		
          <div class="shadowed" id="items">
            <div class="inner-boundaries">
              <div class="gried-view">
                <div class="project-box">
                  <div class="gray-box-bg">
					<table cellpadding="0" cellspacing="0" border="0" width="100%" class="gridViewTable" >
                      <tr>
						<!--<th align="left" style="width:30px">
							<input name="selectall" id="selectall" type="checkbox">
						</th>-->
                        <th style="width:30px" align="left">Id</th>
						<th align="left">Transaction ID</th>
						<th align="left">Date</th>
                        <th align="left">Email</th>
                        <th align="left">Membership</th>
						<th align="left">Price</th>
						<th align="left">Points</th>
						<th align="left">Action</th>
                      </tr>
					    <?php
						$idNo = $start+1;
						$classADD = 0;
						if(count($allTransectionDetails) > 0){
							foreach($allTransectionDetails as $number => $data) {
							?>
							<tr <?php echo $classADD == 0 ? "class = 'odd'" : "class = 'even'";?>>
								<!--<td>
								<input name="checkbox[]" class="checkbox" type="checkbox"  value="<?php echo $idNo; ?>">
								</td>-->
								<td><?php echo $idNo;?></td>
								<td><?php echo $data->txn_id;?></td>
								<td><?php echo $data->payment_date;?></td>
								<td><?php echo $data->payer_email;?></td>
								<td><?php echo $data->item_name;?></td>
								<td><?php echo "$".$data->mc_gross;?></td>
								<td><?php echo $data->no_of_mail;?></td>
								<td><a href="<?php echo site_url() . '/emails/pdf/'.$data->id;?>" ><img width="25" title="Download Invoice PDF" alt="" src="<?php echo $this->config->item('base_url'); ?>images/login_as_a_user.png"></a></td>
							</tr>
							<?php $idNo++; $classADD = 1 - $classADD;}
						}else{ ?>
							<tr class="odd">
								<td colspan='4'><?php echo "No Record";?></td>
							</tr>
						<?php }
						 ?>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
		  
		  </form>
		<div class="paging-box paging-dashboard">
            <div style="clear:both;" class="pagination margin10-top">               
			  <?php
				echo $pagi_data;
			  ?>
            </div>
        </div>
        </div>
      </div>
	  <div style="float:left;width:200px;margin-top:40px;"></div>
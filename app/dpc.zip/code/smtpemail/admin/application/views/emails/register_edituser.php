<h1 class="page-title">Edit User Account</h1>

<?php 
$successMessage = $this->session->userdata('successMessage');
if(trim($successMessage) != '') { 
	echo '<div class="successMessageHeader"><span>'.trim($successMessage).'</span></div>'; 
	$this->session->set_userdata(array('successMessage' => ''));
}
?>
	
<div class="col-s-content">
	<div class="left-part">
		<div class="shadowed" id="items">
			<div class="inner-boundary">
				<form action="" method="post" class="queryForm" style="float: none;">
					<div class="add-form-box">
						<ul>
							<li>
								<label>Full Name</label>
								<input type="text" name="username" id="username" value="<?php echo (isset($postData['username'])) ? $postData['username'] : '';?>" class="add-form-input" />
								<div class="errorbox"><?php echo form_error('username'); ?></div>
							</li>

							<li>
								<label>Email Address</label>
								<input type="text" readonly="readonly" name="email" id="email" value="<?php echo (isset($postData['email'])) ? $postData['email'] : '';?>" class="add-form-input" />
								<div class="errorbox"><?php echo form_error('email'); ?></div>
							</li>

							<input type="hidden" name="id" id="id" value="<?php echo (isset($postData['id'])) ? $postData['id'] : '';?>" class="add-form-input" />

							<li>
								<label>Password</label>
								<input type="password" value="" name="password" id="password" class="add-form-input" />
								<div class="errorbox"><?php echo form_error('password'); ?></div>
							</li>

							<li>
								<label>Confirm Password</label>
								<input type="password" value="" name="confirm_password" id="confirm_password" class="add-form-input" />
								<div class="errorbox"><?php echo form_error('confirm_password'); ?></div>
							</li>
						</ul>
					</div>
					<div class="submit-btn noMargin">
						<button class="submit-button-dark" id="mc-embedded-subscribe2" name="subscribe" type="submit"><span class="sprite"><em class="sprite">Update Your Account</em></span></button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
 
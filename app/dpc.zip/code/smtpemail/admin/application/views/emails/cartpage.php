		<?php //echo "data<pre>";print_R($pricingDetails);?>	
		<table width="100%" cellspacing="0" cellpadding="0" border="0" style=" text-align: center;">
             <thead>
                  <tr>
					<td  class="" >
                    	<div class="priceHeaderTitle">
                            <h2><?php echo "Product Name";?></h2>
						</div>
					</td>	
					<td  class="" >
						<div class="priceHeaderTitle">
                            <h2><?php echo "Price";?></h2>
						</div>						
                    </td>
					<td  class="" >
						<div class="priceHeaderTitle">
                            <h2><?php echo "Total Mails";?></h2>
						</div>						
                    </td>
					<td  class="" >
						<div class="priceHeaderTitle">
                            <h2><?php echo "Total";?></h2>
						</div>						
                    </td>
                  </tr>
			</thead>
                  
			<tbody>
				<tr class="priceTitle">
					<td>
						<h3>
						<?php  echo $priceDetails->mailtype; ?>
						</h3>
					</td>
					<td>	
						<h3>
						<?php  echo "$".$priceDetails->price; ?>
						</h3>
					</td>
					<td>	
						<h3>
						<?php  echo $priceDetails->no_of_mail; ?>
						</h3>
					</td>
					<td>	
						<h3>
						<?php  echo "$".$priceDetails->price; ?>
						</h3>
					</td>					
                </tr>
				
            </tbody>
		</table>
		<table width="100%" cellspacing="0" cellpadding="0" border="0" style="float:right;">	
		<tfoot>
                  <tr>
    				<td>
						<a href="<?php echo GLOBAL_PATH . 'emails/paypalForm/'.$priceDetails->id ; ?>" class="submit-button-dark" id="mc-embedded-subscribe"><span class="sprite"><em class="sprite">Place Order</em></span></a></div>
					</td>
				  </tr>
			</tfoot>
        </table>
		 
		
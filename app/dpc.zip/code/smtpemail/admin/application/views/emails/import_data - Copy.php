  <!--<script src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.6.1.min.js"></script>-->
  <script type="text/javascript">
  function loadXmlDoc(currntId) {
  $('#msg'+currntId).html('');
  var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
  if($('#file'+currntId).val() == '') {
	//alert('Blank');
	$('#msg'+currntId).html('Enter Email Address').hide().fadeIn(1500)  ;
	} else if( !emailReg.test( $('#file'+currntId).val() ) ) {
    //alert('Invalid');
	$('#msg'+currntId).html('Invalid Email Address').hide().fadeIn(1500)  ;
  } else {
	$('#load'+currntId).show();
	//alert($('#file'+currntId).val());
	//alert( "<?php echo site_url() . '/emails/import'; ?>?email="+$('#file'+currntId).val() );
	$.ajax({
	url: "<?php echo site_url() . '/emails/import'; ?>",
	data: 'email=' + $('#file'+currntId).val(),
    success: function(data) {
	//alert(data);
	if(data == '1') {
	//	alert('Success');
		$('#load'+currntId).hide();
		//$('#msg'+currntId).html('Success').hide().fadeIn(1500)  ;
		location.href = '<?php echo site_url() . '/emails/index'; ?>';
	} else {
	//	alert('Invalid');
		//$('#msg'+currntId).html('Invalid').hide().fadeIn(1500)  ;
	}
    }
	})
  }
  
   
  }
     
 </script>
  
  
  
  <h2 class="page-title">Import Emails</h2>
  <?php if(isset($errorMsg)) { ?>
	<div class="errorMessageHeader"><span><?php echo $errorMsg; ?></span></div>
  <?php } ?>
  
	<?php 
	$successMessage = $this->session->userdata('successMessage');
	if(trim($successMessage) != '') { 
		echo '<div class="successMessageHeader"><span>'.trim($successMessage).'</span></div>'; 
		$this->session->set_userdata(array('successMessage' => ''));
	}
	?>
  
    <div class="col-s-content">
        <div class="left-part">
		
		
		
		
		<?php if($points->point == 0){ ?>
		<div class="shadowed" id="items" style="margin-bottom:10px">
			<div class="inner-boundary">
              <div class="signup-content">
			  Please Buy the Creadit Points
			  </div>
			 </div>
		</div>
		<?php } else { ?>
		<div class="shadowed" id="items" style="margin-bottom:10px">
			<div class="inner-boundary">
              <div class="signup-content">
                <form name="singleMail" method="post" action="" id="singleMail" enctype="multipart/form-data">
                  <div class="add-form-box">
                    <ul>
					<?php 
					/*
					$Emailpoint = $points->point;
					
					if($points->point >= 10){
					$Emailpoint = 10;
					}
					
					for($i=1;$i<=$Emailpoint;$i++){ ?>
                    <li>
                        <input value="" type="text" name="file<?php echo $i;?>" id="file<?php echo $i;?>" class="name required add-form-input">
						
						<input type="button" class="validateButton" id="submit<?php echo $i;?>" name="submit<?php echo $i;?>" value="Validate" onclick="loadXmlDoc(<?php echo $i;?>)" />
						<div class="loading" id="load<?php echo $i;?>"></div>
						<div class="loadmsg" id="msg<?php echo $i;?>"></div>
                        <span class="field_error" style="display: none;"> </span> 
					</li>
					<?php } */ ?>
					<script>
					
					$(document).ready(function() {
						$("#add").click(function() {
							var intId = $("#buildyourform div").length + 1;
							
							var fName = $("<input type=\"text\" size=\"20\" class=\"inputbox input-xlarge input-large-text\" value=\"\" id=\"jform_photoname\" name=\"jform[add_photoname][]\">");
							
							var removeButton = $("<input type=\"button\" class=\"remove\" value=\"-\" />");
							removeButton.click(function() {
								$(this).parent().remove();
							});
							fieldWrapper.append(fName);
							fieldWrapper.append(removeButton);
							$("#buildyourform").append(fieldWrapper);
						});

					</script>
					<li>
                        <input value="" type="text" name="file[]" id="file_last[0]" class="name required add-form-input">
						<input type="button" value="Insert" onclick="insert()">
						
						<input type="button" class="validateButton" id="submit<?php echo $i;?>" name="submit<?php echo $i;?>" value="Validate" onclick="loadXmlDoc(<?php echo $i;?>)" />
						
						
						<!--<div class="loading" id="load<?php echo $i;?>"></div>
						<div class="loadmsg" id="msg<?php echo $i;?>"></div>-->
                        <span class="field_error" style="display: none;"> </span> 
					</li>
					
                    </ul>
                  </div>
                </form>
              </div>
            </div>	
		</div>
		
		<h2 class="page-title">Import Emails (bulk)</h2>
        <div class="shadowed" id="items">
			<div class="inner-boundary">
              <div class="signup-content">
                <form name="createAccount" method="post" action="" id="createAccount" enctype="multipart/form-data">
                  <div class="add-form-box">
					<p>To validate various emails in bulk, simply download the Simple CSV, and change  the email address  whom you want to validate. Once your CSV is ready upload it below and hit validation button.</p>
					<br />
                    <ul>
                      <li>
                        <label style="font-weight:bold"><em>*</em> Upload CSV:</label>
                        <input type="file" name="file_csv" id="file_csv" class="name required add-form-input">
                        <span class="field_error" style="display: none;"> </span> </li>
                    </ul>
                  </div>
                  <div class="submit-btn noMargin">
                   <button class="submit-button-dark" id="mc-embedded-subscribe1" name="importdata" type="submit"><span class="sprite"><em class="sprite">Save</em></span></button>
              <button class="submit-button-dark" id="mc-embedded-subscribe1" name="cancel" value="cancel" type=		"submit"><span class="sprite"><em class="sprite">Cancel</em></span></button>
			  </div>
					
				  <div id="downloadSample">Download: <a id= "downloadSampleMain" href="<?php echo base_url("sampleData/emails.csv");?>"><span >Sample CSV</span></a>
				  </div>
                </form>
              </div>
            </div>
          </div>
		  <?php } ?>
        </div>
      </div>

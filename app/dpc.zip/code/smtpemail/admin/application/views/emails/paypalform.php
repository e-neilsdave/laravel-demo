<script type="text/javascript">
$(document).ready(function() {
	$('#paypalForm').submit();
});
</script>

<?php
//echo "<pre>";print_R($priceDetails);
//exit;
?>

<form id="paypalForm" action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post" id="paypal">
<input type="hidden" name="cmd" value="_xclick" />
<input type="hidden" name="cbt" value="Return to example" />
<input type="hidden" name="business" value="jaylaxmi.dwivedi-facilitator@silvertouch.com" />
<input type="hidden" name="item_name" value="<?php echo $priceDetails->mailtype;?>" />
<input type="hidden" name="amount" value="<?php echo $priceDetails->price;?>">
<input type="hidden" name="button_subtype" value="services" />
<input type="hidden" name="on0" value="Mails">
<input type="hidden" name="os0" value="<?php echo $priceDetails->no_of_mail;?>">
<input type="hidden" name="no_shipping" value="1">
<input type="hidden" name="return" value="<?php echo site_url() . '/emails/thankyou/'.$priceDetails->id;?>" />
<input type="hidden" name="notify_url" value="<?php echo site_url() . '/emails/notify/';?>"/>
<input type="hidden" name="cancel_return" value="<?php echo site_url() . '/emails/cancel/';?>" />
<input type="hidden" name="currency_code" value="USD"/>
<input type="hidden" name="image_url" value="" />
<input type="hidden" id="custom" name="custom" value="invoice_id to track"/>
<input type="hidden" class="btn btn-primary" style="width:100%" alt="PayPal - The safer, easier way to pay online!"/>
</form>

<div class="col-s-content-project">
    <div class="left-part-project">
			<div style="float: left;margin-bottom: 50px;text-align: center;width: 100%;">
				<img src="<?php echo $this->config->item('base_url'); ?>images/loading.gif" alt="Silver Touch" />
			</div>
<!--			<div style="float: left;margin-bottom: 50px;text-align: center;width: 100%;">
				Page is redirect on paypal, Please wait
			</div>	-->
	<?php 
		echo "<center><h2>Please wait, your order is being processed and you";
		echo " will be redirected to the paypal website.</h2></center>\n";			
	?>
	</div>
</div>
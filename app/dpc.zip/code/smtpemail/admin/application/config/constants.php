<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| File and Directory Modes
|--------------------------------------------------------------------------
|
| These prefs are used when checking and setting modes when working
| with the file system.  The defaults are fine on servers with proper
| security, but you may wish (or even need) to change the values in
| certain environments (Apache running a separate process for each
| user, PHP under CGI with Apache suEXEC, etc.).  Octal values should
| always be used to set the mode correctly.
|
*/
define('FILE_READ_MODE', 0644);
define('FILE_WRITE_MODE', 0666);
define('DIR_READ_MODE', 0755);
define('DIR_WRITE_MODE', 0777);

/*
|--------------------------------------------------------------------------
| File Stream Modes
|--------------------------------------------------------------------------
|
| These modes are used when working with fopen()/popen()
|
*/

define('FOPEN_READ',							'rb');
define('FOPEN_READ_WRITE',						'r+b');
define('FOPEN_WRITE_CREATE_DESTRUCTIVE',		'wb'); // truncates existing file data, use with care
define('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE',	'w+b'); // truncates existing file data, use with care
define('FOPEN_WRITE_CREATE',					'ab');
define('FOPEN_READ_WRITE_CREATE',				'a+b');
define('FOPEN_WRITE_CREATE_STRICT',				'xb');
define('FOPEN_READ_WRITE_CREATE_STRICT',		'x+b');


define('UNDEFINED_CLASS_ID', '1');
define('UNDEFINED_UNIT_ID', '0');
define('UNDEFINED_CLUSTER_ID', '1');

define('RECORDS_PER_PAGE', '25');

define('DATE_FORMAT', 'm.d.Y');
define('STATICS_RECORD_TYPE_ID', '7');

define('STANDERED_LANGUAGE_ID', '1');
define('STANDERED_KEYWORD', 'standard');
define('SUPER_ADMIN_ROLE_ID', '1');


/* Permission Ids starts here */
define('PERMISSION_VIEW_USERS', '1');
define('PERMISSION_ACTIVE_INACTIVE_USER', '2');
define('PERMISSION_CREATE_USER', '3');
define('PERMISSION_DEFINE_USER', '4');
define('PERMISSION_VIEW_ROLE', '5');
define('PERMISSION_ACTIVE_INACTIVE_ROLE', '6');
define('PERMISSION_CREATE_ROLE', '7');
define('PERMISSION_DEFINE_ROLE', '8');
define('PERMISSION_VIEW_PERMISSION', '9');
define('PERMISSION_CREATE_PERMISSION', '10');
define('PERMISSION_VIEW_OBLIGATION', '11');
define('PERMISSION_CREATE_OBLIGATION', '12');
define('PERMISSION_EDIT_USER', '13');
define('PERMISSION_EDIT_ROLE', '14');
define('PERMISSION_EDIT_PERMISSION', '15');
define('PERMISSION_EDIT_OBLIGATION', '16');
define('PERMISSION_CREATE_COMPANY', '17');
define('PERMISSION_VIEW_COMPANY', '18');
define('PERMISSION_EDIT_COMPANY', '19');
define('PERMISSION_ACTIVE_INACTIVE_COMPANY', '20');
define('PERMISSION_DEFINE_COMPANY_WISE_STATISTICS', '21');
define('PERMISSION_VIEW_STATISTICS', '22');
define('PERMISSION_CREATE_STATISTICS', '23');
define('PERMISSION_UPDATE_STATISTICS', '24');
define('PERMISSION_VIEW_CLASSES', '25');
define('PERMISSION_CREATE_CLASS', '26');
define('PERMISSION_VIEW_CLUSTER', '27');
define('PERMISSION_CREATE_CLUSTER', '28');
define('PERMISSION_DELETE_STATISTICS', '29');
define('PERMISSION_EDIT_CLASSES', '30');
define('PERMISSION_DELETE_CLASSES', '31');
define('PERMISSION_EDIT_CLUSTERS', '32');
define('PERMISSION_DELETE_CLUSTERS', '33');
define('PERMISSION_VIEW_UNITS', '34');
define('PERMISSION_CREATE_UNITS', '35');
define('PERMISSION_EDIT_UNITS', '36');
define('PERMISSION_DELETE_UNITS', '37');
define('PERMISSION_DELETE_COMPANY', '39');
define('PERMISSION_VIEW_LANGUAGES', '40');
define('PERMISSION_CREATE_LANGUAGE', '41');
define('PERMISSION_DELETE_LANGUAGE', '42');
define('PERMISSION_EDIT_LANGUAGE_File', '43');
define('PERMISSION_ACTIVE_INACTIVE_LANGUAGE', '44');
define('PERMISSION_DEFINE_Mandatory_LANGUAGES', '45');
define('PERMISSION_DELETE_USERS', '46');
define('PERMISSION_DELETE_ROLE', '47');
define('PERMISSION_DELETE_PERMISSION', '48');
define('PERMISSION_DELETE_OBLIGATION', '49');

define('OBLIGATION_UPDATE_STATISTICS', '1');
define('price_for_partner_advantage', '10');
define('price_for_godfather_advantage', '20');

//define('OBLIGATION_UPDATE_NEWS', '2');
//define('OBLIGATION_RESPOND_INQUEIRES', '3');
/* Permission Ids ends here */

/* End of file constants.php */
/* Location: ./application/config/constants.php */
<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/*

* reCaptcha File Config
*
* File : recaptcha.php
* Created : May 14, 2013 | 4:22:40 PM
*
* Author : Andi Irwandi Langgara <irwandi@ourbluecode.com>
*/
/*
$config['public_key'] = '6LcJ_PMSAAAAAD_0f4uY7Q4tTpX9fRbVcRtYt3hh';  //'6LdDv-cSAAAAAIJVbMy6Tm5LKaIUgTbxUol3-SJx';//'YOUR PUBLIC KEY';
$config['private_key'] = '6LcJ_PMSAAAAAHSBmZnuQCeJbvxKG0QBRf_fGTPO'; //'6LdDv-cSAAAAAFqXhmCh-2A6Hasbsx4hfjbp4HAr';//'YOUR PRIVATE KEY';
// Set Recaptcha theme, default red (red/white/blackglass/clean)
$config['recaptcha_theme'] = 'white';

*/

if($_SERVER['HTTP_HOST'] == '192.168.0.121'){
	$config['public_key'] = '6LenkO4SAAAAACHDJ2ory8v4EXDoiaEzOzR2LFLV';//'YOUR PUBLIC KEY';
	$config['private_key'] = '6LenkO4SAAAAAMM4H9ZSOlsO99IQON4djz6Q6ohA';//'YOUR PRIVATE KEY';
	// Set Recaptcha theme, default red (red/white/blackglass/clean)
	$config['recaptcha_theme'] = 'red';
}

if($_SERVER['HTTP_HOST'] == '202.131.117.210'){
	$config['public_key'] = '6LdDv-cSAAAAAIJVbMy6Tm5LKaIUgTbxUol3-SJx';//'YOUR PUBLIC KEY';
	$config['private_key'] = '6LdDv-cSAAAAAFqXhmCh-2A6Hasbsx4hfjbp4HAr';//'YOUR PRIVATE KEY';
	// Set Recaptcha theme, default red (red/white/blackglass/clean)
	$config['recaptcha_theme'] = 'red';
}

if($_SERVER['HTTP_HOST'] == 'localhost'){
	$config['public_key'] = '6Lc6bM0SAAAAAHlW0UU3Ol-qGEuqf7vm1kALJ-in'; //'YOUR PUBLIC KEY';
	$config['private_key'] = '6Lc6bM0SAAAAAHPUv-EXUQMdPuu8JrUr8DDvIEgt'; //'YOUR PRIVATE KEY';
	// Set Recaptcha theme, default red (red/white/blackglass/clean)
	$config['recaptcha_theme'] = 'red';
}
if($_SERVER['HTTP_HOST'] == '103.19.89.91'){
	$config['public_key'] = '6LePzPQSAAAAAGKD9swVNjVGxcz54qR9N15J2MjZ'; //'YOUR PUBLIC KEY';
	$config['private_key'] = '6LePzPQSAAAAANuG2YWva9DMZrNUlKnQZfVZXQwS'; //'YOUR PRIVATE KEY';
	// Set Recaptcha theme, default red (red/white/blackglass/clean)
	$config['recaptcha_theme'] = 'red';
}
if($_SERVER['HTTP_HOST'] == 'emailvalidated.com'){
	$config['public_key'] = '6Lc6WvsSAAAAAN8ewjOAahC13kxbr3dcw3QFCAQb'; //'YOUR PUBLIC KEY';
	$config['private_key'] = '6Lc6WvsSAAAAAGby9J_Xby-dF-qtfKm5xWcn-878'; //'YOUR PRIVATE KEY';
	// Set Recaptcha theme, default red (red/white/blackglass/clean)
	$config['recaptcha_theme'] = 'red';
}
if($_SERVER['HTTP_HOST'] == 'www.emailvalidated.com'){
	$config['public_key'] = '6Lftg_sSAAAAAE_upvudcetHS0kd67VIs7EJabWb'; //'YOUR PUBLIC KEY';
	$config['private_key'] = '6Lftg_sSAAAAAE4o0N9ovNSDu6FLB2PW1tHiVHh-'; //'YOUR PRIVATE KEY';
	// Set Recaptcha theme, default red (red/white/blackglass/clean)
	$config['recaptcha_theme'] = 'red';
}

?>


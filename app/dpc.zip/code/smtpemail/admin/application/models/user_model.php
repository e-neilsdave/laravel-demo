<?php
class user_model extends CI_Model {

    var $title   = '';
    var $content = '';
    var $date    = '';

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    
    function validate_user_auth($userName, $password) {
        $sql = "select * FROM users WHERE (email = '".$userName."') AND password = '".md5($password)."' AND status = '1'";
		$rs = $this->db->query($sql);
        return $arrRes = $rs->result();
    }
	
	function user_name_exists($userName) {
		$sql = "select * FROM users WHERE ( email = '".$userName."') ";
		$rs = $this->db->query($sql);
		return $arrRes = $rs->num_rows();
    }
    
    function reset_password($userName) {
        $newPassword = Commonfunctions::generatePassword();
        $sql = "update users SET password = md5('".$newPassword."') WHERE (email = '".$userName."') ";
        $rs = $this->db->query($sql);
        
        $sql = "select * FROM users WHERE (email = '".$userName."') ";
        $rs = $this->db->query($sql);
        $arrRes = $rs->result();
        return array($arrRes, $newPassword);
    }
    
	function change_password($userId, $newPassword, $forgotFlag = 0) {
        $sql = "update user SET password = md5('".$newPassword."'), forgot_flag = '".$forgotFlag."' WHERE id = '".$userId."' ";
        $rs = $this->db->query($sql);
    }
	//get_user_details
	
	function get_user_details($userId, $returnType = 'class') {
        $sql = "select * FROM users where id = '".$userId."' ";
        $rs = $this->db->query($sql);
		if($returnType == 'class') {
            return $arrRes = $rs->result();
        } else {
            $arrRes = $rs->result_array();
            return $arrRes[0];
        }
    }
	
	function getUserMembershipType(){
		$userid = $this->session->userdata('login_id');
		$sql = "select user_type FROM users WHERE ( id = '".$userid."') ";
		$rs = $this->db->query($sql);
        $arrRes = $rs->result();
		return $arrRes[0];
	}
	
	function generateRandomString($length = 10) {
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, strlen($characters) - 1)];
		}
		return $randomString;
	}
	
	function getEmailBody($templateName){
		$userid = $this->session->userdata('login_id');
		$sql = "select * FROM emailtemplate WHERE ( email_alias = '".$templateName."') ";
		$rs = $this->db->query($sql);
        $arrRes = $rs->result();
		return $arrRes[0];
	}
	
	function getFreePoints(){
		$sql = "select no_of_mail FROM pricing_details WHERE ( mailtype = 'free') ";
		echo $sql;
		$rs = $this->db->query($sql);
        $arrRes = $rs->result();
		return $arrRes[0];
	}
	
}

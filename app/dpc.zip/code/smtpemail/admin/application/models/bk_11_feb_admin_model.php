<?php
class admin_model extends CI_Model {

	/**
     * constructor
     *  
     * @return void
     */ 
	
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
		$this->load->database();
    }
    
	function getPricingDetails($itemID = '') {
		if($itemID == ''){
			$sql = "select * from pricing_details where mailtype != 'free'";
			$rs = $this->db->query($sql);
			$arrRes = $rs->result();
			return $arrRes;
		}else{
			$sql = "select * from pricing_details where mailtype != 'free' and id =".$itemID;
			$rs = $this->db->query($sql);
			$arrRes = $rs->result();
			return $arrRes[0];
		}
		
	}
	
	function getNewsDetails($itemID = '') {
		if($itemID == ''){
			$sql = "select * from newslater";
			$rs = $this->db->query($sql);
			$arrRes = $rs->result();
			return $arrRes;
		}else{
			$sql = "select * from newslater where id =".$itemID;
			$rs = $this->db->query($sql);
			$arrRes = $rs->result();
			return $arrRes[0];
		}
		
	}
	
	function get_all_user($where) {
		$sql = "SELECT a.*,b.point FROM `users` as a inner join emailpoints as b  WHERE a.id = b.userid and user_type != 'admin' and $where";
		//echo "<br /> 1= ".$sql;
        $rs = $this->db->query($sql);
        $arrRes = $rs->result();
        return $arrRes;
	}
	
	function get_all_users($where,$start = '',$limit= '') {
		if(empty($limit)){
			$sql = "SELECT a.*,b.point,b.membership_type,c.mailtype FROM `users` as a inner join emailpoints as b inner join pricing_details as c WHERE a.id = b.userid and user_type != 'admin' and b.membership_type = c.id and $where order by id DESC";
			//echo "<br /> 2 = ".$sql;
		}else{
			$sql = "SELECT a.*,b.point,b.membership_type,c.mailtype FROM `users` as a inner join emailpoints as b inner join pricing_details as c WHERE a.id = b.userid and user_type != 'admin' and b.membership_type = c.id and $where order by id DESC LIMIT $start, $limit";
			//echo "<br /> 3 = ".$sql;
		}
		$rs = $this->db->query($sql);
        $arrRes = $rs->result();
        return $arrRes;
	}
	
	function getAllTransection($where) {
		$sql = "SELECT a.*,b.* FROM `users` as a inner join  transection_details as b  WHERE a.id = b.userid and $where";
		$rs = $this->db->query($sql);
        $arrRes = $rs->result();
        return $arrRes;
	}
	
	function getAllTransections($where,$start = '',$limit= '') {
		if(empty($limit)){
			$sql = "SELECT a.*,b.* FROM `users` as a inner join transection_details as b  WHERE a.id = b.userid and $where order by b.id DESC";
		//	echo "<br /> 2 = ".$sql;
		}else{
			$sql = "SELECT a.*,b.* FROM `users` as a inner join transection_details as b  WHERE a.id = b.userid and $where order by b.id DESC LIMIT $start, $limit";
		//	echo "<br /> 3 = ".$sql;
		}
		$rs = $this->db->query($sql);
        $arrRes = $rs->result();
        return $arrRes;
	}
	
	
	function changeStatus($itemID,$status){
		$sql = "UPDATE pricing_details SET status = '".$status."' WHERE id = '".$itemID."' ";
        $this->db->query($sql);
	}
	
	function changeStatusNews($itemID,$status){
		$sql = "UPDATE newslater SET status = '".$status."' WHERE id = '".$itemID."' ";
        $this->db->query($sql);
	}
	
	function changeStatusUser($itemID,$status){
		$sql = "UPDATE users SET status = '".$status."' WHERE id = '".$itemID."' ";
        $this->db->query($sql);
	}
	
	
	function getEmailTemplate($where) {
		$sql = "SELECT * FROM `emailtemplate` WHERE $where";
		//echo "<br /> 1= ".$sql;
        $rs = $this->db->query($sql);
        $arrRes = $rs->result();
        return $arrRes;
	}
	
	function getEmailTemplates($where,$start = '',$limit= '') {
		if(empty($limit)){
			$sql = "select * from emailtemplate where $where order by id DESC";
		//	echo "<br /> 2 = ".$sql;
		}else{
			$sql = "select * from emailtemplate where $where order by id DESC LIMIT $start, $limit";
		//	echo "<br /> 3 = ".$sql;
		}
		$rs = $this->db->query($sql);
        $arrRes = $rs->result();
        return $arrRes;
	}
	
	
	function email_alias_exists($userName) {
		$sql = "select * FROM emailtemplate WHERE ( email_alias = '".$userName."') ";
		$rs = $this->db->query($sql);
		return $arrRes = $rs->num_rows();
    }
	
	
	function get_all_log($where) {
		$sql = "select a.*,b.username from  generate_log as a inner join users as b where $where";
	//	echo "<br /> 1= ".$sql;
        $rs = $this->db->query($sql);
        $arrRes = $rs->result();
        return $arrRes;
	}
	
	function get_all_logs($where,$start = '',$limit= '') {
		if(empty($limit)){
			$sql = "select a.*,b.username from  generate_log as a inner join users as b where $where order by id DESC";
	//		echo "<br /> 2 = ".$sql;
		}else{
			$sql = "select a.*,b.username from  generate_log as a inner join users as b where $where order by id DESC LIMIT $start, $limit";
	//		echo "<br /> 3 = ".$sql;
		}
		$rs = $this->db->query($sql);
        $arrRes = $rs->result();
        return $arrRes;
	}
	
	
	function deleteItemNews($delID){
		$qry = "DELETE FROM newslater WHERE id = ".$delID;
		$this->db->query($qry);
	}
	
	function deleteItemPrice($delID){
		$qry = "DELETE FROM  pricing_details WHERE id = ".$delID;
		$this->db->query($qry);
	}
	
}

<?php
class emails_model extends CI_Model {

    var $title   = '';
    var $content = '';
    var $date    = '';
	
	/**
     * constructor
     *  
     * @return void
     */ 
	
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
		$this->load->database();
    }
    
	function get_all_email($where) {
		$sql = "select * from emaillist where $where";
		//echo "<br /> 1= ".$sql;
        $rs = $this->db->query($sql);
        $arrRes = $rs->result();
        return $arrRes;
	}
	
	function get_all_emails($where,$start = '',$limit= '') {
		if(empty($limit)){
			$sql = "select * from emaillist where $where order by id DESC";
			//echo "<br /> 2 = ".$sql;
		}else{
			$sql = "select * from emaillist where $where order by id DESC LIMIT $start, $limit";
			//echo "<br /> 3 = ".$sql;
		}
		$rs = $this->db->query($sql);
        $arrRes = $rs->result();
        return $arrRes;
	}
	
	
	
	function insertEmails($results){
				
				$userid = $this->session->userdata('login_id');
				
				// view results
				$stringvaluePart = "";
				foreach($results as $email=>$result) {
				$status = ($result) ? 'Valid' : 'Invalid';
				
				$stringvaluePart .= "(
						".$userid.",
					'" .$email . "' ,
					'" .$status. "'
					),";
				}
				
				$stringSql = "INSERT INTO emaillist
							(userid, email, status)";
				$stringSql .= "VALUES";
				$stringvaluePart = trim($stringvaluePart, ',');
				$resultQuery = $this->db->query($stringSql . $stringvaluePart);
				return $resultQuery;
	}
	
	function getPoints($userID){
		
		$sql = "select * from emailpoints where userid =".$userID;
		$rs = $this->db->query($sql);
        $arrRes = $rs->result();
		return $arrRes[0];
	}
	
	function getMembershipType($userID){
		$sql = "select membership_type from emailpoints where userid =".$userID;
		$rs = $this->db->query($sql);
        $arrRes = $rs->result();
		//echo "<pre>";print_R($arrRes[0]);
		return $arrRes[0];
	}
	
	function getPrivateKeys($userID){
		$sql = "select * from users where id =".$userID;
		$rs = $this->db->query($sql);
        $arrRes = $rs->result();
		//echo "<pre>";print_R($arrRes[0]);exit;
		return $arrRes[0];
	}
	
	
	function insertPoints($remainPoint){
		$userid = $this->session->userdata('login_id');
		$stringSql = "UPDATE emailpoints
		SET point='".$remainPoint."'
		WHERE userid=".$userid;
		$resultQuery = $this->db->query($stringSql);
		return $resultQuery;
	}
	
	function getPriceDetails($priceId){
		$sql = "select * from pricing_details where id =".$priceId;
		$rs = $this->db->query($sql);
        $arrRes = $rs->result();
		return $arrRes[0];
	}
	
	
	function getAllTransection($where) {
		$userid = $this->session->userdata('login_id');
		$sql = "SELECT a.*,b.* FROM `users` as a inner join  transection_details as b  WHERE a.id = '".$userid."' and a.id = b.userid and $where";
		$rs = $this->db->query($sql);
        $arrRes = $rs->result();
        return $arrRes;
	}
	
	function getAllTransections($where,$start = '',$limit= '') {
		$userid = $this->session->userdata('login_id');
		if(empty($limit)){
			$sql = "SELECT a.*,b.*,c.no_of_mail FROM `users` as a inner join transection_details as b inner join  pricing_details as c WHERE a.id = '".$userid."' and b.item_name = c.mailtype and a.id = b.userid and $where order by b.id DESC";
		//	echo "<br /> 2 = ".$sql;
		}else{
			$sql = "SELECT a.*,b.*,c.no_of_mail FROM `users` as a inner join transection_details as b inner join  pricing_details as c WHERE a.id = '".$userid."' and a.id = b.userid and b.item_name = c.mailtype and $where order by b.id DESC LIMIT $start, $limit";
		//	echo "<br /> 3 = ".$sql;
		}
		$rs = $this->db->query($sql);
        $arrRes = $rs->result();
        return $arrRes;
	}

	function insertTxnID($postData)
    {
		
		$sql = "SELECT COUNT(*) as total FROM transection_details WHERE txn_id = '".$postData["txn_id"]."' ";
		//echo $sql;
		$rs = $this->db->query($sql);
		$data = $rs->result_array();
		if($data[0]['total'] > 0){
			return 0;
		}
		
		$membershipid = $this->uri->segment(3);
		
		$sqlDate = "select * from  pricing_details where id = '".$membershipid."'";
		$rslt = $this->db->query($sqlDate);
        $arrResMem = $rslt->result();
		
		// for month
		if($arrResMem[0]->validity == 1){
			$month = $arrResMem[0]->validity_month;
			$dateTime =  strtotime($postData["payment_date"]);
			$startDate = date("Y-m-d h:i:s", $dateTime); 
			$enddata = date("Y-m-d h:i:s", strtotime($postData["payment_date"]. "+".$month." months") );
		}
		
		//for year
		if($arrResMem[0]->validity == 2){
			$year = $arrResMem[0]->validity_year;
			$dateTime =  strtotime($postData["payment_date"]);
			$startDate = date("Y-m-d h:i:s", $dateTime); 
			$enddata = date("Y-m-d h:i:s", strtotime($postData["payment_date"]. "+".$year." years") );
		}
		
		
		$userid = $postData['userid'];
		$transactionID=$postData["txn_id"];
		$item=$postData["item_name"];
	    $amount=$postData["mc_gross"];
	    $currency=$postData["mc_currency"];
		
	    /*$datefields=explode(" ",$postData["payment_date"]);
	    $time=$datefields[0];
	    $date=str_replace(",","",$datefields[2])." ".$datefields[1]." ".$datefields[3];
	    $timestamp=strtotime($date." ".$time);*/
		
	    $dateTime =  strtotime($postData["payment_date"]);
		$timestamp = date("Y-m-d h:i:s", $dateTime);
		
		$status=$postData["payment_status"];
	    $firstname=$postData["first_name"];
	    $lastname=$postData["last_name"];
	    $email=$postData["payer_email"];
	    $custom=$postData["option_selection1"];
		
		if ($transactionID AND $amount)
		{
		    // query to save data
		  	$stringSql = "INSERT INTO transection_details
						(userid, txn_id, item_name, mc_gross, mc_currency, payment_date,payment_enddate, payment_status, payer_email)";
			$stringSql .= "VALUES";
			$stringSql .= "(
				'".$userid."',
				'".$transactionID."',
				'".$item."' ,
				'".$amount. "',
				'".$currency."',
				'".$timestamp."' ,
				'".$enddata."',
				'".$status."',
				'".$email."'
				)";
			$resultQuery = $this->db->query($stringSql);
		//	echo "id = ".$this->db->insert_id();exit;
			return $this->db->insert_id();
		}
	    else
	    {
		//echo "id = 0";exit;
		  return 0;
		}
    }
	
	
	function htmlCartPage($priceDetails){
		$html = '<table width="100%" cellspacing="0" cellpadding="0" border="0" style=" text-align: center;">
             <thead>
                  <tr>
					<td  class="" >
                    	<div class="priceHeaderTitle">
                            <h2>Product Name</h2>
						</div>
					</td>	
					<td  class="" >
						<div class="priceHeaderTitle">
                            <h2>Price</h2>
						</div>						
                    </td>
					<td  class="" >
						<div class="priceHeaderTitle">
                            <h2>Total Mails</h2>
						</div>						
                    </td>
					<td  class="" >
						<div class="priceHeaderTitle">
                            <h2>Total</h2>
						</div>						
                    </td>
                  </tr>
			</thead>
                  
			<tbody>
				<tr class="priceTitle">
					<td>
						<h3>'.$priceDetails->mailtype.'</h3>
					</td>
					<td>	
						<h3>$'.$priceDetails->price.'</h3>
					</td>
					<td>	
						<h3>'.$priceDetails->no_of_mail.'</h3>
					</td>
					<td>	
						<h3>$'.$priceDetails->price.'</h3>
					</td>					
                </tr>
				
            </tbody>
		</table>
		<table width="100%" cellspacing="0" cellpadding="0" border="0" style="float:right;">	
		<tfoot>
                  <tr>
    				<td>
						<a href="'.GLOBAL_PATH . 'emails/paypalForm/'.$priceDetails->id.'" class="submit-button-dark" id="mc-embedded-subscribe"><span class="sprite"><em class="sprite">Place Order</em></span></a></div>
					</td>
				  </tr>
			</tfoot>
        </table>';
		
	return $html;
	}
	
	function updateAuthKey($postData){
		$stringSql = "UPDATE users
		SET auth_token='".$postData['auth']."'
		WHERE id=".$postData['id'];
		$resultQuery = $this->db->query($stringSql);
		return $resultQuery;
	}
	
	
	function getLimitPriceDetail($mid){
		$userid = $this->session->userdata('login_id');
		$sql = "select b.max_per_day,b.bulk_limit from emailpoints as a inner join pricing_details as b where userid =".$userid." and a.membership_type = b.id";
		$rs = $this->db->query($sql);
        $arrRes = $rs->result();
		return $arrRes[0];
	}
	
	
	function genrateLogs($genratArray){
	
		$insert = "insert into generate_log (`user_id`,`ipaddress`,`domain`,`platform`,`email`,`email_result`,`date`,`req_status`,`req_message`)";
		
		$insert .= "values";
		
		foreach($genratArray as $key => $resultData) {
			
				$insert .= "('".$resultData['userid']."','".$resultData['ipaddress']."','".$resultData['domain']."','".$resultData['platform']."','".$resultData['email']."','".$resultData['email_result']."','".$resultData['date']."','".$resultData['req_status']."','".$resultData['req_message']."'),";
			
			// sucess email validator generate log 
		}
		$insert = trim($insert,',');
		$resultQuery = $this->db->query($insert);
		return $resultQuery;
	
	}
	
	function getValidity($membershipid){
		
		$sqlDate = "select * from  pricing_details where id = '".$membershipid."'";
		$rslt = $this->db->query($sqlDate);
        $arrResMem = $rslt->result();
		
		// for month
		if($arrResMem[0]->validity == 1){
			$month = $arrResMem[0]->validity_month;
			//$dateTime =  strtotime($postData["payment_date"]);
			$startDate = date("Y-m-d h:i:s"); 
			$enddata = date("Y-m-d h:i:s", strtotime($startDate. "+".$month." months") );
		}
		
		//for year
		if($arrResMem[0]->validity == 2){
			$year = $arrResMem[0]->validity_year;
			//$dateTime =  strtotime($postData["payment_date"]);
			$startDate = date("Y-m-d h:i:s"); 
			$enddata = date("Y-m-d h:i:s", strtotime($startDate. "+".$year." years") );
		}
		$validity = array();
		$validity['start_date'] = $startDate;
		$validity['end_date'] = $enddata;
		
		return $validity;
	
	}
	
	
	function get_all_user_log($where) {
		$sql = "select a.*,b.username from  generate_log as a inner join users as b where $where";
	//	echo "<br /> 1= ".$sql;
        $rs = $this->db->query($sql);
        $arrRes = $rs->result();
        return $arrRes;
	}
	
	function get_all_user_logs($where,$start = '',$limit= '') {
		if(empty($limit)){
			$sql = "select a.*,b.username from  generate_log as a inner join users as b where $where order by id DESC";
	//		echo "<br /> 2 = ".$sql;
		}else{
			$sql = "select a.*,b.username from  generate_log as a inner join users as b where $where order by id DESC LIMIT $start, $limit";
	//		echo "<br /> 3 = ".$sql;
		}
		$rs = $this->db->query($sql);
        $arrRes = $rs->result();
        return $arrRes;
	}
	
	function getPerDayLimit($userID){
		$sql = "select count(*) as countData from generate_log where date between '".date('Y-m-d')." 00:00:00"."' and '".date('Y-m-d')." 23:59:59"."' and user_id = '".$userID."'";
		$rs = $this->db->query($sql);
        $arrRes = $rs->result();
		return $arrRes[0];
	}
	
}

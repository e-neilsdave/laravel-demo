$(document).ready(function() {

    // validate contact form on keyup and submit
    $("#formLogin").validate({
 
        //set the rules for the fild names
        rules: {
            username: {
                required: true,
            },
            password: {
                required: true,
            },
            
        },
 
        //set error messages
        messages: {
            username: {
                required: "Name is required..",
            },
            password: {
            required: "Please provide a password.",
            },          
        },
 
        //our custom error placement
        errorElement: "span",
        errorPlacement: function(error, element) {
                error.appendTo(element.parent());
            }
 
    });
	
	    // validate contact form on keyup and submit
   /* $("#formSignup").validate({
 
        //set the rules for the fild names
        rules: {
            username: {
                required: true,
                minlength: 3,
                maxlength:25,
              
            },
            email: {
                required: true,
                email: true
            },
            password: {
                required: true,
                minlength: 6,
                maxlength:15
            },
			
			confirm_password: {
				required: true,
				minlength: 6,
				equalTo: "#password"
			},
            
        },
 
        //set error messages
        messages: {
 
            username: {
                required: "Userame is required..",
            },
            password: {
            required: "Please provide a password.",
            minlength: "Password must be at least 6 characters long",
            maxlength: "Password can not be more than 15 characters"
            },
			
			confirm_password: {
				required: "please password",
				minlength: "password at least 6 chars",
				equalTo: "password fields have to match"
			},
			
            email: "Valid email is required.",
           
        },
 
        //our custom error placement
        errorElement: "span",
        errorPlacement: function(error, element) {
                error.appendTo(element.parent());
            }
 
    });
	*/
	
	
	
	
});
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * CodeIgniter
 *
 * An open source application development framework for PHP 5.1.6 or newer
 *
 * @package		CodeIgniter
 * @author		ExpressionEngine Dev Team
 * @copyright	Copyright (c) 2008 - 2011, EllisLab, Inc.
 * @license		http://codeigniter.com/user_guide/license.html
 * @link		http://codeigniter.com
 * @since		Version 1.0
 * @filesource
 */

// ------------------------------------------------------------------------

/**
 * CodeIgniter Model Class
 *
 * @package		CodeIgniter
 * @subpackage	Libraries
 * @category	Libraries
 * @author		ExpressionEngine Dev Team
 * @link		http://codeigniter.com/user_guide/libraries/config.html
 */
class CI_Model {

	/**
	 * Constructor
	 *
	 * @access public
	 */
	function __construct()
	{
		log_message('debug', "Model Class Initialized");
	}

	/**
	 * __get
	 *
	 * Allows models to access CI's loaded classes using the same
	 * syntax as controllers.
	 *
	 * @param	string
	 * @access private
	 */
	function __get($key)
	{
		$CI =& get_instance();
		return $CI->$key;
	}
        
        /**
         * inserts to DB
         *
         * @param string $table 
         * @param array $data to be inserted 
         * @return integer inserted record primary key
         */
        function globalInsert($table, $data) {
            $names = "";
            $values = "";
            $start = 0;
            foreach ($data as $name => $value) {
                    $names .= "$name, ";
                    if($value == 'now()') {
                        $values .= $value . ", ";
                    } else {
                        $values .= "'" . $value . "', ";
                    }

                    $start++;
            }
            $names = trim($names);
            $values = trim($values);
            $names = trim($names, ",");
            $values = trim($values, ",");
            $insertSql = "INSERT INTO $table ($names) VALUES ($values)";
            $this->db->query($insertSql);
            return $this->db->insert_id();
        }

        /**
         * updates to DB
         *
         * @param string $table 
         * @param array $data to be updated 
         * @return void
         */
        function globalUpdate($table, $data) {
            $updateSet = '';
            $start = 0;
            foreach ($data as $name => $value) {
                    if ($start == 0) {
                        $id_key = $name;
                        $id_val = $value;
                    }
                    if($value == 'now()') {
                        $updateSet .= $name . "=" . $value . ",";
                    } else {
                        $updateSet .= $name . "='" . $value . "',";
                    }
                    $start++;
            }
            $updateSet = trim($updateSet);
            $updateSet = trim($updateSet, ",");
            $updateSql = "UPDATE $table SET " . $updateSet . " WHERE " . $id_key . "='" . $id_val . "'"; 
			//echo $updateSql;exit;
            $this->db->query($updateSql);
        }
        
        function pagingAndCount($sql, $normalSelect, $countQuery, $start) {
            if ($countQuery) {
                $sql = "select count(*) as total " . $sql;
                $rs = $this->db->query($sql);
                $arrRes = $rs->result();
                return $arrRes[0]->total;
            } else {
                $start = (($start - 1) * RECORDS_PER_PAGE);
                if($start < 0) {
                    $start = 0;
                }
                $sql = "select " . $normalSelect . $sql . " LIMIT " . $start . ", " . RECORDS_PER_PAGE;
                $rs = $this->db->query($sql);
                return $rs->result_array();
            }
	}

}
// END Model Class

/* End of file Model.php */
/* Location: ./system/core/Model.php */